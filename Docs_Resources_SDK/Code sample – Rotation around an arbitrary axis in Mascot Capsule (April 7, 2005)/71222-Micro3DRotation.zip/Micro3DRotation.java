/*****************************************************************************

 Description: Rotation around an arbitrary axis in Mascot Capsule

 Created By: Oscar Vivall
 
 @file        Micro3DRotation.java

 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2004.
 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license 
 agreement which accompanies or is included with the software. The software is 
 provided "as is" and Sony Ericsson specifically disclaim any warranty or 
 condition whatsoever regarding merchantability or fitness for a specific 
 purpose, title or non-infringement. No warranty of any kind is made in 
 relation to the condition, suitability, availability, accuracy, reliability, 
 merchantability and/or non-infringement of the software provided herein.

*****************************************************************************/

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Micro3DRotation extends javax.microedition.midlet.MIDlet {
    
    private Display d;
    private RotationCanvas canvas;
    
    public Micro3DRotation(){
        d = Display.getDisplay(this);
        canvas = new RotationCanvas(this);
    }
    
    public void startApp() {
        d.setCurrent(canvas);
    }
    
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
}
