/*****************************************************************************

 Description: Rotation around an arbitrary axis in Mascot Capsule

 Created By: Oscar Vivall
 
 @file        Micro3DRotation.java

 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2004.
 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license 
 agreement which accompanies or is included with the software. The software is 
 provided "as is" and Sony Ericsson specifically disclaim any warranty or 
 condition whatsoever regarding merchantability or fitness for a specific 
 purpose, title or non-infringement. No warranty of any kind is made in 
 relation to the condition, suitability, availability, accuracy, reliability, 
 merchantability and/or non-infringement of the software provided herein.

*****************************************************************************/

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

import javax.microedition.lcdui.game.*;
import com.mascotcapsule.micro3d.v3.*;

public class RotationCanvas extends GameCanvas implements Runnable{

    private Graphics3D g3d = new Graphics3D();

    private FigureLayout layout;
    private Effect3D effect;
    private AffineTrans trans;
    
    private MIDlet midlet;

    private Texture texture = null;

    private AffineTrans rotationX;
    private AffineTrans rotationY;
    private AffineTrans rotationZ;
    private AffineTrans camera;
    
    private Command ExitCommand;
    
    private static final int COMMAND = Graphics3D.PRIMITVE_QUADS | 
                                            Graphics3D.PDATA_COLOR_PER_FACE;

    private int[] POINTS = {10, 10, 10,   -10, 10, 10,    -10, -10, 10,   10,-10, 10,                // front
                            -10, 10,-10,    10, 10,-10,   10, -10,-10,    -10,-10,-10,             // back
                            -10, 10, 10,   -10, 10,-10,   -10, -10,-10,   -10,-10, 10,                // left
                            10, 10,-10,    10, 10, 10,    10, -10, 10,   10,-10,-10,                 // right
                            10, 10,-10,   -10, 10,-10,    -10, 10,10,     10, 10, 10,                // top
                            10,-10, 10,   -10,-10, 10,    -10,-10, -10,  10,-10,-10};            // bottom


    private int[] NORMALS = {0, 0, 4096};
    private int []TEXTURES = {0,0};

    private int []COLORS = {0xFFFF00, 0xFF0000, 0x00FFFF, 0x00FF00, 0x0000FF, 0xFF00FF};

    
    public RotationCanvas(MIDlet m){
        super(false);

        midlet = m;

        layout = new FigureLayout();
        effect = new Effect3D();
        trans = new AffineTrans();

        camera = new AffineTrans();
        rotationX = new AffineTrans();
        rotationY = new AffineTrans();
        rotationZ = new AffineTrans();

        camera.setIdentity();
        camera.lookAt( new Vector3D(0, 0, 64), new Vector3D(0, 0, -4096), new Vector3D(0, 4096, 0) );

        effect.setShadingType(Effect3D.NORMAL_SHADING);

        trans.setIdentity();
        trans.mul(camera);

        layout.setAffineTrans( trans );
        layout.setPerspective(1, 4096, 512);
        layout.setCenter(getWidth()/2, getHeight()/2);

        ExitCommand = new Command("Exit", Command.EXIT, 0);
        this.addCommand(ExitCommand);
        this.setCommandListener(new CommandListener(){
            public void commandAction(Command c, Displayable d){
                if(c==ExitCommand){
                    midlet.notifyDestroyed();
                }
            }
        });

        Thread t = new Thread(this);
        t.start();
    }

    public void draw3D(Graphics g){
        try{
            g3d.bind(g);
            g3d.renderPrimitives(null, 0, 0, layout, effect, COMMAND, 6, POINTS, NORMALS, TEXTURES, COLORS);
            g3d.flush();
        }finally{
            g3d.release( g );
        }
    }

    public void run(){
        Graphics g = getGraphics();
        
        while(true){
            g.setColor(0x000000);
            g.fillRect(0, 0, getWidth(), getHeight());
            draw3D(g);
            flushGraphics();

            // specify the rotation angle.
            rotationX.rotationX(56);
            rotationY.rotationY(32);
            rotationZ.rotationZ(48);
            trans.mul(rotationX);
            trans.mul(rotationY);
            trans.mul(rotationZ);

            try{
                Thread.sleep(10);
            }catch(Exception e){

            }
        }        
    }
}
