package example.Sample1;

import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import com.mascotcapsule.micro3d.v3.*;
/**
 * Sample1
 */
public class Sample1 extends MIDlet {
	private Canvas3D canvas;

	public Sample1() {
	}

	//------------------------------------------------------
	// startApp
	//------------------------------------------------------
	public void startApp() {

		try {

			Display d = Display.getDisplay(this);
			canvas = new Canvas3D();
			d.setCurrent(canvas);

			Thread runner = new Thread(canvas);
			runner.start();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean u) {
	}

}

/**
 * Canvas3D
 */
final class Canvas3D extends Canvas implements Runnable{

	Figure figure;
	FigureLayout layout;
	Texture mainTexture;

	Effect3D effect;
	AffineTrans affineTrans;
       private Graphics3D g3 = new Graphics3D();

	int centerX;
	int centerY;


	//Viewpoint
	private static Vector3D Pos = new Vector3D(0,120,500);
	private static Vector3D Look = new Vector3D(0,0,-2000);
	private static Vector3D Up = new Vector3D(0,4096,0);

	int bgColor = 0x333377; //background


	//----------------------------------------------------------
	// MainCanvas
	//----------------------------------------------------------
	Canvas3D() throws IOException {
		super();
		figure = new Figure("/example/DemoMIDP/test_model_robo.mbac");
		mainTexture = new Texture("/example/DemoMIDP/tex_001.bmp", true);
		figure.setTexture(mainTexture);

		effect = new Effect3D( null, Effect3D.NORMAL_SHADING, true, null);

		layout = new FigureLayout();

		initViewParams();

	}

	//------------------------------------------------------
	// run
	//------------------------------------------------------
	public void run() {

		// main process
		while (true) {
			// repaint
			repaint();

			try {
				Thread.sleep(100);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}


	//------------------------------------------------------
	// initViewParams
	//------------------------------------------------------
	// initialization
	void initViewParams() {
		centerX = getWidth() / 2;
		centerY =getHeight() / 2;

		// AffineTrans initialization
		affineTrans = new AffineTrans();
		affineTrans.lookAt(Pos, Look, Up);

	}

	//------------------------------------------------------
	// paint
	//------------------------------------------------------
	protected void paint(Graphics g) {

		g.setColor(bgColor);

		g.fillRect(0, 0, getWidth(), getHeight());


		layout.setCenter(centerX, centerY);
		layout.setAffineTrans(affineTrans);
		layout.setParallelSize(800, 800);


		// jowe Graphics3D g3 = (Graphics3D)g;

                try{
                    //Get the Graphics 3D object and render the
                    //figure in the center of the screen with
                    //light effect.
                    g3.bind(g);
                    g3.renderFigure(figure, 0, 0, layout, effect);
                    //Flush to screen
                    g3.flush();
                    //Release the Graphics 3D object
                    g3.release(g);
                } catch (Exception e) {
                    log("Exception: " + e.getMessage());
                }



		//3D rendering
		//jowe g3.renderFigure(figure, 0, 0, layout, effect);
		//jowe g3.flush();

	}
        
        private void log(String msg){
            System.out.println(msg);
        }

}

