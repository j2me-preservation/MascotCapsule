package example.Sample2;

import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import com.mascotcapsule.micro3d.v3.*;
/**
 * Sample2
 */
public class Sample2 extends MIDlet {
	private Canvas3D canvas;

	public Sample2() {
	}

	//------------------------------------------------------
	// startApp
	//------------------------------------------------------
	public void startApp() {

		try {

			Display d = Display.getDisplay(this);
			canvas = new Canvas3D();
			d.setCurrent(canvas);

			Thread runner = new Thread(canvas);
			runner.start();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean u) {
	}

}

/**
 * Canvas3D
 */
final class Canvas3D extends Canvas implements Runnable{

	Figure figure;
	FigureLayout layout;
	Texture mainTexture;

	Effect3D effect;
	AffineTrans affineTrans;
        
        private Graphics3D g3 = new Graphics3D();

	int centerX;
	int centerY;


	//Viewpoint
	private static Vector3D Pos = new Vector3D(0,120,500);
	private static Vector3D Look = new Vector3D(0,0,-2000);
	private static Vector3D Up = new Vector3D(0,4096,0);


	// Translation value
	public final static int MOVE_PLUS = 10;	// Increase or decrease value of translation
	private static int moveX = 0;	// X axis translation value
	private static int moveY = 0;	// Y axis translation value



	int bgColor = 0x333377; //background


	//----------------------------------------------------------
	// MainCanvas
	//----------------------------------------------------------
	Canvas3D() throws IOException {
		super();
		figure = new Figure("/example/DemoMIDP/test_model_robo.mbac");
		mainTexture = new Texture("/example/DemoMIDP/tex_001.bmp", true);
		figure.setTexture(mainTexture);

		effect = new Effect3D( null, Effect3D.NORMAL_SHADING, true, null);

		layout = new FigureLayout();

		initViewParams();

	}

	//------------------------------------------------------
	// run
	//------------------------------------------------------
	public void run() {

		// main process
		while (true) {
			// repaint
			repaint();

			try {
				Thread.sleep(100);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}


	//------------------------------------------------------
	// initViewParams
	//------------------------------------------------------
	// initialization
	void initViewParams() {
		centerX = getWidth() / 2;
		centerY =getHeight() / 2;

		// AffineTrans initialization
		affineTrans = new AffineTrans();
		affineTrans.lookAt(Pos, Look, Up);

	}

	//------------------------------------------------------
	// keyPressed
	//------------------------------------------------------
	protected void keyPressed(int kc) {

		switch (kc) {
			case Canvas.KEY_NUM4: // movel left
				addMoveX(-MOVE_PLUS);
				break;
			case Canvas.KEY_NUM6: // move right
				addMoveX(MOVE_PLUS);
				break;
			case Canvas.KEY_NUM2: // move up
				addMoveY(-MOVE_PLUS);
				break;
			case Canvas.KEY_NUM8: // move down
				addMoveY(MOVE_PLUS);
				break;

			default:
				break;
		}

	}

	//------------------------------------------------------
	// keyReleased
	//------------------------------------------------------
	protected void keyReleased(int kc) {
		moveX = 0;
		moveY = 0;
	}

	//------------------------------------------------------
	// paint
	//------------------------------------------------------
	protected void paint(Graphics g) {

		g.setColor(bgColor);

		g.fillRect(0, 0, getWidth(), getHeight());


		//move
		affineTrans.m03 += moveX;
		affineTrans.m13 += moveY;



		layout.setCenter(centerX, centerY);
		layout.setAffineTrans(affineTrans);
		layout.setParallelSize(800, 800);

                try{
                    //Get the Graphics 3D object and render the
                    //figure in the center of the screen with
                    //light effect.
                    g3.bind(g);
                    g3.renderFigure(figure, 0, 0, layout, effect);
                    //Flush to screen
                    g3.flush();
                    //Release the Graphics 3D object
                    g3.release(g);
                } catch (Exception e) {
                    log("Exception: " + e.getMessage());
                }

	}

	// X axis translation
	void addMoveX(int move){
		moveX += move;
	}

	// Y axis translation
	void addMoveY(int move){
		moveY += move;
	}
        
        private void log(String msg){
            System.out.println(msg);
        }


}

