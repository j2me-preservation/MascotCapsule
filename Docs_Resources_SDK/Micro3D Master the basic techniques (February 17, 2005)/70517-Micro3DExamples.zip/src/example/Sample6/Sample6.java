package example.Sample6;

import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import com.mascotcapsule.micro3d.v3.*;
/**
 * Sample6
 */
public class Sample6 extends MIDlet {
	private Canvas3D canvas;

	public Sample6() {
	}

	//------------------------------------------------------
	// startApp
	//------------------------------------------------------
	public void startApp() {

		try {

			Display d = Display.getDisplay(this);
			canvas = new Canvas3D();
			d.setCurrent(canvas);

			Thread runner = new Thread(canvas);
			runner.start();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean u) {
	}

}

/**
 * Canvas3D
 */
final class Canvas3D extends Canvas implements Runnable,CommandListener{
        private Graphics3D g3 = new Graphics3D();
	Figure figure;
	FigureLayout layout;
	Texture mainTexture;

	Effect3D effect;
	AffineTrans affineTrans;

	int centerX;
	int centerY;


	//Viewpoint
	private static Vector3D Pos = new Vector3D(0,120,500);
	private static Vector3D Look = new Vector3D(0,0,-2000);
	private static Vector3D Up = new Vector3D(0,4096,0);


	// Translation value
	public final static int MOVE_PLUS = 10;	// Increase or decrease value of translation
	private static int moveX = 0;	// X axis translation value
	private static int moveY = 0;	// Y axis translation value


	// Scale value
	public final static int SCALE_PLUS = 100;	// Increase or decrease value of scaling
	private static int scaleX = 4096;// X axis scaling value
	private static int scaleY = 4096;// Y axis scaling value
	private static int scaleZ = 4096;// Z axis scaling value


	Light light;//Lights
	boolean lightEnabled;//Enable lighting(on,off)
	// Lights
	private Vector3D dir = new Vector3D(-3511, 731, 878); // Light vector
	private final int dirIntensity = 4096; // Light intensity
	private final int ambIntensity = 1755; // Ambient light intensity


	//Command(for SOFT KEY)
	static final Command Light_CMD = new Command("Light", Command.EXIT, 2);
	static final Command Perspective_CMD = new Command("Perspective", Command.SCREEN, 1);


	//The status of the projection method
	boolean persEnabled;

	// Camera distance
	private final static int persNear = 1;	// Minimum distance to the camera
	private final static int persFar = 4096;	// Maximum distance to the camera
	private final static int persAngle = 682;	// Angle


	// Rotation value
	public final static int SPIN_X_PLUS = 100;	// Increase or decrease value of the rotation around X axis
	public final static int SPIN_Y_PLUS = 100;	// Increase or decrease value of the rotation around Y axis
	private static int spinX = 0;	// X axis rotation value
	private static int spinY = 0;	// Y axis rotation value


	int bgColor = 0x333377; //background


	//----------------------------------------------------------
	// MainCanvas
	//----------------------------------------------------------
	Canvas3D() throws IOException {
		super();
		figure = new Figure("/example/DemoMIDP/test_model_robo.mbac");
		mainTexture = new Texture("/example/DemoMIDP/tex_001.bmp", true);
		figure.setTexture(mainTexture);

		light = new Light(dir,dirIntensity,ambIntensity);

		effect = new Effect3D( light, Effect3D.NORMAL_SHADING, true, null);

		layout = new FigureLayout();

		initViewParams();

		//SOFT KEY command registers
		addCommand(Light_CMD);
		addCommand(Perspective_CMD);
		setCommandListener(this);
	}

	//------------------------------------------------------
	// run
	//------------------------------------------------------
	public void run() {

		// main process
		while (true) {
			// repaint
			repaint();

			try {
				Thread.sleep(100);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}


	//------------------------------------------------------
	// initViewParams
	//------------------------------------------------------
	// initialization
	void initViewParams() {
		centerX = getWidth() / 2;
		centerY =getHeight() / 2;

		// AffineTrans initialization
		affineTrans = new AffineTrans();
		affineTrans.lookAt(Pos, Look, Up);

	}

	//------------------------------------------------------
	// keyPressed
	//------------------------------------------------------
	protected void keyPressed(int kc) {

		switch (kc) {
			case Canvas.KEY_NUM4: // movel left
				addMoveX(-MOVE_PLUS);
				break;
			case Canvas.KEY_NUM6: // move right
				addMoveX(MOVE_PLUS);
				break;
			case Canvas.KEY_NUM2: // move up
				addMoveY(-MOVE_PLUS);
				break;
			case Canvas.KEY_NUM8: // move down
				addMoveY(MOVE_PLUS);
				break;
			case Canvas.KEY_NUM7: // zoom in
				addScale(SCALE_PLUS);
				break;
			case Canvas.KEY_NUM9: // zoom out
				addScale(-SCALE_PLUS);
				break;
			default:
				kc = getGameAction(kc);
				switch (kc) {
					case Canvas.UP: // roll up
						setSpinX(-SPIN_X_PLUS);
						break;
					case Canvas.DOWN: // roll down
						setSpinX(SPIN_X_PLUS);
						break;
					case Canvas.LEFT: // roll left
						setSpinY(-SPIN_Y_PLUS);
						break;
					case Canvas.RIGHT: // roll right
						setSpinY(SPIN_Y_PLUS);
						break;
					default:
						break;
				}
				break;
		}

	}

	//------------------------------------------------------
	// keyReleased
	//------------------------------------------------------
	protected void keyReleased(int kc) {
		moveX = 0;
		moveY = 0;

		switch (kc) {
			case Canvas.KEY_NUM9:
				addScale(SCALE_PLUS);
				break;
			case Canvas.KEY_NUM7:
				addScale(-SCALE_PLUS);
				break;
		}

		spinX = 0;
		spinY = 0;

	}

	//------------------------------------------------------
	// commandAction
	//------------------------------------------------------
	public void commandAction(Command c, Displayable s) {
		if(c == Light_CMD) {
			if(lightEnabled){
				lightEnabled = false;
			}else{
				lightEnabled = true;
			}
		}else if(c == Perspective_CMD){
			if(persEnabled){
				persEnabled = false;
			}else{
				persEnabled = true;
			}
		}
	}

	//------------------------------------------------------
	// paint
	//------------------------------------------------------
	protected void paint(Graphics g) {

		g.setColor(bgColor);

		g.fillRect(0, 0, getWidth(), getHeight());


		//move
		affineTrans.m03 += moveX;
		affineTrans.m13 += moveY;

		AffineTrans af = new AffineTrans();

		// Scaling the model
		af.set(scaleX,0,0,0,0,scaleY,0,0,0,0,scaleZ,0);
		affineTrans.mul(af);

		//Setting the Enable lighting
		if(lightEnabled){
			effect.setLight(light);
		}else{
			effect.setLight(null);
		}

		//X roll
		af.setIdentity();
		af.setRotationX(spinX);
		affineTrans.mul(af);

		//Y roll
		af.setIdentity();
		af.setRotationY(spinY);
		affineTrans.mul(af);

		layout.setCenter(centerX, centerY);
		layout.setAffineTrans(affineTrans);


		//Setting the projection method
		if(persEnabled){
			layout.setPerspective(persNear, persFar, persAngle);
		}else{
			layout.setParallelSize(800, 800);
		}

                try{
                    //Get the Graphics 3D object and render the
                    //figure in the center of the screen with
                    //light effect.
                    g3.bind(g);
                    g3.renderFigure(figure, 0, 0, layout, effect);
                    //Flush to screen
                    g3.flush();
                    //Release the Graphics 3D object
                    g3.release(g);
                } catch (Exception e) {
                    System.out.println("Exception: " + e.getMessage());
                }

	}

	// X axis translation
	void addMoveX(int move){
		moveX += move;
	}
	
	// Y axis translation
	void addMoveY(int move){
		moveY += move;
	}

	// Scaling the model
	void addScale(int scale){
		if((scaleX+scale) < 0) return;
		if((scaleX+scale) > 8192) return;
		scaleX += scale;
		scaleY += scale;
		scaleZ += scale;
	}

	// Rotaion around X axis
	void setSpinX(int x){
		spinX += x;
	}
	// Rotaion around Y axis
	void setSpinY(int y){
		spinY += y;
	}

}

