
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

import javax.microedition.lcdui.game.*;
import com.mascotcapsule.micro3d.v3.*;


public class GhostMidlet extends MIDlet{
    
    Display display;
    public GhostMidlet() {
        display = Display.getDisplay(this);
    }
    
    public void startApp() {
        display.setCurrent(new GhostCanvas());
    }
    
    public void pauseApp() {
        
    }
    
    public void destroyApp(boolean unconditional) {
    }
}
    

class GhostCanvas extends GameCanvas implements Runnable{
    
    private Graphics3D g3d;
    private int COMMAND =   Graphics3D.PRIMITVE_POINT_SPRITES |
                            Graphics3D.PDATA_POINT_SPRITE_PARAMS_PER_CMD;
//                            Graphics3D.PATTR_BLEND_HALF |
//                            Graphics3D.PATTR_COLORKEY;
//    private int COMMAND =   Graphics3D.PRIMITVE_POINT_SPRITES | 
//                            Graphics3D.PDATA_POINT_SPRITE_PARAMS_PER_CMD | 
//                            Graphics3D.PDATA_NORMAL_NONE | 
//                            Graphics3D.PATTR_COLORKEY | 
//                            Graphics3D.PDATA_COLOR_NONE;    
    
    
    private int BG_COMMAND =   Graphics3D.PRIMITVE_POINT_SPRITES |
                            Graphics3D.PDATA_POINT_SPRITE_PARAMS_PER_CMD;
    
    private int []POINT = {0, 0, 0};
    private int []textureCoords = {40, 50, 0, 0, 0, 80, 100, Graphics3D.POINT_SPRITE_PERSPECTIVE};
    private int []textureCoords2 = {128, 160, 0, 0, 0, 128, 160, Graphics3D.POINT_SPRITE_PERSPECTIVE};
    //w0, h0, a0, x00, y00, x01, y01, f0,
    
    private int [] NORMAL = new int[] {0, 0, 4096};
    private int []colors = {0x00FFFFFF};
    
    private Effect3D effect;
    private AffineTrans trans;
    private FigureLayout layout;

    private Effect3D effect2;
    private AffineTrans trans2;
    private FigureLayout layout2;

    
    private Texture ghostTexture;
    private Texture bgTexture;
    
    private int index = 0;
    
    public GhostCanvas(){
        super(false);
        setFullScreenMode(true);
        g3d = new Graphics3D();
System.out.println("1");
        try{
            ghostTexture = new Texture("/ghost.bmp", true);
            bgTexture = new Texture("/bg.bmp", true);
        }catch(Exception e){
            System.err.println("Failed to load Texture!");
        }

        effect = new Effect3D();
        effect.setShadingType(Effect3D.NORMAL_SHADING);
        effect.setTransparency(true);
        trans = new AffineTrans();
        trans.setIdentity();
        trans.lookAt(new Vector3D(0, 0, 128), new Vector3D(0, 0, -4096), new Vector3D(0, 4096, 0));
        
        layout = new FigureLayout();
        layout.setPerspective(1, 4096, 512);
        layout.setCenter(getWidth()/2, getHeight()/2);
        layout.setAffineTrans(trans);
// -----------------------------------------
        effect2 = new Effect3D();
        effect2.setShadingType(Effect3D.NORMAL_SHADING);
        trans2 = new AffineTrans();
        trans2.setIdentity();
        trans2.lookAt(new Vector3D(0, 0, 150), new Vector3D(0, 0, -4096), new Vector3D(0, 4096, 0));
        
        layout2 = new FigureLayout();
        layout2.setPerspective(1, 4096, 512);
        layout2.setCenter(getWidth()/2, getHeight()/2);
        layout2.setAffineTrans(trans2);

        Thread t = new Thread(this);
        t.start();
    }
    
    public void keyPressed(int key){
        if(key==-6){
            index = index==2?0:index+1;
            if(index==0){
                COMMAND ^= Graphics3D.PATTR_COLORKEY;
                COMMAND ^= Graphics3D.PATTR_BLEND_HALF;
            }else if(index ==1){
                COMMAND ^= Graphics3D.PATTR_COLORKEY;
            }else{
                COMMAND ^= Graphics3D.PATTR_BLEND_HALF;
            }
        }
    }
    
    private void draw3D(Graphics g){
        g.setColor(0xFF00FF);
        g.fillRect(0,0, getWidth(), getHeight());

            g3d.bind(g);

        try{
            g3d.renderPrimitives(bgTexture, 0, 0, layout2, effect2, BG_COMMAND, 1, POINT, NORMAL, textureCoords2, colors);
            g3d.renderPrimitives(ghostTexture, 0, 0, layout, effect, COMMAND, 1, POINT, NORMAL, textureCoords, colors);
            g3d.flush();
        }catch(Exception e){
            System.err.println(e);
        }finally{
            g3d.release(g);
        }
    }

    public void run(){
        Graphics g = getGraphics();
        while(true){
            keyPressed(getKeyStates());
            draw3D(g);
            flushGraphics();
            try{
                Thread.sleep(20);
            }catch(Exception e){}
        }
    }
    
}
