import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import com.mascotcapsule.micro3d.v3.*;
/**
 * Sample9
 */
public class Main extends MIDlet {
	private Canvas3D canvas;

	//------------------------------------------------------
	// startApp
	//------------------------------------------------------
	public void startApp() {
		try {
			Display d = Display.getDisplay(this);
			canvas = new Canvas3D();
			d.setCurrent(canvas);

			Thread runner = new Thread(canvas);
			runner.start();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void pauseApp() {}
	public void destroyApp(boolean u) {}
}

/**
 * Canvas3D
 */
final class Canvas3D extends Canvas implements Runnable, CommandListener{
	private Graphics3D g3;

	private Figure figure;
	private FigureLayout layout;
	private Texture mainTexture;

	private Effect3D effect;
	private AffineTrans viewTrans;
	private AffineTrans modelTrans;
	private AffineTrans tempTrans;

	private int centerX;
	private int centerY;

	//Viewpoint
	private static Vector3D Pos = new Vector3D(0,120,500);
	private static Vector3D Look = new Vector3D(0,0,-2000);
	private static Vector3D Up = new Vector3D(0,4096,0);

	private int modelx = 0;
	private int modely = 0;
	private int modelz = 0;
	public static final int MOVE_MODEL = 10;

	private int spinx = 0;
	private int spiny = 0;
	public static final int SPIN_MODEL = 100;

	private int scalex = 4096;
	private int scaley = 4096;
	private int scalez = 4096;
	public static final int SCALE_MODEL = 256;

	private Light light;
	private boolean lightEnabled;
	private Vector3D lightdir = new Vector3D(-3511, 731, 878); // Light vector
	private final int dirIntensity = 4096; // Light intensity
	private final int ambIntensity = 2048; // Ambient light intensity

	static final Command Light_CMD = new Command("Light", Command.EXIT, 2);
	static final Command Perspective_CMD = new Command("Perspective", Command.SCREEN, 1);

	private boolean persEnabled;
	private final static int persNear = 1;
	private final static int persFar = 4096;
	private final static int persAngle = 682;

	private ActionTable action[] = new ActionTable[2];
	private int actNo;
	private int frame = 0;

	private Figure figureBg;

	private int bgColor = 0x333377; //background

	//----------------------------------------------------------
	// MainCanvas
	//----------------------------------------------------------
	public Canvas3D() throws IOException {
		super();
		g3 = new Graphics3D();
		figure = new Figure("/test_model_robo.mbac");
		mainTexture = new Texture("/tex_001.bmp", true);
		figure.setTexture(mainTexture);

		effect = new Effect3D( null, Effect3D.NORMAL_SHADING, true, null);
		layout = new FigureLayout();

		viewTrans = new AffineTrans();
		modelTrans = new AffineTrans();
		tempTrans = new AffineTrans();

		light = new Light(lightdir, dirIntensity, ambIntensity);
		addCommand(Light_CMD);
		addCommand(Perspective_CMD);
		setCommandListener(this);

		action[0] = new ActionTable("/action_01.mtra");
		action[1] = new ActionTable("/action_02.mtra");

		figureBg = new Figure("/test_model_haikei.mbac");

		centerX = getWidth() / 2;
		centerY = getHeight() / 2;
	}

	//------------------------------------------------------
	// run
	//------------------------------------------------------
	public void run() {
		while (true) {
			repaint();
			try {
				Thread.sleep(100);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}

	//------------------------------------------------------
	// initViewParams
	//------------------------------------------------------
	// initialization
	private void initViewParams() {
		viewTrans.lookAt(Pos, Look, Up);
		modelTrans.setIdentity();
	}

	//------------------------------------------------------
	// keyPressed
	//------------------------------------------------------
	protected void keyPressed(int kc) {
		switch (kc) {
		case Canvas.KEY_NUM4: // movel left
			modelx -= MOVE_MODEL;
			break;
		case Canvas.KEY_NUM6: // move right
			modelx += MOVE_MODEL;
			break;
		case Canvas.KEY_NUM2: // move up
			modely -= MOVE_MODEL;
			break;
		case Canvas.KEY_NUM8: // move down
			modely += MOVE_MODEL;
			break;
		case Canvas.KEY_NUM7: // zoom in
			scalex += SCALE_MODEL;
			scaley += SCALE_MODEL;
			scalez += SCALE_MODEL;
			break;
		case Canvas.KEY_NUM9: // zoom out
			scalex -= SCALE_MODEL;
			scaley -= SCALE_MODEL;
			scalez -= SCALE_MODEL;
			break;
		case Canvas.KEY_NUM1: // action
			actNo = 1;
			frame = 0;
			break;
		default:
			kc = getGameAction(kc);
			switch (kc) {
			case Canvas.UP: // roll up
				spinx -= SPIN_MODEL;
				break;
			case Canvas.DOWN: // roll down
				spinx += SPIN_MODEL;
				break;
			case Canvas.LEFT: // roll left
				spiny -= SPIN_MODEL;
				break;
			case Canvas.RIGHT: // roll right
				spiny += SPIN_MODEL;
				break;
			default:
				break;
			}
			while(spinx >= 4096) spinx -= 4096;
			while(spinx < 0) spinx += 4096;
			break;
		}
	}

	//------------------------------------------------------
	// commandAction
	//------------------------------------------------------
	public void commandAction(Command c, Displayable s) {
		if(c == Light_CMD) {
			if(lightEnabled){
				lightEnabled = false;
			}else{
				lightEnabled = true;
			}
		}else if(c == Perspective_CMD){
			if(persEnabled){
				persEnabled = false;
			}else{
				persEnabled = true;
			}
		}
	}

	//------------------------------------------------------
	// paint
	//------------------------------------------------------
	protected void paint(Graphics g) {
		g.setColor(bgColor);
		g.fillRect(0, 0, getWidth(), getHeight());

		//3D rendering
		g3.bind(g);
		initViewParams();
		if(lightEnabled){
			effect.setLight(light);
		}else{
			effect.setLight(null);
		}
		layout.setCenter(centerX, centerY);
		if(persEnabled){
			layout.setPerspective(persNear, persFar, persAngle);
		}else{
			layout.setParallelSize(800, 800);
		}
		modelTrans.rotationX(spinx);
		tempTrans.setIdentity();
		tempTrans.rotationY(spiny);
		modelTrans.mul(tempTrans);
		tempTrans.set(scalex, 0, 0, 0, 0, scaley, 0, 0, 0, 0, scalez, 0);
		modelTrans.mul(tempTrans);
		modelTrans.m03 = modelx;
		modelTrans.m13 = modely;
		modelTrans.m23 = modelz;
		viewTrans.mul(modelTrans);
		layout.setAffineTrans(viewTrans);
		frame += action[actNo].getNumFrames(0)/10;
		if( frame >= action[actNo].getNumFrames(0) ){
			frame = 0;
			actNo = 0;
		}
		figure.setPosture(action[actNo], 0, frame);
		g3.renderFigure(figure, 0, 0, layout, effect);
		initViewParams();
		modelTrans.m03 = 0;
		modelTrans.m13 = 400;
		modelTrans.m23 = -500;
		viewTrans.mul(modelTrans);
		layout.setAffineTrans(viewTrans);
		g3.renderFigure(figureBg, 0, 0, layout, effect);
		g3.flush();
		g3.release(g);
	}
}
