import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import com.mascotcapsule.micro3d.v3.*;
/**
 * Sample2
 */
public class Main extends MIDlet {
	private Canvas3D canvas;

	//------------------------------------------------------
	// startApp
	//------------------------------------------------------
	public void startApp() {
		try {
			Display d = Display.getDisplay(this);
			canvas = new Canvas3D();
			d.setCurrent(canvas);

			Thread runner = new Thread(canvas);
			runner.start();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void pauseApp() {}
	public void destroyApp(boolean u) {}
}

/**
 * Canvas3D
 */
final class Canvas3D extends Canvas implements Runnable{
	private Graphics3D g3;

	private Figure figure;
	private FigureLayout layout;
	private Texture mainTexture;

	private Effect3D effect;
	private AffineTrans viewTrans;
	private AffineTrans modelTrans;

	private int centerX;
	private int centerY;

	//Viewpoint
	private static Vector3D Pos = new Vector3D(0,120,500);
	private static Vector3D Look = new Vector3D(0,0,-2000);
	private static Vector3D Up = new Vector3D(0,4096,0);

	private int modelx = 0;
	private int modely = 0;
	private int modelz = 0;
	public static final int MOVE_MODEL = 10;

	private int bgColor = 0x333377; //background

	//----------------------------------------------------------
	// MainCanvas
	//----------------------------------------------------------
	public Canvas3D() throws IOException {
		super();
		g3 = new Graphics3D();
		figure = new Figure("/test_model_robo.mbac");
		mainTexture = new Texture("/tex_001.bmp", true);
		figure.setTexture(mainTexture);

		effect = new Effect3D( null, Effect3D.NORMAL_SHADING, true, null);
		layout = new FigureLayout();

		viewTrans = new AffineTrans();
		modelTrans = new AffineTrans();

		centerX = getWidth() / 2;
		centerY = getHeight() / 2;
	}

	//------------------------------------------------------
	// run
	//------------------------------------------------------
	public void run() {
		while (true) {
			repaint();
			try {
				Thread.sleep(100);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}

	//------------------------------------------------------
	// initViewParams
	//------------------------------------------------------
	// initialization
	private void initViewParams() {
		viewTrans.lookAt(Pos, Look, Up);
		modelTrans.setIdentity();
	}

	//------------------------------------------------------
	// keyPressed
	//------------------------------------------------------
	protected void keyPressed(int kc) {
		switch (kc) {
		case Canvas.KEY_NUM4: // movel left
			modelx -= MOVE_MODEL;
			break;
		case Canvas.KEY_NUM6: // move right
			modelx += MOVE_MODEL;
			break;
		case Canvas.KEY_NUM2: // move up
			modely -= MOVE_MODEL;
			break;
		case Canvas.KEY_NUM8: // move down
			modely += MOVE_MODEL;
			break;
		default:
			break;
		}
	}

	//------------------------------------------------------
	// paint
	//------------------------------------------------------
	protected void paint(Graphics g) {
		g.setColor(bgColor);
		g.fillRect(0, 0, getWidth(), getHeight());

		//3D rendering
		g3.bind(g);
		initViewParams();
		layout.setCenter(centerX, centerY);
		layout.setParallelSize(800, 800);
		modelTrans.m03 = modelx;
		modelTrans.m13 = modely;
		modelTrans.m23 = modelz;
		viewTrans.mul(modelTrans);
		layout.setAffineTrans(viewTrans);
		g3.renderFigure(figure, 0, 0, layout, effect);
		g3.flush();
		g3.release(g);
	}
}
