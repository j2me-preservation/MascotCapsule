/*****************************************************************************
 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2005.

 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license
 agreement which accompanies or is included with the software. The software is
 provided "as is" and Sony Ericsson specifically disclaim any warranty or
 condition whatsoever regarding merchantability or fitness for a specific
 purpose, title or non-infringement. No warranty of any kind is made in
 relation to the condition, suitability, availability, accuracy, reliability,
 merchantability and/or non-infringement of the software provided herein.
 *****************************************************************************/

import javax.bluetooth.*;
import com.mascotcapsule.micro3d.v3.Vector3D;

public interface BTTalkerObserver
{
  final static int DISCONNECT = 1;
  final static int CONNECTING = 2;
  final static int CONNECT    = 3;

  public int getState();
  public void startWorking3D(boolean aIsSingleMode);
  public void startMultiRace();
  public void setDisconnected();

  public void updateString(String aStr);
  public void updateAvatarValues(int aX, int aY, int aAngY, int aVx, int aVy);
  public void updateOnColisionSignal(int aPosX, int aPosY, int aRY, int aVx, int aVy);
  public void colisionConfirmed(Vector3D aAvatarPos, int aAwRY, 
                                Vector3D aAvatarSpeed, Vector3D aCarSpeed);
  public void colisionNone(Vector3D aMyCarPos, int aAngZ, Vector3D aMyCarSpeedVect);
}

