/*****************************************************************************
 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2005.

 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license
 agreement which accompanies or is included with the software. The software is
 provided "as is" and Sony Ericsson specifically disclaim any warranty or
 condition whatsoever regarding merchantability or fitness for a specific
 purpose, title or non-infringement. No warranty of any kind is made in
 relation to the condition, suitability, availability, accuracy, reliability,
 merchantability and/or non-infringement of the software provided herein.
 *****************************************************************************/

import javax.bluetooth.*;
import java.io.IOException;
import javax.microedition.io.*;
import java.util.*;

/**
 * BTClient starts a bluetooth client connection and 
 * attempts to connect to the server on the specified remote device.
 * Handles the client-specific funcionality.
 */
class BTClient extends Thread
{
  private BTConectionObserver observer;
  private L2CAPConnection conn = null;
  private ServiceRecord record;
  private String url;


  public BTClient(BTConectionObserver aObserver, ServiceRecord record)
  {
    System.out.println("Client constructor");
    try {
      this.observer = aObserver;
      this.record = record;
    }
    catch(Exception e) {
      System.out.println("EClient01 err: " + e);
    }
  }

  public BTClient(BTConectionObserver aObserver, String aUrl)
  {
    System.out.println("Client constructor");
    try {
      this.observer = aObserver;
      this.url = aUrl;
      System.out.println("url: " + url);
    }
    catch(Exception e) {
      System.out.println("EClient02 err: " + e);
    }
  }

  public void run()
  {
    System.out.println("Client: running");
    try {
      // check if parameters for connection are ok
      if(url == null)
      {
        if (record == null) {
          System.out.println("No record!");
          return;
        }
        int security = ServiceRecord.AUTHENTICATE_NOENCRYPT;
        boolean master = false;
        url = record.getConnectionURL(security, master);
      }
      int index = url.indexOf(':');
      String protocol= url.substring(0, index);
      // Must be L2CAPP
      if (!protocol.equals("btl2cap"))
      {
        System.out.println("Wrong protocol: " + protocol);
        return;
      }
      System.out.println("Client: open connection");
      // Open connection with the server
      conn = (L2CAPConnection)Connector.open(url);
      observer.setConnected(conn);
    }
    catch (Exception e) {
      System.out.println("EClient03 err: " + e.getMessage());
    }
  }

  // Close down the client and notify observer to switch state to disconnected.
  public void close()
  {
    if (conn == null)
      return;

    try {
      conn.close();
    }
    catch (IOException e) {}

    conn = null;
    observer.setDisconnected();
  }

}

