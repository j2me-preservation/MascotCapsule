import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;


public interface RoadDef
{
  // BASE VARIABLES used to build road polygons
  final static int KSize = 160;
  // half of borders thicknes
  final static int KSm = 20;
  // size of triangle longest side, also length of longer border
  final static int KDiag = (int)Math.sqrt(2*(KSize*KSize));
  // half of borders height
  final static int DSm = 2*KSm;

  // Car's starting position on Y
  final static int mGameInitY = -5000;
  // all game's elements uses this value to set position on Z
  final static int KDistance = -380-5;
  // raduis length - outside of this circle road units become invisible
  final static int KOutScreen = 640;
  // Half of car's width, used to set road unit side's collision points used 
  // later in obtaining car-road unit side colision. 
  final static int KCarHalf = 25;
  // vector( +/-KOff, +/-KOff) - used to move longer border along triangle's longer side
  final static int KOff = (int)(Math.sqrt((KSm*KSm)/2));

////////////////////////////////////////////////////////////////////////////////
// triangle specific definitions

  final int mTriNorm[] = {0, 0, 4096};
  final int mTriTex[] = {0, 192,   255, 192,   255, 0};

  // triangle "down-right"
  final  int mVertTriDnR[] = {-KSize, -KSize, 0,
                               KSize, -KSize, 0,
                              -KSize,  KSize, 0};
  // triangle "down-left"
  final  int mVertTriDnL[] = {-KSize, -KSize, 0,
                               KSize, -KSize, 0,
                               KSize,  KSize, 0};
  // triangle "up-right"
  final  int mVertTriUpR[] = {-KSize, -KSize, 0,
                              -KSize,  KSize, 0,
                               KSize,  KSize, 0};
  // triangle "up-left"
  final  int mVertTriUpL[] = { KSize, -KSize, 0,
                              -KSize,  KSize, 0,
                               KSize,  KSize, 0};

///////////////////////////////////////////////////////////////////////////////
// sides (road borders) specific definitions

  final static int[] mSideNorm = {
     0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,
    -4096, 0, 0,   -4096, 0, 0,   -4096, 0,  0,
     4096, 0, 0,    4096, 0, 0,    4096, 0,  0,
     0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0};

  // Coordinates on 2D BMP image to be mapped onto the cube's faces.
  final static int[] mSideTex = {
     96, 0,    0, 0,    96, 96,    0, 0,    96, 96,    0, 96,
     96, 0,    0, 0,    96, 96,
     0, 0,    96, 96,    0, 96,
     96, 0,    0, 0,    96, 96,    0, 0,    96, 96,    0, 96 };

  // short side (road border for units 0,1,2,3 ) - triangle shorter size
  final static int[] mVertSideShort = {
    KSize, KSm, DSm,  -KSize, KSm, DSm,   KSize,-KSm, DSm,  -KSize, KSm, DSm,   KSize,-KSm, DSm,  -KSize,-KSm, DSm,  // front
   -KSize, KSm, DSm,  -KSize, KSm,   0,  -KSize,-KSm, DSm,  // left
    KSize, KSm, DSm,   KSize, KSm,   0,   KSize,-KSm, DSm,  // right
    KSize, KSm,   0,  -KSize, KSm,   0,   KSize, KSm, DSm,  -KSize, KSm,   0,   KSize, KSm, DSm,  -KSize, KSm, DSm}; // top

  // long side (road border for units 4,5,6,7 )- triangle diagonal
  final static int[] mVertSideLong = {
    KDiag, KSm, DSm,  -KDiag, KSm, DSm,   KDiag,-KSm, DSm,  -KDiag, KSm, DSm,   KDiag,-KSm, DSm,  -KDiag,-KSm, DSm,  // front
   -KDiag, KSm, DSm,  -KDiag, KSm,   0,  -KDiag,-KSm, DSm,  // left
    KDiag, KSm, DSm,   KDiag, KSm,   0,   KDiag,-KSm, DSm,  // right
    KDiag, KSm,   0,  -KDiag, KSm,   0,   KDiag, KSm, DSm,  -KDiag, KSm,   0,   KDiag, KSm, DSm,  -KDiag, KSm, DSm}; // top

 
}


