import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Main canvas - used to create, manage and display 3D world
 */
public class Race_Canvas3D extends GameCanvas implements CommandListener
{
  private Race_Main app;    // reference to main appplication class
  Command exitCommand;      // Soft keys

  // constants
  private final int WIDTH, HEIGHT;              // screen coordinates
  private final static int KMaxSpeed = 40;      // maximum speed car can have
  private final static int KAccelerateSpeed = 4;// accelerate with this value
  private final static int KBreakSpeed = 10;    // brake with this speed value
  private final static int KRotStep = 200;      // turn car and camera step
  private final static int KShiftWord = 30;     // to shift camera position
  float KDegreeFactor = (360.0f/4096.0f);       // used for calculating degrees

  // precalculated table of sin and cos values: 0-360 degrees
  float[] sinTab;
  float[] cosTab;

  private Light light = new Light(new Vector3D(-146, 293, 439), 3730, 1626 );
  private Effect3D effect = new Effect3D();

  // variables used to init camera position
  private Vector3D POS = new Vector3D(0, RoadDef.mGameInitY, -RoadDef.KDistance+15);
  private Vector3D LOOK  = new Vector3D(0, 0, -4096);
  private Vector3D UP    = new Vector3D(0, 4096, 0);
  private int pers = 512;    // angle of visible space

  // transformates used to control camera position and orientation
  private AffineTrans mCamMove = new AffineTrans();
  private AffineTrans mCamRotZ = new AffineTrans();
  private AffineTrans mCamera = new AffineTrans();
  private int mCamAngleZ = 0;       // camera's current angles
  // if position or rotation was changed, objects need to update themselves according to camera
  private boolean mCamereNeedUpdate = true;

  // true - car goes toward finish; false - car goes back to start position
  private boolean carMoveForward = true;
  // car's speed vector
  private Vector3D carSpeedVect = new Vector3D(0, 0, 0);
  // car's speed value (speed vector length)
  private int carSpeedValue = 0;

  // this is a counter for number of game reiteration step
  private int canvasStepCounter = 0;

  private FPS mFps = new FPS();     // to obtain current frame rate
  private WallContainer road;      // road for our world
  private CarUnit myCar;            // car that can be controled by user

////////////////////////////////////////////////////////////////////////////////
// multi-player part
  private boolean mIsMulti = false; // true - 2 players game, awatar is created
  
  private CarUnit awatarCar = null; // avatar car is our party's car
  private Vector3D awatarSpeedVect = new Vector3D(0, 0, 0);
  private int mAvatarUpdateStep = 0;

  private int mCarTwiceRadSqare = (2*30)*(2*30); // square of twice of car radius

  Vector3D aCarPosVect = new Vector3D(0, 0, 0) ;// current car position, to send to other player
  private boolean mMovingFunctionPending = false;

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  public Race_Canvas3D(Race_Main app, boolean aIsOtherParty, boolean aPosServer)
  {
    super(false);
    this.app = app;
    mIsMulti = aIsOtherParty;

    setFullScreenMode(true);

    exitCommand = new Command("Quit", Command.EXIT, 1);
    addCommand(exitCommand);
    setCommandListener(this);

    effect.setShadingType(Effect3D.NORMAL_SHADING);
    effect.setLight(light);

    // set screen width and height variables
    WIDTH = getWidth();
    HEIGHT = getHeight();

    // init camera
    mCamMove.setIdentity();
    mCamMove.lookAt( POS, LOOK, UP);

    mCamRotZ.setIdentity();
    mCamRotZ.rotationZ(mCamAngleZ);

    mCamera.setIdentity();
    mCamera.mul(mCamRotZ, mCamMove);
    mCamereNeedUpdate = false;

    try {
      // init sin and cos table
      sinTab = new float[361];
      cosTab = new float[361];
      for( int i=0; i<361; ++i )
      {
        sinTab[i] = (float)Math.sin(Math.toRadians((double)i));
        cosTab[i] = (float)Math.cos(Math.toRadians((double)i));
      }
      // build road (road also reads map)
      road = new WallContainer(WIDTH, HEIGHT, mCamera, effect);
      AffineTrans tmpAT = new AffineTrans();
      // if one player game - build only car
      if(!mIsMulti)
        myCar = new CarUnit(0, RoadDef.mGameInitY, RoadDef.KDistance+5,
                            WIDTH, HEIGHT, mCamera, tmpAT, effect);
      // in two players' mode build also awatar
      else
      {
        // Cars are placed both at start line, moved by either +/- 50 on X from
        // initial position. Server's car on one side, client's car on the other.
        if(aPosServer)
        {
          myCar = new CarUnit(50, RoadDef.mGameInitY, RoadDef.KDistance+5,
                              WIDTH, HEIGHT, mCamera, tmpAT, effect);
          moveWorldCam(-50, 0, 0);
          awatarCar = new CarUnit(-50, RoadDef.mGameInitY, RoadDef.KDistance+5,
                                  WIDTH, HEIGHT, mCamera, tmpAT, effect);
        }
        else
        {
          myCar = new CarUnit(-50, RoadDef.mGameInitY, RoadDef.KDistance+5,
                              WIDTH, HEIGHT, mCamera, tmpAT, effect);
          moveWorldCam(50, 0, 0);
          awatarCar = new CarUnit(50, RoadDef.mGameInitY, RoadDef.KDistance+5,
                                  WIDTH, HEIGHT, mCamera, tmpAT, effect);
        }
      tmpAT = null;
      }
    }
    catch (Exception e) {
      System.out.println("ERROR: Race_Canvas3D::Race_Canvas3D()" + e);
    }
    System.out.println("Race_Canvas3D created");
  }

  public void paint( Graphics g )
  {
    g.setColor(0x77AAAA);
    g.fillRect(0,0, WIDTH, HEIGHT);
    Graphics3D g3d = new Graphics3D();

    // before drawing elements, make sure they have updated their positions with relation to camera
    if( mCamereNeedUpdate )
    {
      setCamera();
      road.updateCamPosition(mCamera);
      myCar.updateCamPosition(mCamera);
      if(mIsMulti)
        awatarCar.updateCamPosition(mCamera);
    }
    g3d.bind(g);
    road.render(g3d);
    myCar.render(g3d);
    if(mIsMulti)
      awatarCar.render(g3d);
    g3d.flush();
    g3d.release( g );
    g3d = null;

    // draw some usefull text
    int textPosY = HEIGHT - 30;
    mFps.calculateFps();
    g.setColor(0xFFFFFF);
    g.drawString(mFps.getFpsString(), 0, textPosY, 0);  // frames per second
    g.drawString(myCar.getCarString(), 50, textPosY, 0);// car's X,Y position

    textPosY = HEIGHT - 15;
    g.drawString(road.getRoadString(), 0, textPosY, 0); // no of road units existing
    String str = "Step: " + canvasStepCounter;
    g.drawString(str, 50, textPosY, 0);                 // no of steps since begining of the game
    String strDir;
    if(carMoveForward)
      strDir = "Front";
    else
      strDir = "Back";
    g.drawString(strDir, 140, textPosY, 0);             // car's move on the road direction
    System.gc();
  }

  public void doMove()
  {
    mMovingFunctionPending = true;
    moveObjects();
    mMovingFunctionPending = false;
  }

  public void clearResource()
  {
  }

  // handle soft keys command
  public void commandAction(Command command, Displayable displayable)
  {
    if(command == exitCommand)
    {
      clearResource();
      try {
        app.destroyApp(true);
      }
      catch(Exception e) {}
    }
  }

  public void handleKey()
  {
    int key = getKeyStates();
    if( (key & UP_PRESSED) != 0)      // accelerate
    {
      if(carSpeedValue >= KMaxSpeed)
        return;
      // break faster than normal acceleration
      if( carSpeedValue < 0 )
        carSpeedValue += KBreakSpeed;
      else
        carSpeedValue += KAccelerateSpeed;
      // set top speed limit
      if(carSpeedValue > KMaxSpeed)
        carSpeedValue = KMaxSpeed;
      updateCarMoveDirection(true);
      return;
    }
    if( (key & DOWN_PRESSED) != 0)  // deaccelerate
    {
      if(carSpeedValue <= -KMaxSpeed)
        return;
      if( carSpeedValue > 0 )
        carSpeedValue -= KBreakSpeed;
      else
        carSpeedValue -= KAccelerateSpeed;
      // set top speed limit
      if(carSpeedValue < -KMaxSpeed)
        carSpeedValue = -KMaxSpeed;
      updateCarMoveDirection(true);
      return;
    }
    if( (key & LEFT_PRESSED) != 0)
    {
      myCar.rotate(0, KRotStep, 0);   // turn left
      rotateWorldCam(KRotStep);       // turn left
      updateCarMoveDirection(true);
      return;
    }
    if( (key & RIGHT_PRESSED) != 0)
    {
      myCar.rotate(0, -KRotStep, 0);  // turn right
      rotateWorldCam(-KRotStep);      // turn right
      updateCarMoveDirection(true);
      return;
    }
    if( (key & FIRE_PRESSED) != 0)
    {
      carSpeedValue = 0;
      updateCarMoveDirection(true);
      return;
    }
  }

  // update camera's affine transformation according to current position and angles
  private void setCamera()
  {
    mCamRotZ.setIdentity();
    mCamRotZ.rotationZ(mCamAngleZ);

    mCamera.setIdentity();
    mCamera.mul(mCamRotZ, mCamMove);

    mCamereNeedUpdate = false;
  }

  private void moveWorldCam(int aX, int aY, int aZ)
  {
    mCamereNeedUpdate = true;
    mCamMove.m03 += aX;
    mCamMove.m13 += aY;
    mCamMove.m23 += aZ;
  }

  private void rotateWorldCam(int aZ)
  {
    mCamereNeedUpdate = true;
    mCamAngleZ += aZ;
    mCamAngleZ = mCamAngleZ & 4095;
  }

  // canvas main loop, it performes actual move and colision handling
  private void moveObjects()
  {
    ++canvasStepCounter;
    if( !mIsMulti ) {
      // if single player and speed is 0, car is not moving so no need to carry on
      if( carSpeedValue == 0 )
        return;
    }
    else {
      if( !isCarCollisionWithAvatar() )
        moveAvatar();
      else
      {
        // get current car's position
        myCar.getLocation(aCarPosVect);
        if(app.sendSignalColision(aCarPosVect, myCar.getSpinAngleY(), carSpeedVect))
        {
          // if collision signal message was sent, stop moving to wait for responce
          mAvatarUpdateStep = 0;
          return;
        }
      }
    }
    // check if car collides with road's side borders
    if( !isCarCollidesWithRoadSides() )
    {
      myCar.move(carSpeedVect.x, carSpeedVect.y);
      // camera folows the car
      moveWorldCam(-carSpeedVect.x, carSpeedVect.y, 0);
    }
    try
    {
      // update road - remove invisible parts, add new ones that becomes visible
      road.updateRoad(carMoveForward, myCar.getPosX(), myCar.getPosY(),
                       WIDTH, HEIGHT, mCamera);
      // car shouldn't leave track at the start or the end of the road
      if( road.isOutOnFinish(myCar.getPosY()) || 
          road.isOutOnStart(myCar.getPosY()) )
      {
        // for now, simply set speed to 0
        carSpeedValue = 0;
        UpdateSpeedVect();
      }
    }
    catch (Exception e) {
      System.out.println("moveObjects(): update road err: "+e);
    }
  }

  private void UpdateSpeedVect()
  {
    // car is rotating around Z axis, so move in local car coordinated
    // has to be transformed into move in world coordinates.
    // take negative Y positions
    float x = 0, y = 0;
    float v = (float)KDegreeFactor*(float)(myCar.getSpinAngleY());
    int angle = (int)v;
    x = carSpeedValue*sinTab[angle];
    y = (-carSpeedValue)*cosTab[angle];
    carSpeedVect.x = (int)x;
    carSpeedVect.y = (int)y;
  }

  private Vector3D triPos = new Vector3D(0,0,0);
  // sets which direction (on the road) car is moving - wheather it moves 
  // forward (growing map index) or it moves back (goes back to 0 in map table)
  // function makes sence as long as car is going on a road.
  private void updateCarMoveDirection(boolean aUpdateSpeed)
  {
    if(aUpdateSpeed)
      UpdateSpeedVect();
    if( !mIsMulti && carSpeedValue == 0 )
      return;

    myCar.getLocation(aCarPosVect);
    int dotProd;
    road.getRoadVect(triPos, aCarPosVect);
    dotProd = triPos.innerProduct(carSpeedVect);
    // dotProd = 0, the angle between road is 90 or 180 degrees;
    // for 90 degrees it might be sometimes better to use it as forward
    if(dotProd > 0)
      carMoveForward = true;
    else
      carMoveForward = false;

    if( mIsMulti && aUpdateSpeed )
    {
      app.updateCarRemoteSpeedAndPos(aCarPosVect,
                                     myCar.getSpinAngleY(),
                                     carSpeedVect);
      mAvatarUpdateStep = 0;
    }
  }

  // iterates through all road unit's elements to find if there is collision
  boolean isCarCollidesWithRoadSides()
  {
    int carPosX = myCar.getPosX();
    int carPosY = myCar.getPosY();

    RoadUnit unit;
    for( int i=0; i<road.getRoadCount(); ++i )
    {
      unit = road.getUnit(i);
      if( carDidSideColision(carPosX, carPosY, unit) ) {
        unit = null;
        return true;
      }
    }
    unit = null;
    return false;
  }

  // check if there is collision between car and particular road unit
  Vector3D mCarBefore = new Vector3D(0,0,0);
  Vector3D mCarAfter  = new Vector3D(0,0,0);
  int mDistBefore, mDistAfter;
  private boolean carDidSideColision(int aCarX, int aCarY, RoadUnit aUnit)
  {
    // get vectors from one points belonging to the wall to the car position
    // at the current moment
    mCarBefore.set(aUnit.pointB.x - aCarX, aUnit.pointB.y - aCarY, 0);
    // after moving with move vector
    mCarAfter.set( aUnit.pointB.x - (aCarX + carSpeedVect.x),
                  aUnit.pointB.y - (aCarY + carSpeedVect.y), 0);
    // get dot product of these vectors with wall normal vector
    mDistBefore = mCarBefore.innerProduct(aUnit.sideNorm);
    mDistAfter = mCarAfter.innerProduct(aUnit.sideNorm);
    // if sign is different -> vectors are on the other sides of wall (or on if 0)
    if( mDistBefore >= 0 && mDistAfter <= 0 ||
        mDistBefore <= 0 && mDistAfter >= 0 ) 
    {
      // check if car goes in opposite direction to unit direction vector
      // scalar product between vectors is > 0, angle is: -90<angle<90 degrees
      if( carSpeedVect.innerProduct(aUnit.sideNorm) > 0 )
        return false;
      // scale variables (normal vector uses 1 as 4096)
      int carSpeedX_s = carSpeedVect.x*4096;
      int carSpeedY_s = carSpeedVect.y*4096;

      // get reversed vector to what the car wants be moved this turn
      Vector3D moveVect_s = new Vector3D(-carSpeedX_s, -carSpeedY_s, 0);
      int divisor_s = moveVect_s.innerProduct(aUnit.sideNorm);
      // if move is paraller to wall plane -> no possible colision
      if( divisor_s == 0 )
        return false;

      // calculate the collision point, scale some variables first
      int carX_s = aCarX*4096;
      int carY_s = aCarY*4096;
      // calculate vector from colision point to car position point
      Vector3D distVect_s = new Vector3D(carX_s - aUnit.pointE.x*4096,
                                         carY_s - aUnit.pointE.y*4096, 0);
      // calculate fracture of speed vector that car moves to collision with wall
      float speedPart = (float)distVect_s.innerProduct(aUnit.sideNorm) /
                        (float)divisor_s;
      // collision point: car position point moved with calculated part of speed vector
      Vector3D colPoint = new Vector3D((carX_s+(int)(speedPart*carSpeedX_s))/4096,
                                       (carY_s+(int)(speedPart*carSpeedY_s))/4096,
                                       0);

      // check if collision point is placed inside wall's borders
      if( isCollisionInsideWall(colPoint, aUnit.pointB, aUnit.pointE) )
      {
        doCarColisionResponce(aUnit.side.getSpinAngleZ());
        colPoint = null;
        return true;
      }
      else {
        colPoint = null;
        return false;
      }
    }
    return false;
  }

  // does responce to car's collision with road unit
  private void doCarColisionResponce(int aWallAng)
  {
    // As a responce to car colision, car gets rotated and speed is decreased.
    // Angle is taken from relation between orientation of wall and car movement.
    int carAng = myCar.getSpinAngleY() - 2048;
    if(carAng == -2048)
      carAng = 2048;
    int wallAng = -(aWallAng - 1024);
    int diff = carAng + wallAng;
    if( diff < -4096 )
      diff = wallAng - carAng;
    if( diff < -1024 && diff < 0 )
      diff = 2048 + diff;
    if(diff > 2048)
      diff = carAng - wallAng;
    if( diff > 1024 )
      diff = diff - 1024;
    // Bounce of the wall.
    // I set bounce angle with part of the angle car hit the wall, 
    // just so it is not an "ideal - (2*diff)" colision and "some energy get's lost".
    // This could depend on the speed (i.e. the faster car goes, the more energy
    // gets lost on bang - car gets damaged)
    myCar.rotate(0, -(diff+diff/4), 0);
    // decrease speed value
    carSpeedValue = (carSpeedValue / 4);
    // update speed vector and car move direction with smaller speed value
    updateCarMoveDirection(true);
  }

  // check if collision point (car-road unit) is inside road unit's borders
  private boolean isCollisionInsideWall(Vector3D aTested, Vector3D aPointOne, Vector3D aPointTwo)
  {
      if( aPointOne.x > aPointTwo.x ) {
        if( aPointTwo.x <= aTested.x && aTested.x <= aPointOne.x) {
          if( aPointOne.y > aPointTwo.y ) {
            if( aPointTwo.y <= aTested.y && aTested.y <= aPointOne.y) {
              return true;
            }
            else
              return false;
          }
          else {
            if( aPointOne.y <= aTested.y && aTested.y <= aPointTwo.y) {
              return true;
            }
            else
              return false;
          }
        }
      }
      else {
        if( aPointOne.x <= aTested.x && aTested.x <= aPointTwo.x) {
          if( aPointOne.y > aPointTwo.y ) {
            if( aPointTwo.y <= aTested.y && aTested.y <= aPointOne.y) {
              return true;
            }
            else
              return false;
          }
          else {
            if( aPointOne.y <= aTested.y && aTested.y <= aPointTwo.y ) {
              return true;
            }
            else
              return false;
          }
        }
      }
    return false;
  }

  public void updateAvatar( int aPosX, int aPosY, int aRY, int aVx, int aVy )
  {
    awatarCar.setPositionAndAngle(aPosX, aPosY, aRY);
    awatarSpeedVect.x = aVx;
    awatarSpeedVect.y = aVy;
    // assume awatar moved once while message was sent/received
    awatarCar.move(aVx, aVy);
  }

  private void moveAvatar()
  {
    awatarCar.move(awatarSpeedVect.x, awatarSpeedVect.y);
    // update car's direction periodically, to prevent bad direction used
    ++mAvatarUpdateStep;
    if(mAvatarUpdateStep > 10) {
      myCar.getLocation(aCarPosVect);
      app.updateCarRemoteSpeedAndPos(aCarPosVect, myCar.getSpinAngleY(), carSpeedVect);
      mAvatarUpdateStep = 0;
    }
  }

  private boolean isCarCollisionWithAvatar()
  {
    if(carSpeedVect.x == 0 && awatarSpeedVect.x == 0 &&
       carSpeedVect.y == 0 && awatarSpeedVect.y == 0)
      return false;

    int distX, distY, distance;
    distX = (myCar.move.m03+carSpeedVect.x) - (awatarCar.move.m03+awatarSpeedVect.x);
    distY = (myCar.move.m13+carSpeedVect.y) - (awatarCar.move.m13+awatarSpeedVect.y);
    distance = distX*distX + distY*distY;
    // distance between cars is smaller than their combined radius: we have collision
    if (distance <= mCarTwiceRadSqare )
      return true;
    return false;
  }

  // when collision signal is received, this function handles it.
  public void updateOnColisionSignal(int aPosX, int aPosY, int aRY, int aVx, int aVy)
  {
    System.out.println("received signal, is in updateOnColisionSignal");

    // update out view on awatar's speed and position
    awatarCar.setPositionAndAngle(aPosX, aPosY, aRY);
    awatarSpeedVect.x = aVx;
    awatarSpeedVect.y = aVy;
    mAvatarUpdateStep = 0;

    // If moveObjects() function is processing, let it finish.
    while(true)
    {
      if(!mMovingFunctionPending)
        break;
    }

    // check if there really was collision between cars,
    // assume my car moved once since message was sent by other party
    myCar.move(-carSpeedVect.x, -carSpeedVect.y );
    moveWorldCam(carSpeedVect.x, -carSpeedVect.y, 0);   // camera folows the car

    if( isCarCollisionWithAvatar() )
    {
      // do some collision responce
      carAvatarColisionResponce();

      // Send responce to awatar: car's current position and speed.
      // Tell also awatar its new speed vector after colision.
      myCar.getLocation(aCarPosVect);
      app.sendColisionBetweenCarsConfirmed(aCarPosVect,
                                           myCar.getSpinAngleY(),
                                           carSpeedVect,
                                           awatarSpeedVect);
      System.out.println("updateOnColisionSignal send confirmed");
    }
    else
    {
      myCar.move(carSpeedVect.x, carSpeedVect.y );
      moveWorldCam(-carSpeedVect.x, carSpeedVect.y, 0); // camera folows the car
      // if there was no collision, simply send car's valid parameters
      myCar.getLocation(aCarPosVect);
      app.sendColisionBetweenCarsNone(aCarPosVect, myCar.getSpinAngleY(), carSpeedVect);
      System.out.println("updateOnColisionSignal send none");
    }
  }

  // 1st message that can be received after we've send signal collision message
  public void updateColisionConfirmed(Vector3D aAvatarPos, int aAwRY, 
                                      Vector3D aAvatarSpeed, Vector3D aCarSpeed)
  {
    System.out.println("recived colision CONFIRMATION");

    // update car's speed vector after collision with the value received from other party
    carSpeedVect.set(aCarSpeed);
    carSpeedValue = (int)Math.sqrt( (carSpeedVect.x*carSpeedVect.x) + 
                                    (carSpeedVect.y*carSpeedVect.y) );
    updateCarMoveDirection(false);
    // update avatar's position and speed
    awatarCar.setPositionAndAngle(aAvatarPos.x, aAvatarPos.y, aAwRY);
    awatarSpeedVect.set(aAvatarSpeed);
    mAvatarUpdateStep = 0;
    repaint();
  }

  // 2nd message that can be received after we've send signal collision message
  public void updateColisionNone(Vector3D aAvatarPos, int aAwRY, Vector3D aAvatarSpeed)
  {
    System.out.println("recived colision NONE");

    awatarCar.setPositionAndAngle(aAvatarPos.x, aAvatarPos.y, aAwRY);
    awatarSpeedVect.set(aAvatarSpeed);
    mAvatarUpdateStep = 0;
    repaint();
  }

  // as a colision responce do simple swap of speeds between car and awatar
  private void carAvatarColisionResponce()
  {
  int tmpX = carSpeedVect.x;
  int tmpY = carSpeedVect.y;
  carSpeedVect.x = awatarSpeedVect.x;
  carSpeedVect.y = awatarSpeedVect.y;
  awatarSpeedVect.x = tmpX;
  awatarSpeedVect.y = tmpY;

  carSpeedValue = (int)Math.sqrt( (carSpeedVect.x*carSpeedVect.x) + 
                                  (carSpeedVect.y*carSpeedVect.y) );
  updateCarMoveDirection(false);
  }

}


