import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
  Road unit consist of floor (triangle) and a side border.
  Triangle is simply so we have our road drawn and side is so we do not fall out
  of the road (visible obstacle).
  Side border has a normal vector pointing towards inside of a road.
  It has also two points at the begining and its end (these points basically 
  sets side's borders).
*/
public class RoadUnit
{
  private int mMapPosition = -1;    // this unit position in map array

  public int[] refVertTri;      // reference to triangle array definition
  public int[] refVertSide;     // reference to side border array definition

  public Obstacle triangle;     // road's triangle element (flor object)
  public Obstacle side;         // road's side (border) element

  // normal of side's border towards inside of track, used for colisions
  public Vector3D sideNorm = new Vector3D(0, 0, 0);
  // "begin" corner point of unit's side border
  public Vector3D pointB = new Vector3D(0, 0, 0);
  // "end" corner point of unit's side border
  public Vector3D pointE = new Vector3D(0, 0, 0);

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  public int getMapPosition()   { return mMapPosition; }

  public RoadUnit(int aType, int aMapPosition,
                  int aPosX, int aPosY, 
                  int aWidth, int aHeight,
                  AffineTrans aCamTrans, AffineTrans aTmpAT)
  {
    mMapPosition = aMapPosition;

    int rotZ = 0;
    int sideOffsetX = 0;
    int sideOffsetY = 0;

    // aPosX, aPosY - coordinates of triangle.
    // Unit's side element has to be moved so it is placed along the triangle side,
    // therefore move it with half of triangle width/height. Since side has its 
    // tickness, it has to be moved also by half of this tickness value.
    // Collision points are placed at both ends of side, and moved also by a vector
    // (half of car's width) so car does not penetrate it the border much on colision.
    switch(aType)
    {
      case 0: // side: short, left; triangle: down-right
        // set reference to proper triangle definition
        refVertTri = RoadDef.mVertTriDnR;
        // set reference to proper side border definition
        refVertSide = RoadDef.mVertSideShort;
        // set initial side border rotation
        rotZ = -1024;
        // offset for the side border position, so it is aligned nicely to the road triangle
        sideOffsetX = -RoadDef.KSize-RoadDef.KSm;
        // definition of points that constitutes sides points used as borders
        // in car-side colision detection
        pointB.x = aPosX - RoadDef.KSize + RoadDef.KCarHalf;
        pointB.y = aPosY + RoadDef.KSize + RoadDef.KCarHalf;
        pointE.x = aPosX - RoadDef.KSize + RoadDef.KCarHalf;
        pointE.y = aPosY - RoadDef.KSize - RoadDef.KCarHalf;
        break;
      case 1: // side: short, right; triangle: up-left
        refVertTri = RoadDef.mVertTriUpL;
        refVertSide = RoadDef.mVertSideShort;
        rotZ = 1024;
        sideOffsetX = RoadDef.KSize+RoadDef.KSm;
        pointB.x = aPosX + RoadDef.KSize - RoadDef.KCarHalf;
        pointB.y = aPosY - RoadDef.KSize - RoadDef.KCarHalf;
        pointE.x = aPosX + RoadDef.KSize - RoadDef.KCarHalf;
        pointE.y = aPosY + RoadDef.KSize + RoadDef.KCarHalf;
        break;
      case 2: // side: short, up; triangle: up-right
        refVertTri = RoadDef.mVertTriUpR;
        refVertSide = RoadDef.mVertSideShort;
        rotZ = -2048;
        sideOffsetY = RoadDef.KSize+RoadDef.KSm;
        pointB.x = aPosX + RoadDef.KSize + RoadDef.KCarHalf;
        pointB.y = aPosY + RoadDef.KSize - RoadDef.KCarHalf;
        pointE.x = aPosX - RoadDef.KSize - RoadDef.KCarHalf;
        pointE.y = aPosY + RoadDef.KSize - RoadDef.KCarHalf;
        break;
      case 3: // side: short, down; triangle: down-left
        refVertTri = RoadDef.mVertTriDnL;
        refVertSide = RoadDef.mVertSideShort;
        rotZ = 0;
        sideOffsetY = -RoadDef.KSize-RoadDef.KSm;
        pointB.x = aPosX - RoadDef.KSize - RoadDef.KCarHalf;
        pointB.y = aPosY - RoadDef.KSize + RoadDef.KCarHalf;
        pointE.x = aPosX + RoadDef.KSize + RoadDef.KCarHalf;
        pointE.y = aPosY - RoadDef.KSize + RoadDef.KCarHalf;
        break;
      case 4: // side: long, right-down; triangle: up-right
        refVertTri = RoadDef.mVertTriUpR;
        refVertSide = RoadDef.mVertSideLong;
        rotZ = 512;
        sideOffsetX = RoadDef.KOff;
        sideOffsetY = -RoadDef.KOff;
        pointB.x = aPosX - RoadDef.KSize - RoadDef.KCarHalf;
        pointB.y = aPosY - RoadDef.KSize;
        pointE.x = aPosX + RoadDef.KSize;
        pointE.y = aPosY + RoadDef.KSize + RoadDef.KCarHalf;
        break;
      case 5: // side: long, up-left; triangle: down-left
        refVertTri = RoadDef.mVertTriDnL;
        refVertSide = RoadDef.mVertSideLong;
        rotZ = -1536;
        sideOffsetX = - RoadDef.KOff;
        sideOffsetY = RoadDef.KOff;
        pointB.x = aPosX + RoadDef.KSize + RoadDef.KCarHalf;
        pointB.y = aPosY + RoadDef.KSize;
        pointE.x = aPosX - RoadDef.KSize;
        pointE.y = aPosY - RoadDef.KSize - RoadDef.KCarHalf;
        break;
      case 6: // side: long, down-left; triangle: up-left
        refVertTri = RoadDef.mVertTriUpL;
        refVertSide = RoadDef.mVertSideLong;
        rotZ = -512;
        sideOffsetX = -RoadDef.KOff;
        sideOffsetY = -RoadDef.KOff;
        pointB.x = aPosX - RoadDef.KSize;
        pointB.y = aPosY + RoadDef.KSize + RoadDef.KCarHalf;
        pointE.x = aPosX + RoadDef.KSize + RoadDef.KCarHalf;
        pointE.y = aPosY - RoadDef.KSize;
        break;
      case 7: // side: long, up-right; triangle: down-right
        refVertTri = RoadDef.mVertTriDnR;
        refVertSide = RoadDef.mVertSideLong;
        rotZ = 1536;
        sideOffsetX = RoadDef.KOff;
        sideOffsetY = RoadDef.KOff;
        pointB.x = aPosX + RoadDef.KSize;
        pointB.y = aPosY - RoadDef.KSize - RoadDef.KCarHalf;
        pointE.x = aPosX - RoadDef.KSize - RoadDef.KCarHalf;
        pointE.y = aPosY + RoadDef.KSize;
        break;
    }
    triangle = new Obstacle( aPosX, aPosY, RoadDef.KDistance, 
                             0, 0, 0, aWidth, aHeight, aCamTrans, aTmpAT);

    side = new Obstacle( aPosX+sideOffsetX, aPosY+sideOffsetY, RoadDef.KDistance,
                         0, 0, rotZ, aWidth, aHeight, aCamTrans, aTmpAT);

    // set vector from pointB to pointE
    sideNorm = new Vector3D( pointE.x - pointB.x, pointE.y - pointB.y, 0);
    // set vector from pointB to pointE(moved down on Z)
    Vector3D tmp = new Vector3D( pointE.x - pointB.x, pointE.y - pointB.y, -10);
    // set vector perpendicular to these
    sideNorm.outerProduct(tmp);
    // normalize it to 1 (1 is 4096 in Mascot Capsule)
    sideNorm.unit();
/*
    System.out.println("Type: "+aType+" TRIPos X: "+aPosX+" Y: "+aPosY+
                       " SIDE X:"+(aPosX+sideOffsetX)+" Y:"+(aPosY+sideOffsetY));
    System.out.println("NormVect X: "+sideNorm.x+" Y: "+sideNorm.y+" Z:"+sideNorm.z);
    System.out.println("BEB X:"+pointB.x+" Y:"+pointB.y+" END X:"+pointE.x+" Y:"+pointE.y);
    System.out.println("// -------------------------------------------- //");
*/
  }

  public void updateCamPosition(AffineTrans aCamTrans, AffineTrans tmpAT)
  {
    triangle.updateCamPosition(aCamTrans, tmpAT);
    side.updateCamPosition(aCamTrans, tmpAT);
  }

  // check based on its position, if this unit is visible on the screen
  public boolean isVisible(int aCurrX, int aCurrY, int aOut)
  {
    int diffX = aCurrX - triangle.move.m03;
    int diffY = aCurrY - triangle.move.m13;
    if( diffX > aOut )
      return false;
    if( diffX < -aOut )
       return false;
    if( diffY > aOut )
        return false;
    if(diffY < -aOut )
      return false;
    return true;
  }

}


