import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Car unit - car, its position is controled by user
 * It has limited move and rotation to XY, Z coordinate stays always the same
*/
public class CarUnit extends Obstacle
{
  // references
  private Effect3D refEffect;

  private static Texture texture = null;
  // figure is static, all car objects use the same one
  private static Figure figure = null;

  // temporary affine trans - used in calculation
  private AffineTrans tmpAT = new AffineTrans();

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  public int getPosX()          { return move.m03; }
  public int getPosY()          { return move.m13; }
  public int getSpinAngleY()    { return mSpinAngleY; }

  public CarUnit(int aPosX, int aPosY, int aPosZ,
                 int aWidth, int aHeight,
                 AffineTrans aCamTrans, AffineTrans aTmpTrans, Effect3D aEffect)
  {
    // Rotate car initially around x, than y, so it looks OK,
    // This rotation means also changes of its loocal coordinates.
    super(aPosX, aPosY, aPosZ, 1024, 2048, 0, aWidth, aHeight, aCamTrans, aTmpTrans);

    // assign references
    refEffect = aEffect;

    try
    {
      if(figure == null && texture == null )
      {
        figure = new Figure("/res/model_car.mbac");
        texture = new Texture("/res/tex_car.bmp",true);
        figure.setTexture(texture);
      }
    }
    catch (Exception e) { e.printStackTrace(); }
  }

  public void getLocation(Vector3D aCarPos)
  {
    aCarPos.x = move.m03;
    aCarPos.y = move.m13;
    aCarPos.z = move.m23;
  }

  // car has move limited to 2D only
  public void move(int aPosX, int aPosY)
  {
    move(aPosX, aPosY, 0);
  }

  // car has rotation limited to around Z axis only
  public void rotate(int aRY)
  {
    // car is actually rotating around Z axis,
    // since it has been transformed at construction - that switched its axis
    rotate(0, aRY, 0);
  }

  public void updateCamPosition(AffineTrans aCamTrans)
  {
    updateCamPosition(aCamTrans, tmpAT);
  }

  // draw itself
  public void render(Graphics3D g3d)
  {
    g3d.renderFigure(figure, 0, 0, layout, refEffect);
  }

  // gives some useful information in form of string
  public String getCarString()
  {
    String car_string;
    car_string = "X:" + move.m03 + " Y:" + move.m13;
    return car_string;
  }

  public void setPositionAndAngle(int aPosX, int aPosY, int aRY)
  {
    move.m03 = aPosX;
    move.m13 = aPosY;
    mSpinAngleY = aRY;

    rotX.setIdentity();
    rotX.rotationX(mSpinAngleX);   // rotate X

    rotY.setIdentity();
    rotY.rotationY(mSpinAngleY);   // rotate Y

    rotZ.setIdentity();
    rotZ.rotationZ(mSpinAngleZ);   // rotate Y

    rotX.mul(rotY);
    rotX.mul(rotZ);
  }

}


