import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.*;
import javax.bluetooth.*;
import java.io.IOException;
import java.util.*;
import com.mascotcapsule.micro3d.v3.Vector3D;

/*
 * Main midlet class
 * It creates canvas and call repaint periodically
 */
public class Race_Main extends MIDlet implements CommandListener, BTConectionObserver, BTTalkerObserver
{
  private final static String CMD_OK          = "OK";
  private final static String CMD_CANCEL      = "Cancel";
  private final static String CMD_EXIT        = "Exit";
  private final static String CMD_REFRESH     = "Refresh";
  private final static String CMD_CONNECT     = "Connect";

  private final static String PLAY_SINGLE  = "Single";
  private final static String PLAY_MULTI  = "Multiplayer";

  private final static String CONNECT_CLIENT  = "Client";
  private final static String CONNECT_SERVER  = "Server";

  public static Display display;

  private boolean appIsServer = true;

  private final static int LIST_INIT = 0;
  private final static int LIST_CONNECTING = 1;
  private final static int LIST_CON_SERVER = 2;
  private final static int LIST_CON_CLIENT = 3;
  private List mInitList = new List("Empty", List.EXCLUSIVE);
  private int mListState = 0;
  
  private List deviceList;
  private int state = DISCONNECT;
  private BTDiscovery discoverer = null;
  private BTServer server = null;   // receive data, pass to talker
  private BTClient client = null;   // receive data, pass to talker
  private BTTalker talker;          // receive or send data that it gets

  // 3D part
  public static Race_Canvas3D canvas = null;
  Timer iTimer = new Timer();    // Timer to implement animation

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  public Race_Main()
  {
    display = Display.getDisplay(this);

    mInitList = new List("Play mode:", List.EXCLUSIVE);
    fillList(LIST_INIT);
    mInitList.addCommand(new Command(CMD_OK, Command.OK, 1));
    mInitList.addCommand(new Command(CMD_CANCEL, Command.CANCEL, 2));
    mInitList.addCommand(new Command(CMD_EXIT, Command.EXIT, 9));
  }
  
  public void startApp()
  {
    display.setCurrent(mInitList);
  }
  
  public void pauseApp()
  {
    iTimer.cancel();
  }

  private void resumeGame()
  {
    iTimer = new Timer();
    iTimer.schedule( new MyEnvTimerTask(), 0, 30 ); // Start timer
  }

  public void destroyApp(boolean unconditional) throws MIDletStateChangeException 
  {
    notifyDestroyed();
  }
  
  private void disconnect()
  {
    fillList(LIST_CONNECTING);
    if(state == DISCONNECT) {
      return;
    }
    System.out.println("Disconnecting");
    state = DISCONNECT;

    iTimer.cancel();

    if( talker != null ) {
      talker.stopBeingActive();
      talker = null;
    }
    if( appIsServer && server != null) {
      server.close();
      server = null;
    }
    else if (client != null) {
      client.close();
      client = null;
    }
  }

  private void startBT()
  {
    try {
      // List of avilable devices
      if(deviceList == null)
      {
        deviceList = new List("Select Device", List.EXCLUSIVE);
        deviceList.addCommand(new Command(CMD_OK, Command.OK, 1));
        deviceList.addCommand(new Command(CMD_REFRESH, Command.SCREEN, 5));
        deviceList.addCommand(new Command(CMD_CANCEL, Command.CANCEL, 3));
        deviceList.addCommand(new Command(CMD_EXIT, Command.EXIT, 4));
        deviceList.setCommandListener(this);
      }
      if( discoverer == null )
      {
        discoverer = new BTDiscovery(this, deviceList);
      }
      discoverer.startBluetoothDiscovery();
    } 
    catch (Exception e) {
      System.out.println("ERROR: Race_Main::startBT()" + e);
    }
  }

  private void fillList(int aState)
  {
    mInitList.deleteAll();
    switch (aState)
    {
      case LIST_INIT:
        mInitList.setTitle("Play mode:");
        mInitList.setFitPolicy(List.EXCLUSIVE);
        mInitList.append(PLAY_SINGLE, null);
        mInitList.append(PLAY_MULTI, null);
        mInitList.setCommandListener(this);
        break;

      case LIST_CONNECTING:
        mInitList.setTitle("Connection Mode:");
        mInitList.setFitPolicy(List.EXCLUSIVE);
        mInitList.append(CONNECT_SERVER, null);
        mInitList.append(CONNECT_CLIENT, null);
        mInitList.setCommandListener(this);
        break;

      case LIST_CON_SERVER:
        mInitList.setTitle("Conecting server...");
        mInitList.append("Awaiting client", null);
        break;

      case LIST_CON_CLIENT:
        mInitList.setTitle("Conecting client...");
        mInitList.append("connecting", null);
        break;
    }
    mListState = aState;
    display.setCurrent(mInitList);
  }

  private void startServerMode()
  {
    try {
      if (state != DISCONNECT)
        return;
      fillList(LIST_CON_SERVER);
      // Starts a thread
      server = new BTServer(this);
    } 
    catch (Exception e) {
      System.out.println("ERROR: Race_Main::startServerMode()" + e);
    }
  }

  private void startClientMode()
  {
    try {
      if(state != DISCONNECT)
        return;
      state = CONNECTING;
      fillList(LIST_CON_CLIENT);
      discoverer.searchForServices();
    }
    catch (Exception e) {
      System.out.println("ERROR: Race_Main::startClientMode() " + e);
    }
  }

  // called by canvas - send to other party car's position and speed.
  public void updateCarRemoteSpeedAndPos(Vector3D aMyCarPos, int aAngZ, Vector3D aMyCarSpeedVect)
  {
    try {
      // send message via talker.
      talker.remoteUpdateSpeedAndPos(aMyCarPos, aAngZ, aMyCarSpeedVect, false);
    }
    catch(Exception e) { System.out.println("ERROR, updateCarRemoteSpeedAndPos: " + e); }
  }

  // called by canvas - send to other party car's position and speed and signal
  // that connection is possible.
  // Currenlty, only server can send this message.
  public boolean sendSignalColision(Vector3D aMyCarPos, int aAngZ, Vector3D aMyCarSpeedVect)
  {
    if( !appIsServer )
      return false;
    try
    {
      // pause app, it will be resumed when responce is received.
      pauseApp();
      // send message via talker.
      talker.remoteUpdateSpeedAndPos(aMyCarPos, aAngZ, aMyCarSpeedVect, true);
    }
    catch(Exception e) {
      System.out.println("ERROR, sendSignalColision: " + e);
    }
    return true;
  }

  // called by canvas - send to other party car's position and speed.
  // Also confirm collision, and tell other party it's new speed after collision.
  public void sendColisionBetweenCarsConfirmed(Vector3D aMyCarPos, int aAngZ,
                                               Vector3D aMyCarSpeedVect,
                                               Vector3D aAvatarNewSpeedVect)
  {
    try {
      // send message via talker.
      talker.remoteSendColisionConfirm(aMyCarPos, aAngZ, aMyCarSpeedVect, aAvatarNewSpeedVect);
    }
    catch(Exception e) {
      System.out.println("ERROR, sendColisionBetweenCarsConfirmed: " + e);
    }
  }

  // called by canvas - send to other party car's position and speed.
  // Also add that there was no colision.
  public void sendColisionBetweenCarsNone(Vector3D aMyCarPos, int aAngZ, Vector3D aMyCarSpeedVect)
  {
    try {
      talker.remoteSendColisionNone(aMyCarPos, aAngZ, aMyCarSpeedVect);
    }
    catch(Exception e) {
      System.out.println("ERROR, sendColisionBetweenCarsNone: " + e);
    }
  }

  //////////////////////////////////////////////////////////////////////////////
  // from BTTalkerObserver
  //////////////////////////////////////////////////////////////////////////////
  public int getState()                 { return state; }
  public void setDisconnected()         { disconnect(); }
  public void updateString(String aStr) { mInitList.append(aStr, null); }

  public void startWorking3D(boolean aIsSingleMode)
  {
    try {
      if(aIsSingleMode)
      {
        canvas = new Race_Canvas3D(this, false, false);
        display.setCurrent(canvas);
        iTimer.schedule( new MyEnvTimerTask(), 0, 30 ); // Start timer
      }
      else {
        canvas = new Race_Canvas3D(this, true, appIsServer);
        display.setCurrent(canvas);
        talker.remoteSendReady();
      }
    }
    catch (Exception e) {
      System.out.println("ERROR: Race_Main::startWorking3D()" + e); 
    }
  }

  public void startMultiRace()
  {
    iTimer.schedule( new MyEnvTimerTask(), 0, 30 ); // Start timer
  }

  // received over BT, new awatar values
  public void updateAvatarValues(int aPosX, int aPosY, int aRY, int aVx, int aVy)
  {
    canvas.updateAvatar(aPosX, aPosY, aRY, aVx, aVy);
  }

  // received over BT, new awatar values and signal about collision possible
  public void updateOnColisionSignal(int aPosX, int aPosY, int aRY, int aVx, int aVy)
  {
    pauseApp();
    canvas.updateOnColisionSignal(aPosX, aPosY, aRY, aVx, aVy);
    resumeGame();
  }

  // received over BT, new awatar values, new car's speed and colision was confirmed
  public void colisionConfirmed(Vector3D aAvatarPos, int aAwRY,
                                Vector3D aAvatarSpeed, Vector3D aCarSpeed)
  {
    canvas.updateColisionConfirmed(aAvatarPos, aAwRY, aAvatarSpeed, aCarSpeed);
    resumeGame();
  }

  // received over BT, new awatar values and there was no collision
  public void colisionNone(Vector3D aAvatarPos, int aAwRY, Vector3D aAvatarSpeed)
  {
    canvas.updateColisionNone(aAvatarPos, aAwRY, aAvatarSpeed);
    resumeGame();
  }

  //////////////////////////////////////////////////////////////////////////////
  // from BTConectionObserver
  //////////////////////////////////////////////////////////////////////////////
  public void setConnected(L2CAPConnection aConn)
  {
    try {
      System.out.println("setStateConnected called");
      try {
        talker = new BTTalker(this, aConn, appIsServer);
      }
      catch (Exception e) {
        System.out.println(e);
        disconnect();
      }
      state = CONNECT;

      if( appIsServer )
        mInitList.append("Server started", null);
      else
        mInitList.append("Client started", null);

      talker.remoteSendHello();
      System.out.println("setStateConnected return");
    }
    catch (Exception e) {
      System.out.println("ERROR: Race_Main::setConnected()" + e);
    }
  }

  public void createClient(ServiceRecord aRecord)
  {
    try {
      client = new BTClient(this, aRecord);
      client.start();
    }
    catch (Exception e) {
      System.out.println("Exception: createClient " + e);
    }
    System.out.println("Client created");
  }


  //////////////////////////////////////////////////////////////////////////////
  // from CommandListener
  //////////////////////////////////////////////////////////////////////////////
  public void commandAction(Command c, Displayable s)
  {
    if( c.getCommandType() == Command.EXIT )
    {
      try {
        destroyApp(false);
      }
      catch (MIDletStateChangeException ex) {}
      return;
    }
    if( c.getCommandType() == Command.OK )
    {
      if( s == deviceList && deviceList.size() > 0 )
      {
        startClientMode();
        return;
      }
      switch(mListState)
      {
        case LIST_INIT:
          if( mInitList.getSelectedIndex() == 0 )
          {
            startWorking3D(true);
          }
          else {
            fillList(LIST_CONNECTING);
            startBT();
          }
          break;
        case LIST_CONNECTING:
          if( mInitList.getSelectedIndex() == 0 )
          {
            appIsServer = true;
            startServerMode();
          }
          else {
            appIsServer = false;
            display.setCurrent(deviceList);
          }
          break;
      }
      return;
    }       
    if( c.getCommandType() == Command.CANCEL )
    {
      if(mListState == LIST_CONNECTING)
      {
        discoverer = null;
        deviceList = null;
        fillList(LIST_INIT);
      }
      else
        disconnect();
      return;
    }
    if( c.getLabel().equals(CMD_REFRESH) )
    {
      deviceList.deleteAll();
      discoverer.startBluetoothDiscovery();
    }
  }


  //////////////////////////////////////////////////////////////////////////////
  // class MyEnvTimerTask 
  //////////////////////////////////////////////////////////////////////////////
  class MyEnvTimerTask extends TimerTask
  {
    public void run()
    {
      if( canvas != null ) // If Canvas is present...
      {
        try {
          canvas.handleKey();
          canvas.doMove();
          canvas.repaint();
        }
        catch (Exception e) {
          System.out.println("ERROR: Race_Main::repaint()" + e);
        }
      }
    }
  } // end TimerTask

}
