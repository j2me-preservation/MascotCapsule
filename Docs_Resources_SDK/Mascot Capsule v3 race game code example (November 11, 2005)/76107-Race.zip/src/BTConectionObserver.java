/*****************************************************************************
 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2005.

 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license
 agreement which accompanies or is included with the software. The software is
 provided "as is" and Sony Ericsson specifically disclaim any warranty or
 condition whatsoever regarding merchantability or fitness for a specific
 purpose, title or non-infringement. No warranty of any kind is made in
 relation to the condition, suitability, availability, accuracy, reliability,
 merchantability and/or non-infringement of the software provided herein.
 *****************************************************************************/

import javax.bluetooth.*;  

public interface BTConectionObserver
{
  public static String MY_SERVICE_NUMBER =  "1020304050d0708093a1b121d1e1f100";

  public void setConnected(L2CAPConnection c);
  public void setDisconnected();
  public void createClient(ServiceRecord record);
}

