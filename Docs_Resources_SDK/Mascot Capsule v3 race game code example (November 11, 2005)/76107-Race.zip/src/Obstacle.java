import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Obstacle class - a root of all object placed in our world.
 * It contains object's layout, current position, angles and rotation
 */
public class Obstacle
{
  protected AffineTrans move = new AffineTrans();
  protected AffineTrans rotX = new AffineTrans();
  protected AffineTrans rotY = new AffineTrans();
  protected AffineTrans rotZ = new AffineTrans();
  private AffineTrans trans = new AffineTrans();

  protected FigureLayout layout = new FigureLayout();

  protected int mSpinAngleX = 0;
  protected int mSpinAngleY = 0;
  protected int mSpinAngleZ = 0;


  // returns this object layout
  public FigureLayout getLayout()   { return layout; }
  public int getSpinAngleZ()        { return mSpinAngleZ; }

  // constructor
  public Obstacle(int aPosX, int aPosY, int aPosZ,
                  int aRX, int aRY, int aRZ,
                  int aWidth, int aHeight,
                  AffineTrans aCamTrans, AffineTrans aTmpAT)
  {
    move.setIdentity();
    move(aPosX, aPosY, aPosZ);
    rotate(aRX, aRY, aRZ);

    aTmpAT.setIdentity();
    aTmpAT.mul(move, rotX);

    trans.setIdentity();
    trans.mul(aCamTrans, aTmpAT);

    layout.setAffineTrans( trans );
    layout.setPerspective(1, 14096, 512);
    layout.setCenter(aWidth/2, aHeight/2);
  }

  // construct with simple copy of rotation
  public Obstacle(int aPosX, int aPosY, int aPosZ,
                  int aRX, int aRY, int aRZ,
                  int aWidth, int aHeight,
                  AffineTrans aCamTrans, AffineTrans aTmpAT,
                  AffineTrans aRotX)
  {
    move.setIdentity();
    move(aPosX, aPosY, aPosZ);

    mSpinAngleX += aRX;
    mSpinAngleY += aRY;
    mSpinAngleZ += aRZ;
    rotX = aRotX;

    aTmpAT.setIdentity();
    aTmpAT.mul(move, rotX);

    trans.setIdentity();
    trans.mul(aCamTrans, aTmpAT);

    layout.setAffineTrans( trans );
    layout.setPerspective(1, 14096, 512);
    layout.setCenter(aWidth/2, aHeight/2);
  }

  // update objects position according to camera
  public void updateCamPosition(AffineTrans aCamTrans, AffineTrans aTmpAT)
  {
    aTmpAT.setIdentity();
    aTmpAT.mul(move, rotX);

    trans.setIdentity();
    trans.mul(aCamTrans, aTmpAT);
  }

  // move object
  public void move(int aPosX, int aPosY, int aPosZ)
  {
    move.m03 += aPosX;
    move.m13 += aPosY;
    move.m23 += aPosZ;
  }

  // rotate object
  public void rotate(int aRX, int aRY, int aRZ)
  {
    mSpinAngleX += aRX;
    mSpinAngleY += aRY;
    mSpinAngleZ += aRZ;

    if(mSpinAngleX >= 2048)
        mSpinAngleX = mSpinAngleX - 4096;
    else if( mSpinAngleX <= -2048 )
        mSpinAngleX = mSpinAngleX + 4096;

    mSpinAngleY = mSpinAngleY & 4095;
    mSpinAngleZ = mSpinAngleZ & 4095;

    rotX.setIdentity();
    rotX.rotationX(mSpinAngleX);   // rotate X

    rotY.setIdentity();
    rotY.rotationY(mSpinAngleY);   // rotate Y

    rotZ.setIdentity();
    rotZ.rotationZ(mSpinAngleZ);   // rotate Y

    rotX.mul(rotY);
    rotX.mul(rotZ);
  }

}


