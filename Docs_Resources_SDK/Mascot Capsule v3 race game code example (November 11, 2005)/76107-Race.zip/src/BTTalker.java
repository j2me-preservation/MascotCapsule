/*****************************************************************************
 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2005.

 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license
 agreement which accompanies or is included with the software. The software is
 provided "as is" and Sony Ericsson specifically disclaim any warranty or
 condition whatsoever regarding merchantability or fitness for a specific
 purpose, title or non-infringement. No warranty of any kind is made in
 relation to the condition, suitability, availability, accuracy, reliability,
 merchantability and/or non-infringement of the software provided herein.
 *****************************************************************************/

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.bluetooth.*;
import java.io.IOException;
import java.util.*;
import com.mascotcapsule.micro3d.v3.Vector3D;

/*
 * After conection is established, this class handles actual 
 * sending and receiving of information.
 * Messages always starts with a "command type".
 * Handling of received messages is based on a type of the "command".
*/
public class BTTalker
{
  BTTalkerObserver observer;
  private L2CAPConnection conn;

  private static byte BTCMD_SAY_HELLO            = 0x01;
  private static byte BTCMD_UPDATE_SPEED_AND_POS = 0x02;
  private static byte BTCMD_START_3D_WORLD       = 0x03;
  private static byte BTCMD_READY_FOR_PLAY       = 0x04;
  private static byte BTCMD_COLISION_SIGNAL      = 0x05;
  private static byte BTCMD_COLISION_CONFIRM     = 0x06;
  private static byte BTCMD_COLISION_NONE        = 0x07;

  private boolean receivingStarted = false;
  private boolean appIsServer = true;

  // Receive processing
  private Vector receiveDataStack = new Vector();
  private byte receiveBuf[] = null;
  private int receiveIndex = 0;

  // Transmit processing
  private Vector sendDataStack = new Vector();
  private byte transmitBuffer[];
  private int transmitIndex = 0;

  private static boolean amIReady    = false;
  private static boolean avatarReady = false;

  private BtReceiveThread mBtReceiver;
  private BtReaderThread mBtReader;

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  public BTTalker( BTTalkerObserver aObserver,
                   L2CAPConnection aConn,
                   boolean aAppIsServer )
  {
    this.observer = aObserver;
    this.conn = aConn;
    this.appIsServer = aAppIsServer;

    try {
      // buffer with maximum number of bytes that can be sent in a single send()
      transmitBuffer = new byte[conn.getTransmitMTU()];
      transmitIndex = 2;  // reserve first 2 bytes for length of payload

      // thread for receiving data from other party
      mBtReceiver = new BtReceiveThread();
      mBtReceiver.start();
      // thread for reading (and proccessing) of received data
      mBtReader = new BtReaderThread();
      mBtReader.start();
    }
    catch (Exception e) {
      System.out.println("ERROR: BTTalker::BTTalker()" + e);
    }
  }

  // this class is used to start receiving data from BT connection
  class BtReceiveThread extends Thread
  {
    public void run()
    {
      startAndDoReceive();
    }
  }

  // this function receives data from BT connection
  void startAndDoReceive()
  {
    if( receivingStarted == true )
      return;

    receivingStarted = true;

    try {
      System.out.println("Starting Server");
      byte[] data = null;
      int length;
      // get maximum number of bytes that can be read in a single receive()
      length = conn.getReceiveMTU();
      data = new byte[length];
      length = conn.receive(data);
      // receiving of information from other party is performed in this loop
      while (length != -1)
      {
        receiveData(data, length);
        try {
          length = conn.receive(data);
        }
        catch (IOException e) {
          System.out.println("ETalk01 err: reading: " + e);
          break;
        }
      }
      data = null;
    }
    catch(Exception e) {
      System.out.println("ETalk02 err: " + e);
    }
    finally {
      System.out.println("Close receiving");
      observer.setDisconnected();
    }   
  }

  // class that is used to start reading information from data received over BT
  class BtReaderThread extends Thread
  {
    public void run() {
      handleReadData();
    }
  }

  // read (and proccess) data received from BT connection
  private void handleReadData()
  {
    byte b;
    while(true)
    {
      b = read();
      if( b == BTCMD_UPDATE_SPEED_AND_POS ||
          b == BTCMD_COLISION_SIGNAL ||
          b == BTCMD_COLISION_NONE )
      {
        int x = 0, y = 0, angY = 0, vX = 0, vY = 0;
        int e, f, g, h;
        boolean isNegative;
        for( int i=0; i<5; ++i )
        {
          isNegative = false;
          e = (int)read();
          f = (int)read();
          g = (int)read();
          h = (int)read();
          if( e == -1 ) {
            isNegative = true;
            if( f < 0 ) f = 256 + f;
            if( g < 0 ) g = 256 + g;
            if( h < 0 ) h = 256 + h;
          }
          e = (e << 24);
          f = (f << 16);
          g = (g << 8);
          if( !isNegative ) {
            if( e < 0 ) e = 256 + e;
            if( f < 0 ) f = 256 + f;
            if( g < 0 ) g = 256 + g;
            if( h < 0 ) h = 256 + h;
          }
          switch(i) {
            case 0 : x    = e+f+g+h; break;
            case 1 : y    = e+f+g+h; break;
            case 2 : angY = e+f+g+h; break;
            case 3 : vX   = e+f+g+h; break;
            case 4 : vY   = e+f+g+h; break;
          }
        }
        if( b == BTCMD_UPDATE_SPEED_AND_POS )
          observer.updateAvatarValues(x, y, angY, vX, vY);
        else if( b == BTCMD_COLISION_SIGNAL )
          observer.updateOnColisionSignal(x, y, angY, vX, vY);
        else if ( b == BTCMD_COLISION_NONE )
        {
          Vector3D awPos   = new Vector3D(x, y, 0);
          Vector3D awSpeed = new Vector3D(vX, vY, 0);
          observer.colisionNone(awPos, angY, awSpeed);
        }
      }
      else if( b == BTCMD_COLISION_CONFIRM )
      {
        Vector3D awPos    = new Vector3D(0, 0, 0);
        Vector3D awSpeed  = new Vector3D(0, 0, 0);
        Vector3D carSpeed = new Vector3D(0, 0, 0);
        int angY = 0;
        int e, f, g, h;
        boolean isNegative;
        for( int i=0; i<7; ++i )
        {
          isNegative = false;
          e = (int)read();
          f = (int)read();
          g = (int)read();
          h = (int)read();
          if( e == -1 ) {
            isNegative = true;
            if( f < 0 ) f = 256 + f;
            if( g < 0 ) g = 256 + g;
            if( h < 0 ) h = 256 + h;
          }
          e = (e << 24);
          f = (f << 16);
          g = (g << 8);
          if( !isNegative ) {
            if( e < 0 ) e = 256 + e;
            if( f < 0 ) f = 256 + f;
            if( g < 0 ) g = 256 + g;
            if( h < 0 ) h = 256 + h;
          }
          switch(i) {
            case 0 : awPos.x    = e+f+g+h; break;
            case 1 : awPos.y    = e+f+g+h; break;
            case 2 : angY       = e+f+g+h; break;
            case 3 : awSpeed.x  = e+f+g+h; break;
            case 4 : awSpeed.y  = e+f+g+h; break;
            case 5 : carSpeed.x = e+f+g+h; break;
            case 6 : carSpeed.y = e+f+g+h; break;
          }
        }
        observer.colisionConfirmed(awPos, angY, awSpeed, carSpeed);
      }
      else if (b == BTCMD_SAY_HELLO) {
        observer.updateString("Received: Hello message");
        // if received hello message -> conection is working properly and
        // our 3D world can be started. Tell client to create itself
        if(appIsServer) {
          remoteStart3DWorld();
          observer.startWorking3D(false);
        }
      }
      else if (b == BTCMD_START_3D_WORLD) {
        // only client is able to receive this message
        observer.updateString("Received: start 3D world");
        if( !appIsServer )
          observer.startWorking3D(false);
      }
      else if (b == BTCMD_READY_FOR_PLAY) {
        System.out.println("Received: avatar ready");
        avatarReady = true;
        if(amIReady)
          observer.startMultiRace();
      }
      else {
        System.out.println("Flag corrupted received: " + (int) b);
      }
    }
  }

  // Process data received from BT.
  public void receiveData(byte buf[], int length)
  {
    if (length <= 2) {
      System.out.println("Dropped len=" + length);
      return;
    }

    length = (buf[0] << 8 & 0xFF) | (buf[1] & 0xFF);
    length = length - 2;
    if (length < 0) {
      System.out.println("Dropped adj len=" + length);
      return;
    }

    byte tmp[] = new byte[length];
    for (int i=0; i < length; i++) {
      tmp[i] = buf[i+2];
    }
    synchronized (receiveDataStack) {
      receiveDataStack.addElement(tmp);
      receiveDataStack.notify();
    }
    tmp = null;
  }

  // Read a single byte, blocks if data not available
  private byte read()
  {
    byte rc;
    while (true)
    {
      if (receiveBuf != null)
      {
        rc = receiveBuf[receiveIndex++];
        if (receiveIndex >= receiveBuf.length) {
          receiveBuf = null;
        }
        return rc;
      }
      synchronized (receiveDataStack) {
        while (receiveDataStack.size() == 0 )
        {
          try {
            receiveDataStack.wait();
          }
          catch (InterruptedException e) {}
        }
        receiveBuf = (byte []) receiveDataStack.elementAt(0);
        receiveDataStack.removeElementAt(0);
        receiveIndex = 0;
      }
    }
  }

  public void remoteSendHello()
  {
    if( observer.getState() != observer.CONNECT )
      return;
    byte buf[] = new byte[1];
    buf[0] = BTCMD_SAY_HELLO;
    System.out.println("Sending: Hello message");
    sendDataStack.addElement(buf);
    sendDataIfNecessary();
    buf = null;
    }

  public void remoteStart3DWorld()
  {
    if( observer.getState() != observer.CONNECT )
      return;
    byte buf[] = new byte[1];
    buf[0] = BTCMD_START_3D_WORLD;
    System.out.println("Sending: start 3D world");
    sendDataStack.addElement(buf);
    sendDataIfNecessary();
    buf = null;
    }

  public void remoteSendReady()
  {
    if( observer.getState() != observer.CONNECT )
      return;
    byte buf[] = new byte[1];
    buf[0] = BTCMD_READY_FOR_PLAY;
    System.out.println("Sending: ready for play");
    sendDataStack.addElement(buf);
    sendDataIfNecessary();
    amIReady = true;
    // in case avatar build itself up already
    if(avatarReady)
    {
      System.out.println("avatar already ready");
      observer.startMultiRace();
    }
    buf = null;
    System.gc();
  }

  private static byte mBufPosTab[] = new byte[29];
  public void remoteUpdateSpeedAndPos(Vector3D aMyCarPos, int aAngZ,
                                      Vector3D aMyCarSpeedVect,
                                      boolean aSignalColision)
  {
    if( observer.getState() != observer.CONNECT )
      return;
    if(aSignalColision)
      mBufPosTab[0] = BTCMD_COLISION_SIGNAL;
    else
      mBufPosTab[0] = BTCMD_UPDATE_SPEED_AND_POS;

    int a, b, c, d, tmp = 0, iter = 0;
    iter++;
    for( int i=0; i<5; ++i)
    {
      switch(i) {
        case 0 : tmp = aMyCarPos.x;        break;
        case 1 : tmp = aMyCarPos.y;        break;
        case 2 : tmp = aAngZ;              break;
        case 3 : tmp = aMyCarSpeedVect.x;  break;
        case 4 : tmp = aMyCarSpeedVect.y;  break;
      }
      a = (tmp & 0xFF000000);
      b = (tmp & 0x00FF0000);
      c = (tmp & 0x0000FF00);
      d = (tmp & 0x000000FF);
      a = (a >> 24);
      b = (b >> 16);
      c = (c >> 8);
      mBufPosTab[iter] = (byte)a; iter++;
      mBufPosTab[iter] = (byte)b; iter++;
      mBufPosTab[iter] = (byte)c; iter++;
      mBufPosTab[iter] = (byte)d; iter++;
    }
    write(mBufPosTab, 0, 21);
    sendTransmitBuf();
  }

  public void remoteSendColisionConfirm(Vector3D aMyCarPos, int aAngZ,
                                        Vector3D aMyCarSpeedVect,
                                        Vector3D aAvatarSpeedVect)
  {
    if( observer.getState() != observer.CONNECT )
      return;
    int a, b, c, d, tmp = 0, iter = 0;
    mBufPosTab[0] = BTCMD_COLISION_CONFIRM;
    iter++;
    for( int i=0; i<7; ++i)
    {
      switch(i) {
        case 0 : tmp = aMyCarPos.x;        break;
        case 1 : tmp = aMyCarPos.y;        break;
        case 2 : tmp = aAngZ;              break;
        case 3 : tmp = aMyCarSpeedVect.x;  break;
        case 4 : tmp = aMyCarSpeedVect.y;  break;
        case 5 : tmp = aAvatarSpeedVect.x; break;
        case 6 : tmp = aAvatarSpeedVect.y; break;
      }
      a = (tmp & 0xFF000000);
      b = (tmp & 0x00FF0000);
      c = (tmp & 0x0000FF00);
      d = (tmp & 0x000000FF);
      a = (a >> 24);
      b = (b >> 16);
      c = (c >> 8);
      mBufPosTab[iter] = (byte)a; iter++;
      mBufPosTab[iter] = (byte)b; iter++;
      mBufPosTab[iter] = (byte)c; iter++;
      mBufPosTab[iter] = (byte)d; iter++;
    }
    write(mBufPosTab, 0, 29);
    sendTransmitBuf();
  }

  public void remoteSendColisionNone(Vector3D aMyCarPos, int aAngZ, Vector3D aMyCarSpeedVect)
  {
    if( observer.getState() != observer.CONNECT )
      return;
    int a, b, c, d, tmp = 0, iter = 0;
    mBufPosTab[0] = BTCMD_COLISION_NONE;
    iter++;
    for( int i=0; i<5; ++i)
    {
      switch(i) {
        case 0 : tmp = aMyCarPos.x;        break;
        case 1 : tmp = aMyCarPos.y;        break;
        case 2 : tmp = aAngZ;              break;
        case 3 : tmp = aMyCarSpeedVect.x;  break;
        case 4 : tmp = aMyCarSpeedVect.y;  break;
      }
      a = (tmp & 0xFF000000);
      b = (tmp & 0x00FF0000);
      c = (tmp & 0x0000FF00);
      d = (tmp & 0x000000FF);
      a = (a >> 24);
      b = (b >> 16);
      c = (c >> 8);
      mBufPosTab[iter] = (byte)a; iter++;
      mBufPosTab[iter] = (byte)b; iter++;
      mBufPosTab[iter] = (byte)c; iter++;
      mBufPosTab[iter] = (byte)d; iter++;
    }
    write(mBufPosTab, 0, 21);
    sendTransmitBuf();
  }

  private void sendDataIfNecessary()
  {
    byte tmp[];
    if( observer.getState() == observer.CONNECT )
    {
      try {
        // Send Drawing messages to peer
        while (sendDataStack.size() > 0)
        {
          tmp = (byte []) sendDataStack.elementAt(0);
          write(tmp, 0, tmp.length);
          sendDataStack.removeElementAt(0);
          tmp = null;
        }
        flush();
      }
      catch (Exception e) {
        System.out.println("ERROR BTTalker::sendDataIfNecessary(): " + e);
      }
    }
  }

  public void write(byte buf[], int offset, int length)
  {
    synchronized (transmitBuffer)
    {
      for (int i = 0; i < length; i++)
      {
        transmitBuffer[transmitIndex++] = buf[offset+i];
        if( transmitIndex >= transmitBuffer.length )
          sendTransmitBuf();
      }
    }
  }

  public void flush()
  {
    synchronized (transmitBuffer)
    {
      // If there is data to send, then send it!
      if (transmitIndex > 2)
        sendTransmitBuf();
    }
  }

  private void sendTransmitBuf()
  {
    if(conn == null)
      return;
    try {
      synchronized (transmitBuffer)
      {
        // Store the length in the first two bytes of the array
        transmitBuffer[0] = (byte) (transmitIndex >> 8 & 0xFF);
        transmitBuffer[1] = (byte) (transmitIndex & 0xFF);
        conn.send(transmitBuffer);
        transmitIndex = 2;
      }
    }
    catch (IOException e) {
      System.out.println("ERROR: conn.send: " + e);
    }
  }

  public void stopBeingActive()
  {
    sendDataStack.removeAllElements();
    mBtReceiver = null;
    mBtReader = null;
    System.gc();
  }

}
