/*****************************************************************************
 COPYRIGHT All rights reserved Sony Ericsson Mobile Communications AB 2005.

 The software is the copyrighted work of Sony Ericsson Mobile Communications AB.
 The use of the software is subject to the terms of the end-user license
 agreement which accompanies or is included with the software. The software is
 provided "as is" and Sony Ericsson specifically disclaim any warranty or
 condition whatsoever regarding merchantability or fitness for a specific
 purpose, title or non-infringement. No warranty of any kind is made in
 relation to the condition, suitability, availability, accuracy, reliability,
 merchantability and/or non-infringement of the software provided herein.
 *****************************************************************************/

import javax.bluetooth.*;  
import java.io.IOException;
import javax.microedition.io.*;

/**
 * A server part of bluetooth comunication.
 * Server is started and waits for client to connect.
 */
class BTServer extends Thread
{
  private BTConectionObserver observer;

  private L2CAPConnection conn = null;
  L2CAPConnectionNotifier server = null;

  private String message = "";


  public BTServer(BTConectionObserver aObserver)
  {
    this.observer = aObserver;
    this.start();
  }

  public void run()
  {
    try {
      System.out.println("Starting Server");
      byte[] data = null;
      int length;
      // Get local device, make it discoverable
      LocalDevice local = LocalDevice.getLocalDevice();
      local.setDiscoverable(DiscoveryAgent.GIAC);
      // create a L2CAP connection notifier
      server = (L2CAPConnectionNotifier)Connector.open("btl2cap://localhost:" +
                                                       observer.MY_SERVICE_NUMBER );
      try {
        boolean connected = false;
        while(!connected) {
          conn = null;
          try {
            conn = server.acceptAndOpen();
          }
          catch (IOException e) {
            System.out.println("EServ01 err: acceptAndOpen: " + e);
            // hammer connecting...
            continue;
          }
          connected = true;
        }
        // Set state to OPEN
        observer.setConnected(conn);
      }
      catch (Exception e) {
        System.out.println("EServ03 err: " + e);
      }
    }
    catch (Exception e) {
      System.out.println("EServ04 err: run(): " + e);
    }
  }

  // Close down the server and notify observer to switch state to disconnected.
  public void close()
  {
    if (conn != null)
    {
      try { conn.close(); }
      catch (IOException e) {}
    }
    if (server != null)
    {
      try { server.close(); }
      catch (IOException e) {}
    }
    conn = null;
    server = null;
    observer.setDisconnected();
    }

}

