import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;
import java.util.*;

/*
 * This class builds road with triangle floor and side borders.
 * Only map has full information no the whole road.
 * Only curently visible part of road is actually created.
 * Road is constantly updated according to car movement and map.
 * First map element is always element 0.
 * Information kept in map is actualy a connection list:
 * - which road unit type should be connected to the current unit 
 *   (according to GetNextUnitType function)
 * - how it should be positioned in relation to the current unit (according to 
 *   GetNextUnitPos function)
 *
 * Map keeps connection, i.e: map[i] == 1 means that we have unit type 1 to
 * which unit type 0 is connected. 
 * Unit type 0 should be moved KUnitDistance on Y in reletion to unit type 1.
*/
public class WallContainer
{
  private Effect3D refEffect;       // reference to effect that should be used

  // triangle's tables references
  int[] refTriNorm = RoadDef.mTriNorm;      // normal vectors
  int[] refTriTex = RoadDef.mTriTex;        // texture coordinates
  // side border's tables references
  int[] refSideNorm = RoadDef.mSideNorm;    // normal vectors
  int[] refSideTex = RoadDef.mSideTex;      // texture coordinates

  private final int COLOR[] = {0x000000};

  // temporary variable, used in calculations
  private AffineTrans tmpAT = new AffineTrans();

////////////////////////////////////////////////////////////////////////////////
// common definition for all roads' triangles
//
  private Texture textureTab;
  private final int COMMAND_TRI = Graphics3D.PDATA_NORMAL_NONE | 
                                  Graphics3D.PDATA_TEXURE_COORD | 
                                  Graphics3D.PRIMITVE_TRIANGLES;

///////////////////////////////////////////////////////////////////////////////
// common definition for all road borders' sides
//
  private Texture textureSide;
  protected static final int COMMAND_SIDE = Graphics3D.PRIMITVE_TRIANGLES | 
                                            Graphics3D.PDATA_NORMAL_PER_VERTEX |
                                            Graphics3D.PDATA_TEXURE_COORD | 
                                            Graphics3D.PDATA_COLOR_NONE;

///////////////////////////////////////////////////////////////////////////////
// members

  // exact distance between folowing road unints
  private final static int KUnitDistance = 2*RoadDef.KSize;
  // screen radius - used to determine when road unit is not visible
  private static int KOutOfScreen = 0;
  // stack to store road units
  private Stack road = new Stack();
  // number of elements in currently created map
  private int mapSize = 0;
  // map array holding information about the order of road units' creation.
  private int[] map;

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

  // get no of road units
  public int getRoadCount()          { return road.size(); }
  // get road unit at given index
  public RoadUnit getUnit(int aIter) { return (RoadUnit)road.elementAt(aIter); }

  public WallContainer(int aWidth, int aHeight, AffineTrans aCamTrans, Effect3D aEffect)
  {
    refEffect = aEffect;
    KOutOfScreen = RoadDef.KOutScreen;
    try {
      textureTab = new Texture("/res/wall_down.bmp", true);
      textureSide = new Texture("/res/wall_side.bmp", true);
      // load map of the road
      loadMap();
      // build initial visible part of the road
      buildRoadOnConstruct(aWidth, aHeight, aCamTrans);
    }
    catch(Exception e) {
      System.out.println("Failed to create Road");
    }
    System.out.println("Road created.");
  }

  // car shouldn't leave track at the begining of the track
  public boolean isOutOnStart(int aCarY)
  {
    RoadUnit unit = (RoadUnit)road.firstElement();
    if( unit.getMapPosition() == -1 && aCarY < unit.triangle.move.m13 )
      return true;
    // did not return before, so is not out of track at its begin.
    return false;
  }

  // car shouldn't leave track at the end of the track
  public boolean isOutOnFinish(int aCarY)
  {
    RoadUnit unit = (RoadUnit)road.lastElement();
    if( unit.getMapPosition() == mapSize-1 && aCarY >= unit.triangle.move.m13 )
      return true;
    // did not return before, so is not out of track at its finish.
    return false;
  }

  // draw road init (triangle floor and side border)
  public void render(Graphics3D g3d)
  {
    RoadUnit unit;
    int elemNo = road.size();
    for( int i=0; i<elemNo; ++i )
    {
      unit = (RoadUnit)road.elementAt(i);
      g3d.renderPrimitives(textureTab, 0, 0, unit.triangle.getLayout(), refEffect,
                           COMMAND_TRI, 1, unit.refVertTri, refTriNorm, refTriTex,
                           COLOR);
      g3d.renderPrimitives(textureSide, 0, 0, unit.side.getLayout(), refEffect,
                           COMMAND_SIDE, 6, unit.refVertSide, refSideNorm, refSideTex,
                           COLOR);
    }
  }

  public void updateCamPosition(AffineTrans aCamTrans)
  {
    RoadUnit unit;
    int elemNo = road.size();
    for( int i=0; i<elemNo; ++i )
    {
      unit = (RoadUnit)road.elementAt(i);
      unit.updateCamPosition(aCamTrans, tmpAT);
    }
  }

  private void buildFirstRoadUnit(int aWidth, int aHeight, AffineTrans aCamTrans)
  {
    RoadUnit unit;
    unit = new RoadUnit( 0, -1, 0, RoadDef.mGameInitY, aWidth, aHeight, aCamTrans, tmpAT);
    road.insertElementAt(unit, 0);
  }

  private void buildRoadOnConstruct(int aWidth, int aHeight, AffineTrans aCamTrans)
  {
    int[] pos = new int[2];
    pos[0] = 0;
    pos[1] = RoadDef.mGameInitY;
    int conNo = 0;
    int unitType = 0;
    // build road
    RoadUnit unit;
    buildFirstRoadUnit(aWidth, aHeight, aCamTrans);

    for( int i=0; i<mapSize; ++i )
    {
      conNo = map[i];
      GetNextUnitPos(conNo, pos);
      if( !isVisible(0, RoadDef.mGameInitY, pos, KOutOfScreen))
        break;
      unitType = GetNextUnitType(conNo);
      unit = new RoadUnit(unitType, i, pos[0], pos[1], aWidth, aHeight, aCamTrans, tmpAT);
      int tmp = i+1;
      road.addElement(unit);
    }
  }

  // this function updates road while car is moving so only visible road units
  // are actually created and taken into account when drawing or colliding.
  private int nextPos[] = new int[2];
  private int[] dif = new int[2];
  public void updateRoad(boolean aMoveForward, int aCarPosX, int aCarPosY,
                         int aWidth, int aHeight, AffineTrans aCamTrans)
  {
    RoadUnit unit;
    int mapPos = 0;
    int conNo = 0;
    int unitType = 0;
    if(aMoveForward)
    {
      // Check if road unit going from begining of road stack becomes invisible,
      // if it does - remove it.
      // Than retry again until stack is empty or there is a visible unit found.
      while(road.size() > 0)
      {
        unit = (RoadUnit)road.firstElement();
        if( !unit.isVisible(aCarPosX, aCarPosY, KOutOfScreen) ) {
          road.removeElementAt(0);
        }
        else
          break;
      }
      // Check if any new road unit at the end of stack becomes visible.
      // Add it on the end if it does.
      // Retry until finding invisible unit or no more elements.
      while(true)
      {
        try {
          unit = (RoadUnit)road.lastElement();
        }
        catch (Exception e) {
          break;
        }
        mapPos = unit.getMapPosition();
        // safety check -> if this is first road unit element (mapPosit == -1)
        if(mapPos == -1)
          mapPos = 0;
        ++mapPos;
        if( mapPos >= mapSize )
          break;
        conNo = map[mapPos];
        nextPos[0] = unit.triangle.move.m03;
        nextPos[1] = unit.triangle.move.m13;
        GetNextUnitPos( conNo, nextPos);
        if(isVisible(aCarPosX, aCarPosY, nextPos, KOutOfScreen) )
        {
          unitType = GetNextUnitType(conNo);
          unit = new RoadUnit(unitType, mapPos, nextPos[0], nextPos[1], 
                              aWidth, aHeight, aCamTrans, tmpAT);
          road.addElement(unit);
        }
        else {
          break;
        }
      }
    } // END if(aMoveForward)
    else 
    {
      // Check if road unit from the end of road stack becomes invisible,
      // if it does - remove it.
      // Than retry again until stack is empty or visible unit id found.
      while(road.size() > 0)
      {
        unit = (RoadUnit)road.lastElement();
        if( !unit.isVisible(aCarPosX, aCarPosY, KOutOfScreen) )
          road.pop();
        else
          break;
      }
      // Check if any new road unit at the start of stack becomes visible.
      // Add it on at begining if it does.
      // Retry until found invisible or no more elements.
      while(true)
      {
        try {
          unit = (RoadUnit)road.firstElement();
        }
        catch (Exception e) {
          break;
        }
        mapPos = unit.getMapPosition();
        // safety check -> if it is first road unit element (mapPosit == -1)
        // than no new one can be put in front
        if(mapPos == -1)
          break;
        conNo = map[mapPos];
        // get the distance that this unit was moved with in relation to its previous unit
        dif[0] = 0;
        dif[1] = 0;
        GetNextUnitPos(conNo, dif);
        // the previous unit gets its position by moving backwards
        nextPos[0] = unit.triangle.move.m03 - dif[0];
        nextPos[1] = unit.triangle.move.m13 - dif[1];
        if(isVisible(aCarPosX, aCarPosY, nextPos, KOutOfScreen) )
        {
          // if curent unit is the second one from the begining
          if( mapPos == 0 )
          {
            buildFirstRoadUnit(aWidth, aHeight, aCamTrans);
          }
          else
          {
            // we take our new unit from previous connection since we build 
            // with indexes going backwards when using our map
            --mapPos;
            conNo = map[mapPos];
            unitType = GetNextUnitType(conNo);
            unit = new RoadUnit(unitType, mapPos, nextPos[0], nextPos[1], 
                                aWidth, aHeight, aCamTrans, tmpAT);
            road.insertElementAt(unit, 0);
          }
        }
        else {
          break;
        }
      } // END while(true)
    } // END else
  }

  // this function returns next unit type based on the current unit's conection type
  private int GetNextUnitType(int aConNo)
  {
    switch(aConNo)
    {
      case 0:  return 1;
      case 1:  return 0;
      case 2:  return 5;
      case 3:  return 7;
      case 4:  return 3;
      case 5:  return 3;
      case 6:  return 6;
      case 7:  return 2;
      case 8:  return 2;
      case 9:  return 4;
      case 10: return 0;
      case 11: return 5;
      case 12: return 2;
      case 13: return 4;
      case 14: return 0;
      case 15: return 2;
      case 16: return 4;
      case 17: return 5;
      case 18: return 7;
      case 19: return 3;
      case 20: return 6;
    }
    return -1; // error
  }

  // Function determines how much next unit should be moved in relation to 
  // the current one
  private void GetNextUnitPos(int aConNo, int[] aPos)
  {
    switch(aConNo)
    {
      case 0:
      case 4:
      case 7:
        // same position, no move in relation to previous unit
        break;
      case 8:
      case 9:
      case 12:
      case 13:
      case 15:
      case 16:
        // increase X
        aPos[0] += KUnitDistance;
        break;
      case 1:
      case 2:
      case 3:
      case 10:
      case 11:
      case 14:
      case 17:
      case 18:
        // increase Y
        aPos[1] += KUnitDistance;
        break;
      case 5:
      case 6:
      case 19:
      case 20:
        // decrease X
        aPos[0] -= KUnitDistance;
        break;
    }
  }

  public boolean isVisible(int aCurrX, int aCurrY, int[] aPos, int aOut)
  {
    int diffX = aCurrX - aPos[0];
    int diffY = aCurrY - aPos[1];
    if( diffX > aOut )
      return false;
    if( diffX < -aOut )
       return false;
    if( diffY > aOut )
        return false;
    if(diffY < -aOut )
      return false;
    return true;
  }

  // gives some useful information in form of string
  public String getRoadString()
  {
    String road_string;
    road_string = "No:" + road.size();
    return road_string;
  }

  // This function is used to determine if car is mowing towards begin or end 
  // of the road.
  // Road vector is simply vector created:
  // - start at road unit position placed closest to the car
  // - points to next road unit position (this can not be the same position, 
  //   since vector would be (0,0,0))
  // Road vector is created slightly different at the end of the road - there 
  // is no "next" road unit.
  public void getRoadVect(Vector3D aRoadVect, Vector3D aCarPosVect)
  {
    RoadUnit unit = (RoadUnit)road.elementAt(0);
    // first, find a triangle that is closest to the car's position
    // this is begining of road vector
    Vector3D from = new Vector3D(unit.triangle.move.m03, unit.triangle.move.m13, 0);
    int distX, distY, distVect, minDist, currMinTriangleIndex;
    distX = from.x - aCarPosVect.x;
    distY = from.y - aCarPosVect.y;
    minDist = distX*distX + distY*distY;
    currMinTriangleIndex = 0;
    for( int i=1; i<road.size(); ++i )
    {
      unit = (RoadUnit)road.elementAt(i);
      // check if next road's unit position is not also my position
      if( (unit.triangle.move.m03 != from.x) || (unit.triangle.move.m13 != from.y) )
      {
        // calculate square distance between position of triangle's and car's
        distX = unit.triangle.move.m03 - aCarPosVect.x;
        distY = unit.triangle.move.m13 - aCarPosVect.y;
        distVect = distX*distX + distY*distY;
        if( distVect < minDist ) {
          minDist = distVect;
          currMinTriangleIndex = i;
          from.set(unit.triangle.move.m03, unit.triangle.move.m13, 0);
        }
      }
    }
    // if distance starts to increase, we've passed car's position
    // now find end of road vector, this should be next triangle's position
    // (if next has the same position, take the one after it...)
    Vector3D to = new Vector3D(from.x, from.y, 0);
    for(int j=currMinTriangleIndex+1; j<road.size(); ++j)
    {
      unit = (RoadUnit)road.elementAt(j);
      if( unit.triangle.move.m03 != from.x || unit.triangle.move.m13 != from.y )
      {
        to.set(unit.triangle.move.m03, unit.triangle.move.m13, 0);
        break;
      }
    }
    // if we did not found any valid end point in front, 
    // find position from previous ones (and swap: "front" becomes "to")
    if( from.x == to.x && from.y == to.y )
    {
      for(int j=currMinTriangleIndex-1; j>0; --j)
      {
        unit = (RoadUnit)road.elementAt(j);
        if( unit.triangle.move.m03 != from.x || unit.triangle.move.m13 != from.y )
        {
          to.set(from.x, from.y, 0);
          from.set(unit.triangle.move.m03, unit.triangle.move.m13, 0);
          break;
        }
      }
    }
    aRoadVect.set( to.x - from.x, to.y - from.y, 0);
  }

  // this function loads our road map. Curently it is simply hardcoded.
  // element 0 always set to 0 !!!
  private void loadMap()
  {
    int timesNo = 4;
    int baseSize = 60;

    mapSize = (baseSize*timesNo)+1;
    map = new int[mapSize];
    map[0] = 0;     // 0-1      // this comment means connection from 0 to 1
    map[1] = 1;     // 1-0      // so it is easier to check with function
    map[2] = 0;     // 0-1      // GetNextUnitType
    map[3] = 2;     // 1-5
    map[4] = 13;    // 5-4
    map[5] = 11;    // 4-5
    map[6] = 13;    // 5-4
    map[7] = 10;    // 4-0
    map[8] = 0;     // 0-1
    map[9] = 3;     // 1-7
    map[10] = 19;   // 7-3
    map[11] = 7;    // 3-2
    map[12] = 5;    // 2-3
    map[13] = 7;    // 3-2
    map[14] = 6;    // 2-6
    map[15] = 18;   // 6-7
    map[16] = 19;   // 7-3
    map[17] = 7;    // 3-2
    map[18] = 6;    // 2-6
    map[19] = 14;   // 6-0
    map[20] = 0;    // 0-1
    map[21] = 1;    // 1-0
    map[22] = 0;    // 0-1
    map[23] = 1;    // 1-0
    map[24] = 0;    // 0-1
    map[25] = 2;    // 1-5
    map[26] = 13;   // 5-4
    map[27] = 11;   // 4-5
    map[28] = 12;   // 5-2
    map[29] = 4;    // 2-3
    map[30] = 8;    // 3-2
    map[31] = 4;    // 2-3
    map[32] = 8;    // 3-2
    map[33] = 4;    // 2-3
    map[34] = 8;    // 3-2
    map[35] = 4;    // 2-3
    map[36] = 9;    // 3-4
    map[37] = 10;   // 4-0
    map[38] = 0;    // 0-1
    map[39] = 2;    // 1-5
    map[40] = 12;   // 5-2
    map[41] = 4;    // 2-3
    map[42] = 9;    // 3-4
    map[43] = 10;   // 4-0
    map[44] = 0;    // 0-1
    map[45] = 3;    // 1-7
    map[46] = 19;   // 7-3
    map[47] = 7;    // 3-2
    map[48] = 6;    // 2-6
    map[49] = 18;   // 6-7
    map[50] = 20;   // 7-6
    map[51] = 17;   // 6-5
    map[52] = 13;   // 5-4
    map[53] = 11;   // 4-5
    map[54] = 13;   // 5-4
    map[55] = 10;   // 4-0
    map[56] = 0;    // 0-1
    map[57] = 3;    // 1-7
    map[58] = 20;   // 7-6
    map[59] = 14;   // 6-0

    // clone the part above couple of times so that road is longer
    int ind = 0;
    for( int i=1; i<timesNo; ++i )
    {
      for( int j=0; j<baseSize; j++ )
      {
        ind = i*(baseSize-1)+j+i;
        map[ind] = map[j];
      }
    }
    map[mapSize-1] = 0;   // 0-1
  }


}

