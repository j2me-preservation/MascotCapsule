import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;
import java.util.Timer;
import java.util.TimerTask;

/*
 * SpinObstacleContainer class.
 * It creates a net of cubes in proper positions.
 * It creates task to rotate all cubes periodically.
 * Every cube gets assigned on construction, how much it will rotate every turn.
 * On redraw (render function) it call every cube to redraw.
 * It calls every cube to update itself according to new camera position when 
 * needed (updateCamPosition)
 */
public class SpinObstacleContainer
{
  private int mTabSize = 0;
  private CubeUnit[] cubes;

  Timer timer = new Timer();    // Timer to implement animation

  // temporary variable, reused in calculations
  private AffineTrans tmpAT = new AffineTrans();


  public SpinObstacleContainer(int aWidth, int aHeight, int aPosZ, int aDelay,
                               AffineTrans aCamTrans, Effect3D aEffect)
  {
    try {
      mTabSize = 16;
      cubes = new CubeUnit[mTabSize];

      int tabIndex = 0;
      for( int i=0; i<4; ++i) {
        for( int j=0; j<4; ++j ) {
          cubes[tabIndex] = new CubeUnit(-650+i*400, 650-j*400, aPosZ,
                                  0, 0, 0, aWidth, aHeight, aCamTrans, tmpAT,
                                  j*10+10, 15, 30, aEffect);
          ++tabIndex;
        }
      }
      timer.schedule( new MyUpdateTimerTask(), 0, aDelay ); // Start timer
    }
    catch(Exception e) {
      System.out.println("Failed to create cubes");
    }
    System.out.println("Obstacles created.");
  }

  public void render(Graphics3D g3d)
  {
    for( int i=0; i<mTabSize; ++i) {
      cubes[i].render(g3d);
    }
  }

  public void updateCamPosition(AffineTrans aCamTrans)
  {
    for( int i=0; i<mTabSize; ++i) {
      cubes[i].updateRotation();
      cubes[i].updateCamPosition(aCamTrans, tmpAT);
    }
  }

  class MyUpdateTimerTask extends TimerTask
  {
    public void run()
    {
      for( int i=0; i<mTabSize; ++i) {
        cubes[i].increaseAngles();
      }
    }
  }

}


