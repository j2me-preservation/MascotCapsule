import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * This class builds cube.
 * Cube has 6 walls:
 * front (z is moved -500) and back (z is moved 500) both not rotated
 * left (x is moved -500) and right (x is moved 500) both rotated via Y axis
 * floor (y is moved -500) an ceiling (y is moved 500) both rotated via X axis
 * Walls are positioned in a way, that camera is in the center
 * Each wall is build from 4x4 bricks. (actually use only half of this)
 * References to bricks are storied in table for easier access.
*/
public class WallContainer
{
  // reference to effect that should be used
  private Effect3D refEffect;

  // table with references to all bricks' layouts, it is used for convienience
  private FigureLayout[] refLayout;
  // table with references to all bricks, it is used for convienience
  private WallUnit[] bricks;

  private final int NORMALS[] = {0, 0, 4096};
  private final int COLOR[] = {0x000000};

  private final int WALL_COMMAND = Graphics3D.PDATA_NORMAL_NONE | 
                                   Graphics3D.PDATA_TEXURE_COORD | 
                                   Graphics3D.PRIMITVE_QUADS;
  // vertices for the brick, one brick consist of 2 triangles (it is a quad)
  private final int mSideSize = 1500;
  private final int mBrickSize = mSideSize/2;
  private final int mHalfBrickSize = 1+mSideSize/4;

  private final  int WALL_POINTS[] = {-mHalfBrickSize, -mHalfBrickSize, 0,
                                       mHalfBrickSize, -mHalfBrickSize, 0,
                                       mHalfBrickSize,  mHalfBrickSize, 0,
                                      -mHalfBrickSize,  mHalfBrickSize, 0};

  // texture coordinates for the brick background
  private final int WALL_TEXTURES[] = {0, 192,
                                       255, 192,
                                       255, 0,
                                       0, 0};
  // table with textures used for drawing walls. 
  // Every wall know which texture number it is using
  private Texture[] textureTab;

  // no of all bricks
  private int mTabSize = 0;

  // temporary variable, reused in calculations
  private AffineTrans tmpAT = new AffineTrans();


///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                             FUNCTIONS                                     //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
  // get no of bricks
  public int getTabSize() { return mTabSize; }

  // constructor
  public WallContainer(int aWidth, int aHeight, AffineTrans aCamTrans, Effect3D aEffect)
  {
    refEffect = aEffect;
    try {
      textureTab = new Texture[3];
      textureTab[0] = new Texture("/res/wall_down.bmp", true);
      textureTab[1] = new Texture("/res/wall_sideA.bmp", true);
      textureTab[2] = new Texture("/res/wall_sideB.bmp", true);

      // we have 6 walls, every one is 4x4 but use only half of them
      mTabSize = (16*6)/2;
      refLayout = new FigureLayout[mTabSize];
      bricks = new WallUnit[mTabSize];
    }
    catch(Exception e) {
      System.out.println("Failed to create wall");
    }
    // build walls
    int offset = mBrickSize + mHalfBrickSize;
    int wallIndex = 0;
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==0 && j%2!=0)|| (i%2!=0 && j%2==0) ) {
              WallUnit front = new WallUnit( i*mBrickSize-offset, j*mBrickSize-offset, -mSideSize,
                                             0, 0, 0, aWidth, aHeight, aCamTrans, tmpAT, 0);
              refLayout[wallIndex] = front.getLayout();
              bricks[wallIndex] = front;
              wallIndex++;
          }
        }
    }
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==1 && j%2!=1)|| (i%2!=1 && j%2==1) ) {
              WallUnit back = new WallUnit( i*mBrickSize-offset, j*mBrickSize-offset, mSideSize,
                                             0, 0, 0, aWidth, aHeight, aCamTrans, tmpAT, 0);
              refLayout[wallIndex] = back.getLayout();
              bricks[wallIndex] = back;
              wallIndex++;
          }
        }
    }
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==0 && j%2!=0)|| (i%2!=0 && j%2==0) ) {
              WallUnit left = new WallUnit( -mSideSize, i*mBrickSize-offset, j*mBrickSize-offset,
                                             0, -1024, 0, aWidth, aHeight, aCamTrans, tmpAT, 1);
              refLayout[wallIndex] = left.getLayout();
              bricks[wallIndex] = left;
              wallIndex++;
          }
        }
    }
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==1 && j%2!=1)|| (i%2!=1 && j%2==1) ) {
              WallUnit right = new WallUnit( mSideSize, i*mBrickSize-offset, j*mBrickSize-offset,
                                             0, 1024, 0, aWidth, aHeight, aCamTrans, tmpAT, 1);
              refLayout[wallIndex] = right.getLayout();
              bricks[wallIndex] = right;
              wallIndex++;
          }
        }
    }
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==0 && j%2!=0)|| (i%2!=0 && j%2==0) ) {
              WallUnit ceiling = new WallUnit( i*mBrickSize-offset, mSideSize, j*mBrickSize-offset,
                                             -1024, 0, 0, aWidth, aHeight, aCamTrans, tmpAT, 2);
              refLayout[wallIndex] = ceiling.getLayout();
              bricks[wallIndex] = ceiling;
              wallIndex++;
          }
        }
    }
    for(int i=0; i<4; ++i)
    {
        for( int j=0; j<4; ++j)
        {
          if( (i%2==1 && j%2!=1)|| (i%2!=1 && j%2==1) ) {
              WallUnit floor = new WallUnit( i*mBrickSize-offset, -mSideSize, j*mBrickSize-offset,
                                             1024, 0, 0, aWidth, aHeight, aCamTrans, tmpAT, 2);
              refLayout[wallIndex] = floor.getLayout();
              bricks[wallIndex] = floor;
              wallIndex++;
          }
        }
    }
    System.out.println("Walls created.");
  }

  public void render(Graphics3D g3d)
  {
    for( int i=0; i<mTabSize; ++i) {
      g3d.renderPrimitives( textureTab[bricks[i].getUseTextureNo()],
                            0, 0, refLayout[i], refEffect,
                            WALL_COMMAND, 1, WALL_POINTS, NORMALS,
                            WALL_TEXTURES, COLOR );
    }
  }

  public void updateCamPosition(AffineTrans aCamTrans)
  {
    for( int i=0; i<mTabSize; ++i) {
      bricks[i].updateCamPosition(aCamTrans, tmpAT);
    }
  }

}


