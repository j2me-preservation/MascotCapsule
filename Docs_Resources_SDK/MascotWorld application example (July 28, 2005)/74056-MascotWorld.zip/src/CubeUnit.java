import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Cube unit - cube thas is rotating around its axis'
 * It does not change its position
*/
public class CubeUnit extends Obstacle
{
  // reference to effect that should be used
  private static Effect3D refEffect;

  // static variables - common for all cubes
  private static final int COMMAND = Graphics3D.PRIMITVE_TRIANGLES | 
                                     Graphics3D.PDATA_NORMAL_PER_VERTEX |
                                     Graphics3D.PDATA_TEXURE_COORD | 
                                     Graphics3D.PDATA_COLOR_NONE | 
                                     Graphics3D.ENV_ATTR_LIGHTING;

  private final static int KSize = 20;
  // Triangles that make up the cube's faces -- these are vertices, not triangle strips
  private final static int[] mVert = {
    KSize, KSize, KSize,   -KSize, KSize, KSize,   KSize,-KSize, KSize,  -KSize, KSize, KSize,   KSize,-KSize, KSize,  -KSize,-KSize, KSize,   // front
   -KSize, KSize,-KSize,    KSize, KSize,-KSize,  -KSize,-KSize,-KSize,   KSize, KSize,-KSize,  -KSize,-KSize,-KSize,   KSize,-KSize,-KSize,   // back
   -KSize, KSize, KSize,   -KSize, KSize,-KSize,  -KSize,-KSize, KSize,  -KSize, KSize,-KSize,  -KSize,-KSize, KSize,  -KSize,-KSize,-KSize,   // left
    KSize, KSize,-KSize,    KSize, KSize, KSize,   KSize,-KSize,-KSize,   KSize, KSize, KSize,   KSize,-KSize,-KSize,   KSize,-KSize, KSize,   // right
    KSize, KSize,-KSize,   -KSize, KSize,-KSize,   KSize, KSize, KSize,  -KSize, KSize,-KSize,   KSize, KSize, KSize,  -KSize, KSize, KSize,   // top
    KSize,-KSize, KSize,   -KSize,-KSize, KSize,   KSize,-KSize,-KSize,  -KSize,-KSize, KSize,   KSize,-KSize,-KSize,  -KSize,-KSize,-KSize }; // bottom

  // Cube's normals -- Used in lighting calculations.
  private final static int[] mNorm = {
     0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,    0, 0, 4096,
     0, 0, -4096,   0, 0,-4096,    0, 0,-4096,    0, 0,-4096,    0, 0,-4096,    0, 0, -4096,
    -4096, 0, 0,   -4096, 0, 0,   -4096, 0,  0,  -4096, 0, 0,   -4096, 0,  0,  -4096, 0,  0,
     4096, 0, 0,    4096, 0, 0,    4096, 0, 0,    4096, 0, 0,    4096, 0, 0,    4096, 0,  0,
     0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0,    0, 4096, 0,
     0, -4096, 0,   0, -4096, 0,   0, -4096, 0,   0, -4096, 0,   0, -4096, 0,   0, -4096, 0};

  // Coordinates on 2D BMP image to be mapped onto the cube's faces.
  private final static int[] mTex = {
     96, 32,    64, 32,    96, 64,    64, 32,    96, 64,    64, 64,    // cyan
     64, 32,    32, 32,    64, 64,    32, 32,    64, 64,    32, 64,    // blue
     64, 0,     32, 0,     64, 32,    32, 0,     64, 32,    32, 32,    // yellow
     32, 0,     0, 0,      32, 32,    0, 0,      32, 32,    0, 32,    // red
     32, 32,    0, 32,     32, 64,    0, 32,     32, 64,    0, 64,    // magenta
     96, 0,     64, 0,     96, 32,    64, 0,     96, 32,    64, 32 }; // green

  private final static int[] mColor = { 0xFF00FF };

  private static Texture texture = null;

  // every cube update its rotation angles with this variables, initializated at construction
  private int mIncX = 0, mIncY = 0, mIncZ = 0;

  // constructor
  public CubeUnit(int aPosX, int aPosY, int aPosZ, int aRX, int aRY, int aRZ,
                  int aWidth, int aHeight,
                  AffineTrans aCamTrans, AffineTrans aTmpAT,
                  int aIncX, int aIncY, int aIncZ, Effect3D aEffect)
  {
    super(aPosX, aPosY, aPosZ, aRX, aRY, aRZ, aWidth, aHeight, aCamTrans, aTmpAT);

    mIncX = aIncX;
    mIncY = aIncY;
    mIncZ = aIncY;

    refEffect = aEffect;

    try {
      // if texture is not already inicializated, create it
      if( texture == null )
        texture = new Texture("/res/tex_cube.bmp", true);
    }
    catch (Exception e) { e.printStackTrace(); }
  }

  // draw itself on screen
  public void render(Graphics3D g3d)
  {
    g3d.renderPrimitives(texture, 0, 0, layout, refEffect, COMMAND,
                          12, mVert, mNorm, mTex, mColor);
  }

  // increase its own rotation angles - to rotate itself
  public void increaseAngles()
  {
    mSpinAngleX += mIncX;
    mSpinAngleY += mIncY;
    mSpinAngleZ += mIncZ;
  }

  // updates rotation affine transformations with current angles
  public void updateRotation()
  {
    if(mSpinAngleX >= 2048)
        mSpinAngleX = mSpinAngleX - 4096;
    else if( mSpinAngleX <= -2048 )
        mSpinAngleX = mSpinAngleX + 4096;

    if(mSpinAngleY >= 2048)
        mSpinAngleY = mSpinAngleY - 4096;
    else if( mSpinAngleY <= -2048 )
        mSpinAngleY = mSpinAngleY + 4096;

    if(mSpinAngleZ >= 2048)
        mSpinAngleZ = mSpinAngleZ - 4096;
    else if( mSpinAngleZ <= -2048 )
        mSpinAngleZ = mSpinAngleZ + 4096;

    rotX.setIdentity();
    rotX.rotationX(mSpinAngleX);   // rotate X

    rotY.setIdentity();
    rotY.rotationY(mSpinAngleY);   // rotate Y

    rotZ.setIdentity();
    rotZ.rotationZ(mSpinAngleZ);   // rotate Y

    rotX.mul(rotY);
    rotX.mul(rotZ);
  }

}


