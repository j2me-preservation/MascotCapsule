
/*
 * class used to obtain frame rate
 */
public class FPS
{
  public static int fps = 10;
  private int count_fps;
  private String fps_string;
  private long last;

  public FPS()
  {
    fps = 10;
    count_fps = 0;
  }

  public void calculateFps()
  {
    count_fps++;
    long n = System.currentTimeMillis() / 1000L;
    if(n != last)
    {
      fps = count_fps;
      count_fps = 0;
      fps_string = "Fps:" + fps;
      last = n;
    }
  }

  public String getFpsString()
  {
    return fps_string;
  }
}
