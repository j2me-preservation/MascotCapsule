import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;
import java.util.*;

/*
 * Main midlet class
 * It creates canvas and call repaint periodically
 */
public class MW_Main extends MIDlet
{
  public static MIDlet app;
  public static MW_Canvas3D canvas;
  public static Display display;
  Timer iTimer = new Timer();    // Timer to implement animation
  
  int waitCount = 0; 
  
  private boolean paused = false;
  
  public MW_Main() {
    app = this;
    display = Display.getDisplay(app);
    canvas = new MW_Canvas3D(this);
  }
  
  public void startApp()
  {
    display.setCurrent(canvas);
    iTimer.schedule( new MyEnvTimerTask(), 0, 30 ); // Start timer
  }
  
  public void pauseApp() {}
  
  public void destroyApp(boolean unconditional)
  {
    canvas.clearResource();
    this.notifyDestroyed();
  }
  
  class MyEnvTimerTask extends TimerTask
  {
    public void run()
    {
      if( canvas != null ) { // If Canvas is present...
        canvas.repaint(); // ... call its repaint()
      } // end if
    } // end run
  } // end TimerTask
}
