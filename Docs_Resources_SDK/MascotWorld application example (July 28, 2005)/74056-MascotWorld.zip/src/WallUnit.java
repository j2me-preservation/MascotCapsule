import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Wall unit - it is simply a brick, a simplest part of cube.
 * Brick is actually 2 triangles.
 * Brick knows its current position in a scene.
 * It calculates its position in relation to camera for its redraw.
 * It knows which texture (from possible in wall container) it uses.
*/
public class WallUnit extends Obstacle
{
  private int useTextureNo = 0;

  public int getUseTextureNo() { return useTextureNo; }

  public WallUnit(int aPosX, int aPosY, int aPosZ, int aRX, int aRY, int aRZ,
                  int aWidth, int aHeight,
                  AffineTrans aCamTrans, AffineTrans aTmpAT, int aTextNo)
  {
    super(aPosX, aPosY, aPosZ, aRX, aRY, aRZ, aWidth, aHeight, aCamTrans, aTmpAT);
    useTextureNo = aTextNo;
  }

}


