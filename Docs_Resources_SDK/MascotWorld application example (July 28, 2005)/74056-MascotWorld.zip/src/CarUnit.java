import javax.microedition.lcdui.game.*;
import javax.microedition.lcdui.*;
import java.io.*;
import java.lang.*;
import com.mascotcapsule.micro3d.v3.*;

/*
 * Car unit - car, its position is controled by user
 * It has limited move and rotation to XY, Z coordinate stays always the same
*/
public class CarUnit extends Obstacle
{
  // references
  private static Effect3D refEffect;
  private float[] sinRef;
  private float[] cosRef;
  
  // figure is static, all car objects use the same one
  private static Figure figure;

  // temporary affine trans - used in calculation
  private static AffineTrans tmpAT = new AffineTrans();

  // factor used for calculating degrees
  float factor = (360.0f/4096.0f);

  // constructor
  public CarUnit(int aPosX, int aPosY, int aPosZ,
                 int aWidth, int aHeight,
                 AffineTrans aCamTrans, Effect3D aEffect, 
                 float[] aSin, float[] aCos)
  {
    // Rotate car initially around x, than y, so it looks OK,
    // This rotation means also changes of its loocal coordinates.
    super(aPosX, aPosY, aPosZ, 1024, 2048, 0, aWidth, aHeight, aCamTrans, tmpAT);

    // assign references
    refEffect = aEffect;
    sinRef = aSin;
    cosRef = aCos;

    try {
      figure = new Figure("/res/model_car.mbac");
    }
    catch (Exception e) { e.printStackTrace(); }
  }


  public int getPosX() { return move.m03; }
  public int getPosY() { return move.m13; }

  public int getSpinAngleX() { return mSpinAngleX; }
  public int getSpinAngleY() { return mSpinAngleY; }
  public int getSpinAngleZ() { return mSpinAngleZ; }

  public void getMoveLocalToWord(int[] aPosX, int[] aPosY)
  {
    // car is rotating around Z axis, so move in local car coordinated
    // has to be transformed into move in world coordinates.
    // take negative Y positions
    float x = 0, y = 0;
    float v = (float)factor*(float)(mSpinAngleY);
    int angle = (int)v;
    try {
        x = aPosX[0]*cosRef[angle] - (-aPosY[0])*sinRef[angle];
        y = aPosX[0]*sinRef[angle] + (-aPosY[0])*cosRef[angle];
        aPosX[0] = (int)x;
        aPosY[0] = (int)y;
    }
    catch (Exception e) { System.out.println("ERROR: " + "radian: " + mSpinAngleZ + " angle: " + angle); }
  }

  // car has move limited to 2D only
  public void move(int aPosX, int aPosY)
  {
    move(aPosX, aPosY, 0);
  }

  // car has rotation limited to Z axis only
  public void rotate(int aRY)
  {
    // car is actually rotating around Z axis,
    // it has been transformed at construction - that switched its axis
    rotate(0, aRY, 0);
  }

  public void updateCamPosition(AffineTrans aCamTrans)
  {
    this.updateCamPosition(aCamTrans, tmpAT);
  }

  // draw itself
  public void render(Graphics3D g3d)
  {
    g3d.renderFigure(figure, 0, 0, layout, refEffect);
  }

}


