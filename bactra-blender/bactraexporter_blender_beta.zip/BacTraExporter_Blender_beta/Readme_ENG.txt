========================================
BacTra Exporter Ver.beta
2006.09.12
HI CORPORATION
========================================
This is a plugin for outputting .bac/.tra files, data for HI CORPORATION's MacotCapsule V3, from Blender, one of the 3D CG tools.

This plugin supports Blender 2.41.
The output formats are BAC6/TRA4.

��Install
The plugin itself consists of BacTraExp.py file only.
If the directory where Blender has been installed is [Blender], copy BacTraExp.py file to the below directory:

[Blender]\.blender\scripts

If Blender is already run, select [Scripts]-[Update Menus] from Scripts Window of Blender. Now you can export .bac and .tra files.

��Export
Select an object to be output among the designed 3D objects. In this state, select "BacTra(.bac .tra)" from [File]-[Export]. 
When a dialog for selecting a file is displayed, enter the output file name (.bac file name; .tra file name is automatically provided) and click [Export] button. 
The .bac and .tra files are thus generated.

The bitmap for texture is not generated. Create a bitmap of 256 colors and 256x256 bits separately. 
Among the color palette of the bitmap, color No. 0 can be made transparent. For UV setting, UV/Image Editor on Blender is used.

��Settings
��Model
	- Polygon -
		MascotCapsule V3 supports polygons with 3 or 4 vertices only. The bone is always used, and the weight of 100% alone can be used.
	
	- Switch between smooth/solid
		Select [Editing] in the button window and click Set Smooth button in [Link and Materials].

��Material
	- Texture -
		MascotCapsule V3 supports only one texture for one material. 
		Accordingly, in the case where more than one textures are applied on the material, the first texture found is used. 
		Note that appearance may change as a result in some cases.

	- Double-sided polygon -
		Select [Editing] in the button window and set with Double Sided button in [Mesh].

	- Transparency -
		Three settings are required.
		Select [Shading]-[Material buttons] in the button window and set A (Alpha) value in [Material] to 0.
		Select Alpha button in [Map To].
		Select [Shading]-[Texture buttons] in the button window, then select UseAlpha button in [Image].

	- Blend mode -
		Normal
			No blend processing is carried out.
			It will be Normal if other settings are not applied.
		Semi-transparency
			Select [Shading]-[Material buttons] in the button window and set A (Alpha) value to 0.500 in [Material].
		Addition
			Select [Shading]-[Material buttons] in the button window, and then select Add in Mix option in [Map To].
			If both of Addition and Semi-transparency are set, Addition is given priority.
		Subtraction
			Select [Shading]-[Material buttons] in the button window, and then select Subtract in Mix option in [Map To].
			If both of Subtraction and Semi-transparency are set, Subtraction is given priority.

	- On/Off of lighting
		Select [Shading]-[Material buttons] in the button window and select On/Off with Shadeless button in [Material]. 
		If Shadeless in On, the lighting is Off, and if Shadeless in Off, the lighting is On.

	- Environment mapping -
		Select [Shading]-[Material buttons] in the button window, and change Ref value in [Shaders]. 
		If 1.000 is set to the value, it is regarded as On, and if a value other than 1.000 is set, it is regarded as Off.

��Bone/Animation
	When creating the bones, make sure a vertex is not shared by more than one bones.
	Specifically, do not use "Create From Closest Bones" when setting parent-child relationship of the bone and the object. 
	Select "Don't Create Groups" and set it yourself.

	For creating animations, specify the start and end frames with [Anim] in [Scene] in the button window.
	Animations in the range set in this operation are output.
	Incidentally, status of the start frame is described in 0 frame in the TRA file.
	Create animations with this status as the basic posture.

	"Vertex Groups" have always to be set for associating the object and the bone.

