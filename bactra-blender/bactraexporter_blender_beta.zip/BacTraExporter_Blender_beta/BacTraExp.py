#!BPY

"""
Name: 'BacTra(.bac .tra)'
Blender: 241
Group: 'Export'
Tip: 'BacTra Exporter Ver.beta'
"""

import Blender
from Blender import *
import os
import time
import math
from math import *

global GlobalTopObject		# class TransformedBaseObject
global GlobalBoneList		# class BoneCapsule []
global GlobalNMeshList		# class NMeshCapsule []

#===========================================================================
# MARK : Functions
#---------------------------------------------------------------------------

# FUNC : VecMultMatEx
def VecMultMatEx(vec,mat):  # vec(x,y,z,1) * mat
	res = Mathutils.Vector()
	res.x = mat[0][0] * vec.x + mat[1][0] * vec.y + mat[2][0] * vec.z + mat[3][0]
	res.y = mat[0][1] * vec.x + mat[1][1] * vec.y + mat[2][1] * vec.z + mat[3][1]
	res.z = mat[0][2] * vec.x + mat[1][2] * vec.y + mat[2][2] * vec.z + mat[3][2]
	return res

# FUNC : MatMultVecEx
def MatMultVecEx(mat,vec): # mat * vec(x,y,z,1)
	res = Mathutils.Vector()
	res.x = mat[0][0] * vec.x + mat[0][1] * vec.y + mat[0][2] * vec.z + mat[0][3]
	res.y = mat[1][0] * vec.x + mat[1][1] * vec.y + mat[1][2] * vec.z + mat[1][3]
	res.z = mat[2][0] * vec.x + mat[2][1] * vec.y + mat[2][2] * vec.z + mat[2][3]
	return res

# FUNC : MatMultEx
def MatMultEx(mat1,mat2):
	mat = Mathutils.Matrix()
	for i in range(4):
		for j in range(4):
			mat[i][j] = 0.0
			for k in range(4):
				mat[i][j] += mat1[i][k] * mat2[k][j]
	return mat

#===========================================================================
# MARK : Base Classes
#---------------------------------------------------------------------------
  # class BacBone

# CLSS : BacBone
class BacBone:
	# MTHD : BacBone.__init__
	def __init__(self,mat):
		xx = mat[0][0]
		yx = mat[0][1]
		zx = mat[0][2]
		nx = mat[0][3]
		xy = mat[1][0]
		yy = mat[1][1]
		zy = mat[1][2]
		ny = mat[1][3]
		xz = mat[2][0]
		yz = mat[2][1]
		zz = mat[2][2]
		nz = mat[2][3]
		xt = mat[3][0]
		yt = mat[3][1]
		zt = mat[3][2]
		nt = mat[3][3]
		self.translate = Mathutils.Vector( xt, yt, zt )
		self.rotate = Mathutils.Vector( zx+xt, zy+yt, zz+zt ) 
		self.handle = Mathutils.Vector( yx+xt, yy+yt, yz+zt )

#---------------------------------------------------------------------------
  # class TraRotation

# CLSS : TraRotation
class TraRotation:
	# MTHD : TraRotation.__init__
	def __init__(self,quat,bmat=Mathutils.Matrix()):
		
		self.rotate = Mathutils.Vector()
		self.roll = 0.0 # degree
		
		for i in range(3):
			bmat[3][i] = 0
			bmat[i][3] = 0

		#qmat.resize4x4()
		bimat = Mathutils.Matrix(bmat) 
		#bimat.resize4x4() 
		bimat.invert()
		
		qmat = quat.toMatrix()         # quaternion transformed matrix
		
		zAxis = Mathutils.Vector(0.0,0.0,1.0) # vector
		zAxis = zAxis * qmat
		zAxis.normalize()
		self.rotate = zAxis 
		
		euler = quat.toEuler()
		self.roll = euler.z
		
		return
	
	# MTHD : TraRotation.__eq__
	def __eq__(self,comp):
		if(None is not comp):
			return (self.rotate == comp.rotate) and (self.roll   == comp.roll)
		else:
			return False

#---------------------------------------------------------------------------
  # class CurveAdmin

# CLSS : CurveAdmin
class CurveAdmin:
	
	# MTHD : CurveAdmin.__init__
	def __init__(self,owner):
		self.owner = owner
		self.curves = {} # CurvePoints
	
	# MTHD : CurveAdmin.makeCurve
	def makeCurve(self, name):
		self.curves[name] = CurvePoints(name)
	
	# MTHD : CurveAdmin.appendPoint
	def appendPoint(self, name, time, value, autoMake=True):
		if(autoMake and not self.hasCurve(name)):
			self.makeCurve(name)
		if(self.curves.has_key(name)):
			self.curves[name].append(time, value)
	
	def appendCriticalPoint(self, name, time, value, autoMake=True):
		if(autoMake and not self.hasCurve(name)):
			self.makeCurve(name)
		if(self.curves.has_key(name)):
			self.curves[name].appendCritical(time, value)
	
	# MTHD : CurveAdmin.hasCurve
	def hasCurve(self,name):
		return self.curves.has_key(name)
	
	# MTHD : CurveAdmin.any
	def any(self,time):
		for curve in self.curves.values():
			if(curve.exists(time)):
				return True
		return False
	
	# MTHD : CurveAdmin.exists
	def exists(self,time):
		if len(self.curves)==0 :
			return False
		for curve in self.curves.values():
			if(not curve.exists(time)):
				return False
		return True
	
	# MTHD : CurveAdmin.animationExists
	def animationExists(self):
		for curve in self.curves.values():
			if len(curve.frames)>0 :
				return True
		return False
	
	# MTHD : CurveAdmin.validate
	def validate(self,startframe,object):
		if(self.animationExists()):
				for curveName in ['LocX','LocY','LocZ']:
					if(self.hasCurve(curveName)):
						self.curves[curveName].translateValidation(startframe,object)
				for curveName in ['SizeX','SizeY','SizeZ']:
					if(self.hasCurve(curveName)):
						self.curves[curveName].sizeValidation(startframe,object)
				mat = Mathutils.Matrix()
				mat.identity()
				quat = mat.toQuat()
				for curveName in ['Quaternion']:
					if(self.hasCurve(curveName)):
						self.curves[curveName].quaternionValidation(startframe,object)
	
	def mergeCriticalFrom(self,name,points):
		if(self.curves.has_key(name)):
			self.curves[name].mergeCriticalFrom(points)
	
	# MTHD : CurveAdmin.reduce
	def reduce(self,startframe,endframe,threshold=0.001):
		reducer = KeyFrameReducer()
		for curve in self.curves.values():
			reducer.appendCurve(curve)
		reducer.reduce(startframe,endframe,threshold)
	
	# MTHD : CurveAdmin.compact
	def compact(self,startframe,endframe):
		values = self.curves.values()
		for val in values:
			if ((val.name=="QuatX") or (val.name=="QuatY") or (val.name=="QuatZ") or(val.name=="QuatW") or
				(val.name=="RotX") or (val.name=="RotY") or (val.name=="RotZ")):
					continue
			val.compact(startframe,endframe)

#---------------------------------------------------------------------------
  # class CurvePoints

# CLSS : CurvePoints
class CurvePoints:
	
	# MTHD : CurvePoints.__init__
	def __init__(self, name):
		self.name = name
		self.frames = {} # TimeAndValue
		self.criticalTimes = set() 

	# MTHD : CurvePoints.__getitem__
	def __getitem__(self, time):
		return self.frames[time]
	
	# MTHD : CurvePoints.exists
	def exists(self, time):
		return self.frames.has_key(time)
	
	# MTHD : CurvePoints.append
	def append(self, time, value):
		self.frames[time] = value
	
	# MTHD : CurvePoints.appendCritical
	def appendCritical(self, time, value):
		self.criticalTimes.add(time)
		self.frames[time] = value
	
	# MTHD : CurvePoints.criticalTimeExists
	def criticalTimeExists(self, time):
		return time in self.criticalTimes
	
	# MTHD : CurvePoints.clear
	def clear(self):
		removables = []
		iterf = self.frames.iterkeys()
		for i in range(len(self.frames)):
			time = iterf.next()
			if time==None : break
			if not (time in self.criticalTimes):
				removables.append(time)
		for time in removables:
			del self.frames[time]
		#self.frames.clear()
		#self.criticalTimes.clear()

	def mergeCriticalFrom(self,points):
		self.criticalTimes = self.criticalTimes.union(points.criticalTimes)

	# MTHD : CurvePoints.translateValidation
	def translateValidation(self,startframe,object):
		if(not self.exists(startframe)):
			if(len(self.frames)>0): # has_key 
				self.append(startframe,self.frames.items()[0][1])
				return True
			else:
				if(self.name=='LocX'):
					self.append(startframe,object.loc.x)
				elif(self.name=='LocY'):
					self.append(startframe,object.loc.y)
				elif(self.name=='LocZ'):
					self.append(startframe,object.loc.z)
				return False
		return True
	
	# MTHD : CurvePoints.sizeValidation
	def sizeValidation(self,startframe,object):
		if(not self.exists(startframe)):
			if(len(self.frames)>0): # has_key 
				self.append(startframe,self.frames.items()[0][1])
				return True
			else:
				if(self.name=='SizeX'):
					self.append(startframe,object.size.x)
				elif(self.name=='SizeY'):
					self.append(startframe,object.size.y)
				elif(self.name=='SizeZ'):
					self.append(startframe,object.size.z)
				return False
		return True
	
	# MTHD : CurvePoints.quaternionValidation
	def quaternionValidation(self,startframe,object):
		if(not self.exists(startframe)):
			if(len(self.frames)>0): # has_key 
				self.append(startframe,self.frames.items()[0][1])
				return True
			else:
				euler = Mathutils.Euler()
				euler.x = object.rot.x
				euler.y = object.rot.y
				euler.z = object.rot.z
				self.append(startframe,euler.toQuat())
				return False
		return True

	# MTHD : CurvePoints.traRotationValidation
	def traRotationValidation(self):
		minValue = 0
		maxValue = 360
		for traRot in self.frames.values():
			if(traRot.roll<minValue):
				minValue = traRot.roll
			if(traRot.roll>maxValue):
				maxValue = traRot.roll
		addRad = 0 
		while(maxValue>360) :
			addRad = addRad - 360 
			maxValue = maxValue - 360
		while(minValue<0) :
			addRad = addRad + 360 
			minValue = minValue + 360
		for traRot in self.frames.values():
			traRot.roll = traRot.roll+addRad

	# MTHD : CurvePoints.sizeInterpolation
	def sizeInterpolation(self,time):
		return
	
	# MTHD : CurvePoints.translateInterpolation
	def translateInterpolation(self, time):
		return
	
	# MTHD : CurvePoints.quaternionInterpolation
	def quaternionInterpolation(self, time):
		return

	# MTHD : CurvePoints.rotateInterpolation
	def rotateInterpolation(self, time):
		if(self.exists(time)):
			return self.frames[time] ;
		else:
			items = self.frames.items()
			if(len(items)==0):
				return 0
			elif(len(items)==1):
				return items[0][1]
			else:
				neartime = starttime = items[0][0]
				endtime = items[len(items)-1][0]
				duringtime = int(endtime - starttime + 1)
				if(starttime>time):
					return items[0][1]
				elif(endtime<time):
					return items[len(items)-1][1]
				point = -1
				for t in range(duringtime):
					now = starttime + t
					if(self.exists(now)):
						point = point + 1 
					if(now==time):
						time1 = items[point][0]
						val1 = items[point][1]
						time2 = items[point+1][0]
						val2 = items[point+1][1]
						return (val2-val1)*(time-time1)/(time2-time1) + val1
	
	# MTHD : CurvePoints.compact
	def compact(self,startframe,endframe):
		if(len(self.frames)>=2):
			removable_times = []
			old = None
			for t in range(endframe-startframe+1):
				time = t + startframe
				if(self.frames.has_key(time)):
					if(old==None):
						old = self.frames[time]
					elif(old==self.frames[time]):
						removable_times.append(time)
					else:
						old = self.frames[time]
			for time in removable_times:
				del self.frames[time]

#---------------------------------------------------------------------------
  # class KeyFrameReducer

# CLSS : KFRKeyframe
class KFRKeyframe:
	
	# MTHD : KFRKeyframe.__init__
	def __init__(self,time):
		self.time = time
		self.values = []
	
	# MTHD : KFRKeyframe.append
	def append(self,value):
		self.values.append(value)
	
	# MTHD : KFRKeyframe.__getitem__
	def __getitem__(self, index):
		return self.frames[index]
	
	# MTHD : KFRKeyframe.__setitem__
	def __setitem__(self, index, value):
		self.frames[index] = value

# CLSS : KFRFrame
class KFRFrame:
	
	# MTHD : KFRFrame.__init__
	def __init__(self,time,value):
		self.time = time
		self.value = value

# CLSS : KFRFrames
class KFRFrames:
	
	# MTHD : KFRFrames.__init__
	def __init__(self):
		self.frames = []
	
	# MTHD : KFRFrames.append
	def append(self,time,value):
		self.frames.append(KFRFrame(time,value))
	
	# MTHD : KFRFrames.__getitem__
	def __getitem__(self, index):
		return self.frames[index]
	
	# MTHD : KFRFrames.__setitem__
	def __setitem__(self, index, value):
		self.frames[index] = value
	
	# MTHD : KFRFrames.find
	def find(self,time):
		for index in range(len(self.frames)):
			if self.frames[index].time==time :
				return self.frames[index]
		return None

# CLSS : KeyFrameReducer
class KeyFrameReducer:
	
	# MTHD : KeyFrameReducer.__init__
	def __init__(self):
		self.curves = [] # CurvePoints
	
	# MTHD : KeyFrameReducer.appendCurve
	def appendCurve(self,curve):
		self.curves.append(curve)
	
	# MTHD : KeyFrameReducer.reduce
	def reduce(self,startframe,endframe,threshold=0.001):
		for curve in self.curves:
			if len(curve.frames)<1 :
				return
		self.threshold = threshold
		componentCount = len(self.curves)
		self.srcFrms = [] # KFRFrames()
		self.dstFrms = [] # KFRFrames()
		for c in range(componentCount):
			self.srcFrms.append(KFRFrames())
			self.dstFrms.append(KFRFrames())
		for fn in range(endframe-startframe+1):
			time = fn + startframe
			existed = True
			for c in range(componentCount):
				if not self.curves[c].exists(time) :
					existed = False
					break
			if existed :
				for c in range(componentCount):
					self.srcFrms[c].append(time,self.curves[c][time])
		ftimes = set()
		for c in range(componentCount):
			self.dstFrms[c].append(self.srcFrms[c][0].time,self.srcFrms[c][0].value)
			if len(self.srcFrms[c].frames)>=2 :
				self._subReduce1(c,0,len(self.srcFrms[c].frames))
			for k in range(len(self.dstFrms[c].frames)):
				ftimes.add(self.dstFrms[c][k].time)
		dstKeyframes = []
		for fn in range(endframe-startframe+1):
			time = fn+startframe
			if time in ftimes:
				dstKeyframe = KFRKeyframe(time)
				for c in range(componentCount):
					key = self.dstFrms[c].find(time)
					if key != None :
						dstKeyframe.values.append(key.value)
					else :
						dstKeyframe.values.append(self.srcFrms[c].find(time).value)
				dstKeyframes.append(dstKeyframe)

		ck = 0
		for curve in self.curves:
			curve.clear()
			for key in dstKeyframes:
				curve.append(key.time,key.values[ck])
			ck = ck + 1
	
	# MTHD : KeyFrameReducer._subReduce1
	def _subReduce1(self,compo,beg,end):
		errPos = self._checkError1(compo,beg,end)
		if errPos != end :
			self._subReduce1(compo,beg,errPos+1)
			self._subReduce1(compo,errPos,end)
		else:
			self.dstFrms[compo].append(
				self.srcFrms[compo][end-1].time,
				self.srcFrms[compo][end-1].value )
	
	# MTHD : KeyFrameReducer._checkError1
	def _checkError1(self,compo,beg,end):
		back = end-1
		t0 = self.srcFrms[compo][beg].time
		v0 = self.srcFrms[compo][beg].value
		diff_time = float(self.srcFrms[compo][back].time - t0)
		dv = (self.srcFrms[compo][back].value - v0) / diff_time
		max_it = end
		max_err = self.threshold
		for i in range(back-(beg+1)):
			it = i+beg+1
			tdist = self.srcFrms[compo][it].time - t0
			value = v0 + float(tdist) *dv
			err = fabs(self.srcFrms[compo][it].value - value)
			if err>max_err :
				max_it = it
				max_err = err
		return max_it

#---------------------------------------------------------------------------
  # class TypeBaseObject

# CLSS : TypeBaseObject
class TypeBaseObject:
	# MTHD : TypeBaseObject.__init__
	def __init__(self,type="",name=""):
		self.type = type
		self.name = name
		self.inherits = []
		self.inherits.append("TypeBaseObject")
	
	# MTHD : TypeBaseObject.inherited
	def inherited(typeName):
		for name in inherits:
			if(name==typeName):
				return True
		return False
	
	# MTHD : TypeBaseObject.isArmature
	def isArmature(self):
		return self.type == "Armature"
	
	# MTHD : TypeBaseObject.isMesh
	def isMesh(self):
		return self.type == "Mesh"
	
	# MTHD : TypeBaseObject.isBone
	def isBone(self):
		return self.type == "Bone"
	
	# MTHD : TypeBaseObject.isNecessaryObject
	def isNecessaryObject(self):
		return	(	self.isArmature() or
					self.isMesh() or
					self.isBone()	)

#---------------------------------------------------------------------------
  # class TransformedBaseObject

# CLSS : TransformedBaseObject
class TransformedBaseObject(TypeBaseObject):
	
	# MTHD : TransformedBaseObject.__init__
	def __init__(self,type="",name="",matrix=None,object=None,parent=None):
		TypeBaseObject.__init__(self,type,name)
		self.inherits.append("TransformedBaseObject")
		self.object = object
		if(matrix==None):
			self.matrix = Mathutils.Matrix()
			self.matrix.identity()
		else:
			self.matrix = matrix
		self.track = None
		#self.parent = parent
		self.children = []
		self.parent = None
		if(parent!=None):
			parent.appendChild(self)
		if(object!=None):
			self.pose=object.getPose()
			self.loc = Mathutils.Vector(object.loc)
			self.rot = Mathutils.Vector(object.rot)
			self.size = Mathutils.Vector(object.size)
		else:
			self.pose=None;
			self.loc = Mathutils.Vector(0,0,0)
			self.rot = Mathutils.Vector(0,0,0)
			self.size = Mathutils.Vector(1,1,1)

	# MTHD : TransformedBaseObject.getDirectionNormalizedMatrix
	def getDirectionNormalizedMatrix(self):
		matrix = Mathutils.Matrix(self.matrix)
		vx = Mathutils.Vector(matrix[0][0],matrix[1][0],matrix[2][0])
		vy = Mathutils.Vector(matrix[0][1],matrix[1][1],matrix[2][1])
		vz = Mathutils.Vecotr(matrix[0][2],matrix[1][2],matrix[2][2])
		vx.normalize()
		vy.normalize()
		vz.normalise()
		matrix[0][0] = vx.x 
		matrix[1][0] = vx.y 
		matrix[2][0] = vx.z 
		matrix[0][1] = vy.x 
		matrix[1][1] = vy.y 
		matrix[2][1] = vy.z 
		matrix[0][2] = vz.x 
		matrix[1][2] = vz.y 
		matrix[2][2] = vz.z 
		return matrix
	
	# MTHD : TransformedBaseObject.getDirectionNormalizedWorldMatrix
	def getDirectionNormalizedWorldMatrix(self):
		if(self.parent!=None):
			return ( self.getDirectionNormalizedMatrix() 
				 * self.parent.getDirectionNormalizedWroldMatrix() )
		else:
			return self.getDirectionNormalizedMatrix() 

	# MTHD : TransformedBaseObject.getWorldMatrix
	def getWorldMatrix(self):
		if(self.object!=None):
			return self.object.matrixWorld 
		if(self.parent!=None):
			return self.matrix * self.parent.getWorldMatrix()
		else:
			return Mathutils.Matrix(self.matrix)
	
	# MTHD : TransformedBaseObject.appendChild
	def appendChild(self,tbobj):
		tbobj.parent = self
		self.children.append(tbobj)
	
	# MTHD : TransformedBaseObject.removeChild
	def removeChild(self,tbobj):
		i = 0
		found = False
		for child in self.children:
			if(child==tbobj):
				found = True 
				break
			i = i+1
		if found :
			tbobj.parent = None
			self.children = self.children[0:i] + self.children[i+1:len(self.children)]
		return found
	
	# MTHD : TransformedBaseObject.searchObject
	def searchObject(self,object):
		if(self.object==object):
			return self
		for hObj in self.children:
			return hObj.searchObject(object)
		return None
	
	# MTHD : TransformedBaseObject.hasBrother
	def hasBrother(self):
		if(self.parent!=None):
			pchildren = self.parent.children
			found_self = False
			for pchild in pchildren:
				if pchild==self:
					found_self = True
				elif found_self:
					return True
			return False
		else:
			return False
	
	# MTHD : TransformedBaseObject.hasChild
	def hasChild(self):
		return len(self.children)>0
	
	# MTHD : TransformedBaseObject.makeTrack
	def makeTrack(self,startframe,endframe):
		if (self.object != None ):
			ipo = self.object.getIpo()
			if ipo!=None :
				self.track = CurveAdmin(self)
				self.track.makeCurve('RotX')
				self.track.makeCurve('RotY')
				self.track.makeCurve('RotZ')
				self.track.makeCurve('SizeX')
				self.track.makeCurve('SizeY')
				self.track.makeCurve('SizeZ')
				self.track.makeCurve('LocX')
				self.track.makeCurve('LocY')
				self.track.makeCurve('LocZ')
				curves = ipo.curves
				for curve in curves:
					bezPoints = curve.bezierPoints
					for bezTripple in bezPoints: 
						pt = bezTripple.pt
					for fn in range(endframe-startframe+1):
						time = startframe+fn
						self.track.appendPoint(curve.name,time,curve.evaluate(time))
		return

	# MTHD : TransformedBaseObject.makeAllTracks
	def makeAllTracks(self,startframe,endframe):
		self.makeTrack(startframe,endframe)
		for child in self.children:
			child.makeAllTracks(startframe,endframe)

#===========================================================================
# MARK : Extra Classes
#---------------------------------------------------------------------------
  # class ArmatureCapsule 
  
# CLSS : ArmatureCapsule
class ArmatureCapsule(TransformedBaseObject):
	# MTHD : ArmatureCapsule.__init__
	def __init__(self,type,name,matrix,object,armature,parent=None):
		TransformedBaseObject.__init__(self,type,name,matrix,object,parent)
		self.inherits.append("ArmatureCapsule")
		self.armature = armature    # Armature
		#self.bones = {}             # BoneCapsule{}
		for bonetup in armature.bones.items():
			bone = bonetup[1]
			if(not bone.hasParent()):
				cbone = BoneCapsule(bone,self)

#---------------------------------------------------------------------------
  # class BoneCapsule

# CLSS : BoneCapsule
class BoneCapsule(TransformedBaseObject):
	
	# MTHD : BoneCapsule.__init__
	def __init__(self,bone,parent):
		global GlobalBoneList
		type = "Bone"
		name = bone.name
		TransformedBaseObject.__init__(self,type,name,None,None,parent)
		self.inherits.append("BoneCapsule")
		self.bone		= bone
		self.matrix = self.calculateMatrix()
		if(self.bone.hasChildren()):
			for child in self.bone.children:
				cbone = BoneCapsule(child,self)
		GlobalBoneList.append(self)
	
	# MTHD : BoneCapsule.getArmature
	def getArmature(self):
		parent = self.parent
		while (parent!=None) and (not parent.isArmature()) :
			parent = parent.parent
		return parent
	
	# MTHD : BoneCapsule.getArmatureMatrix
	def getArmatureMatrix(self):
		if(self.parent==None): 
			return Mathutils.Matrix(self.matrix)
		elif(self.parent.isArmature()):
			return Mathutils.Matrix(self.matrix)
		else:
			return self.matrix * self.parent.getArmatureMatrix()
	
	# MTHD : BoneCapsule.getDirectionNormalizedArmatureMatrix
	def getDirectionNormalizedArmatureMatrix(self):
		if( (self.parent==None) or self.parent.isArmature()):
			return self.getDirectionNormalizedMatrix()
		else:
			return ( self.getDirectionNormalizedMatrix()
						* self.parent.getDirectionNormalizedArmatureMatrix() )

	# MTHD : BoneCapsule.calculateMatrix
	def calculateMatrix(self):
		matrix = Mathutils.Matrix()
		matrix.identity()
		for i in range(3):
			for j in range(3):
				matrix[i][j] = self.bone.matrix['BONESPACE'][i][j]
		if(self.parent.isBone()):
			translate = self.parent.bone.tail['BONESPACE'] - self.parent.bone.head['BONESPACE']
		else:
			translate = self.bone.head['BONESPACE']
		matrix[3][0] = translate.x
		matrix[3][1] = translate.y
		matrix[3][2] = translate.z
		return matrix
	
	# MTHD : BoneCapsule.makeTrack
	def makeTrack(self,startframe,endframe):
		armature = self.getArmature()
		action = armature.object.getAction()
		if(action != None):
			iposdict = action.getAllChannelIpos() ;
			for ipotup in iposdict.items():
				bonename = ipotup[0]
				if(bonename==self.name):
					self.track = CurveAdmin(self)
					self.track.makeCurve('QuatX')
					self.track.makeCurve('QuatY')
					self.track.makeCurve('QuatZ')
					self.track.makeCurve('QuatW')
					self.track.makeCurve('SizeX')
					self.track.makeCurve('SizeY')
					self.track.makeCurve('SizeZ')
					self.track.makeCurve('LocX')
					self.track.makeCurve('LocY')
					self.track.makeCurve('LocZ')
					ipo = ipotup[1]
					curves = ipo.curves
					for curve in curves:
						bezPoints = curve.bezierPoints
						for bezTripple in bezPoints: 
							pt = bezTripple.pt
						for fn in range(endframe-startframe+1):
							time = startframe+fn
							self.track.appendPoint(curve.name,time,curve.evaluate(time))

#---------------------------------------------------------------------------
  # class NMeshCapsule

# CLSS : NMeshCapsule
class NMeshCapsule(TransformedBaseObject):
	# MTHD : NMeshCapsule.__init__
	def __init__(self,type,name,matrix,object,nmesh,parent=None):
		global GlobalNMeshList
		TransformedBaseObject.__init__(self,type,name,matrix,object,parent)
		self.inherits.append("NMeshCapsule")
		self.nmesh = nmesh
		GlobalNMeshList.append(self)
		self.nmesh.transform(self.getWorldMatrix(),True)

# FUNC : SearchNMeshCapsule
def SearchNMeshCapsule(nmesh):
	for nmeshCap in GlobalNMeshList:
		if(nmeshCap.nmesh == nmesh):
			return nmeshCap
	return None

#---------------------------------------------------------------------------
  # def CreateCapsuleObject

# FUNC : CreateCapsuleObject
def CreateCapsuleObject(object):
	result = None
	if(object==None):
		result = TransformedBaseObject()
	else:
		type = object.getType()
		name = object.getName()
		matrix = object.matrixLocal
		data = object.getData()
		if(type=='Armature'):
			result = ArmatureCapsule(type,name,matrix,object,data)
		elif(type=='Mesh'):
			result = NMeshCapsule(type,name,matrix,object,data)
		else:
			result = TransformedBaseObject(type,name,matrix,object)
	return result

#===========================================================================
global gList_Color		#class V3ColorList
global gList_Tex		#class V3TexList
global gList_Mat		#class V3MatList
global gList_Face		#class V3FaceList
global gList_Vert		#class V3VertList
global gList_UV			#class V3UVList
global gList_Bone		#class V3BoneList
#-------------------------------------------------------------------------------
# FUNC : getData
def getData():
	global gList_Color		#class V3ColorList
	global gList_Tex		#class V3TexList
	global gList_Mat		#class V3MatList
	global gList_Face		#class V3FaceList
	global gList_Vert		#class V3VertList
	global gList_UV			#class V3UVList
	global gList_Bone		#class V3BoneList

	gList_Color = V3ColorList()
	gList_Tex = V3TexList()
	gList_Mat = V3MatList()
	gList_Face = V3FaceList(GlobalNMeshList)

	gList_Mat.makelist(GlobalNMeshList)
	gList_Tex.makelist(gList_Mat)
	gList_Color.makelist(gList_Mat)
	gList_Face.linkMaterial(GlobalNMeshList, gList_Mat, gList_Color)

	gList_Vert = V3VertList(GlobalNMeshList, gList_Face)
	gList_UV = V3UVList(GlobalNMeshList, gList_Face)

	gList_Face.fill()

	gList_Bone = V3BoneList()
	gList_Bone.addVertices(gList_Vert)

#---------------------------------------------------------------------------
# CLSS : V3Color
class V3Color:
	#<<member fields>>
	#color : float list
	#number : index

	# MTHD : V3Color.__init__
	def __init__(self, list, num):
		self.color = list
		self.number = num

	#write bac
	# MTHD : V3Color.write
	def write(self, file):
		str = ("        ( f3 %s %s %s )\n"% (self.color[0], self.color[1], self.color[2]) )
		file.write(str)

#-------------------------------------------------------------------------------
# CLSS : V3ColorList
class V3ColorList:
	#<<member fields>>
	#list : real list

	# MTHD : V3ColorList.__init__
	def __init__(self):
		self.list = []

	# MTHD : V3ColorList.makelist
	def makelist(self, matlist):
		number = 0
		for v3mat in matlist.list:
			if(v3mat.tex == None):
				color = v3mat.mat.getRGBCol()
				samecol = self.getSameColor(color)
				if(samecol == None):
					self.list.append(V3Color(color, number))
					v3mat.colorindex = number
					number = number + 1
				else:
					v3mat.colorindex = samecol.number

	# MTHD : V3ColorList.getSameColor
	def getSameColor(self, target):
		col = None
		for data in self.list:
			if(data.color == target):
				col = data
		return col

	#write bac
	# MTHD : V3ColorList.write
	def write(self, file):
		file.write('    ( Colors\n')
		for cl in self.list:
			if(cl == None):
				file.write('        ( f3 0.5 0.5 0.5 )\n')
			else:
				cl.write(file)
		file.write('    )\n')

#---------------------------------------------------------------------------

# CLSS : V3Tex
class V3Tex:
	#<<member fields>>
	#tex : Texture
	#number : index

	# MTHD : V3Tex.__init__
	def __init__(self, texdata, num):
		self.tex = texdata
		self.number = num

	#write bac
	# MTHD : V3Tex.write
	def write(self, file):
		xy = self.tex.getImage().getMaxXY()
		str = ("        ( i2 %s %s )\n" % (xy[0], xy[1]) )
		file.write(str)

#---------------------------------------------------------------------------

# CLSS : V3TexList
class V3TexList:
	#<<member fields>>
	#tmplist
	#list : real list

	# MTHD : V3TexList.__init__
	def __init__(self):
		self.tmplist = Texture.Get()
		self.list = []

	# MTHD : V3TexList.makelist
	def makelist(self, matlist):
		number = 0
		for tex in self.tmplist:
			for v3mat in matlist.list:
				if(v3mat.tex != None):
					if(tex.name == v3mat.tex.name):
						sametex = self.getSameTex(tex)
						if(sametex == None):
							self.list.append(V3Tex(tex, number))
							v3mat.texindex = number
							number = number + 1
						else:
							v3mat.texindex = sametex.number

	# MTHD : V3TexList.getSameTex
	def getSameTex(self, target):
		tex = None
		for data in self.list:
			if(data.tex.name == target.name):
				tex = data
		return tex

	#write bac
	# MTHD : V3TexList.write
	def write(self, file):
		if(len(self.list) == 0):
			return
		file.write('    ( Textures\n')
		for tex in self.list:
			tex.write(file)
		file.write('    )\n')

#---------------------------------------------------------------------------

# CLSS : V3Mat
class V3Mat:
	#<<member fields>>
	#mat : Material
	#tex : Texture
	#color
	#number : index
	#???index_tex : list
	#???index_color : list
	#texindex : int
	#colorindex : int

	#blendMode : str
	#doubleface : str
	#transparent : str
	#lighting : str
	#specular : int

	# MTHD : V3Mat.__init__
	def __init__(self, v3mesh, material, num):
		self.number = num
		self.tex = None
		self.mat = material
		self.texindex = -1
		self.colorindex = -1

		self.blendMode = 'normal'
		maptoalpha = False
		usealpha = False

		for mtex in self.mat.getTextures():
			if(mtex != None):
				temptex = mtex.tex

				if(mtex.blendmode & Texture.BlendModes['SUBTRACT']):
					self.blendMode = 'sub'
				if(mtex.blendmode & Texture.BlendModes['ADD']):
					self.blendMode = 'add'
				if(mtex.mapto & Texture.MapTo['ALPHA']):
					maptoalpha = True
				if(temptex.imageFlags & Texture.ImageFlags['USEALPHA']):
					usealpha = True

				if(temptex != None):
					if(temptex.getImage() != None):
						self.tex = temptex
						break
		if (self.tex == None):
			self.color = self.mat.getRGBCol()

		if(self.blendMode == 'normal'):
			if(self.mat.getAlpha() == 0.5):
				self.blendMode = 'half'

		if(v3mesh.nmesh.getMode() & NMesh.Modes['TWOSIDED']):
			self.doubleface = 'true'
		else:
			self.doubleface = 'false'

		self.transparent = 'false'
		if(maptoalpha):
			if(usealpha):
				if(self.mat.getAlpha() == 0):
					self.transparent = 'true'

		if(self.mat.getMode() & Material.Modes['SHADELESS']):
			self.lighting = 'false'
		else:
			self.lighting = 'true'

		if( self.mat.getRef() == 1.0):
			self.specular = 1.0
		else:
			self.specular = 0.0

	#write bac
	# MTHD : V3Mat.write
	def write(self, file):
		str = "        ( material\n"
		file.write(str)

		str = '            ( name "%s" )\n' % self.mat.name
		file.write(str)

		str = "            ( blendMode %s )\n" % self.blendMode
		file.write(str)

		str = "            ( doubleFace %s )\n" % self.doubleface
		file.write(str)

		str = "            ( transparent %s )\n" % self.transparent
		file.write(str)

		file.write("            ( alpha 0.0 )\n")

		str = "            ( lighting %s )\n" % self.lighting
		file.write(str)

		str = "            ( textureIndex %s )\n" % self.texindex
		file.write(str)

		str = "            ( colorIndex %s )\n" % self.colorindex
		file.write(str)

		str = "            ( specular %s )\n" % self.specular
		file.write(str)

		file.write("            ( shininess 0.0 )\n")

		file.write("        )\n")

#-------------------------------------------------------------------------------

# CLSS : V3MatList
class V3MatList:
	#<<member fields>>
	#tmplist
	#list : real list

	# MTHD : V3MatList.__init__
	def __init__(self):
		self.tmplist = Material.Get()
		self.list = []

	#make list from matlist
	#matlist : all materials including unused.
	#list : only used materials.
	# MTHD : V3MatList.makelist
	def makelist(self, meshlist):
		number = 0
		for mat in self.tmplist:
			for v3mesh in meshlist:
				for tmpmat in v3mesh.nmesh.materials:
					if(mat.name == tmpmat.name):
						if(self.checkSameMat(tmpmat) == False):
							self.list.append(V3Mat(v3mesh, tmpmat, number))
							number = number + 1

	# MTHD : V3MatList.checkSameMat
	def checkSameMat(self, target):
		answer = False
		for data in self.list:
			if(data.mat.name == target.name):
				answer = True
		return answer

	#write bac
	# MTHD : V3MatList.write
	def write(self, file):
		global gList_Color		#for dummy material
		file.write('    ( Materials\n')
		for mat in self.list:
			if(mat == None):	#dummy
				file.write('        ( material\n')
				file.write('            ( name "V3_Material_Dummy" )\n')
				file.write('            ( blendMode normal )\n')
				file.write('            ( doubleface false )\n')
				file.write('            ( transparent false )\n')
				file.write('            ( alpha 0.0 )\n')
				file.write('            ( lighting false )\n')
				file.write('            ( transparent false )\n')
				file.write('            ( textureIndex -1 )\n')
				str = '            ( colorIndex %s )\n' % (len(gList_Color.list) - 1)
				file.write(str)
				file.write('            ( specular 0.0 )\n')
				file.write('            ( shininess 0.0 )\n')
				file.write('        )\n')
			else:
				mat.write(file)
		file.write('    )\n')

#---------------------------------------------------------------------------

# CLSS : V3Face
class V3Face:
	#<<member fields>>
	#face : NMFace
	#number : index
	#mat : int
	#v3m : V3Mesh
	#vertices : list (only indecies)
	#texcoords : list (only indecies)

	# MTHD : V3Face.__init__
	def __init__(self, f, n, mesh):
		self.face = f
		self.number = n
		self.v3m = mesh
		self.mat = -1
		self.vertices = []
		self.texcoords = []

	# MTHD : V3Face.fill
	def fill(self):
		corners = len(self.face.v)
		if(len(self.texcoords) == 0):
			if(corners == 3):
				self.texcoords.append(-1)
				self.texcoords.append(-1)
				self.texcoords.append(-1)
			if(corners == 4):
				self.texcoords.append(-1)
				self.texcoords.append(-1)
				self.texcoords.append(-1)
				self.texcoords.append(-1)

	#write bac
	# MTHD : V3Face.write
	def write(self, file):
		corners = len(self.face.v)

		v = self.vertices
		t = self.texcoords

		v.reverse()
		t.reverse()

		if(corners == 3):
			str = "        ( face %s ( i3 %s %s %s ) ( i3 %s %s %s ) )\n" % (self.mat, v[0], v[1], v[2], t[0], t[1], t[2])
			file.write(str)
		if(corners == 4):
			str = "        ( face %s ( i4 %s %s %s %s ) ( i4 %s %s %s %s ) )\n" % (self.mat, v[0], v[1], v[2], v[3], t[0], t[1], t[2], t[3])
			file.write(str)

#---------------------------------------------------------------------------

# CLSS : V3FaceList
class V3FaceList:
	#<<member fields>>
	#list

	# MTHD : V3FaceList.__init__
	def __init__(self, meshlist):
		number = 0
		self.list = []
		for v3m in meshlist:
			faces = v3m.nmesh.faces
			for nmface in faces:
				f = V3Face(nmface, number, v3m)
				self.list.append(f)
				number = number + 1

	# MTHD : V3FaceList.linkMaterial
	def linkMaterial(self, meshlist, matlist, colorlist):
		for v3mesh in meshlist:
			for v3f in self.list:
				if(v3f.v3m.nmesh.name == v3mesh.nmesh.name):
					if(len(v3mesh.nmesh.materials) > v3f.face.mat):
						matname = v3mesh.nmesh.materials[v3f.face.mat].name
						count = 0
						for v3mat in matlist.list:
							if(matname == v3mat.mat.name):
								v3f.mat = count
							count = count + 1
		hasnomat = False
		for v3f in self.list:
			if( v3f.mat == -1 ):
				hasnomat = True
				v3f.mat = len(matlist.list)
		if(hasnomat):
			matlist.list.append(None)
			colorlist.list.append(None)

	# MTHD : V3FaceList.fill
	def fill(self):
		for f in self.list:
			f.fill()

	#write bac
	# MTHD : V3FaceList.write
	def write(self, file):
		file.write('    ( Polygons\n')
		for p in self.list:
			p.write(file)
		file.write('    )\n')

#-------------------------------------------------------------------------------

# CLSS : V3Vert
class V3Vert:
	#<<member fields>>
	#vert : NMVert
	#number
	#bone : string
	#facenormal : vector

	# MTHD : V3Vert.__init__
	def __init__(self, data, n, fn):
		self.vert = data
		self.number = n
		self.facenormal = fn

	#write bac
	# MTHD : V3Vert.writeVertex
	def writeVertex(self, file):
		str = ("            ( pnt %s %s %s )\n"% (self.vert.co[0], self.vert.co[1], self.vert.co[2]) )
		file.write(str)

	# MTHD : V3Vert.writeNormal
	def writeNormal(self, file):
		if(self.facenormal == None):
			str = ("            ( vct %s %s %s )\n"% (self.vert.no[0], self.vert.no[1], self.vert.no[2]) )
		else:
			str = ("            ( vct %s %s %s )\n"% (self.facenormal[0], self.facenormal[1], self.facenormal[2]) )
		file.write(str)

#---------------------------------------------------------------------------
# CLSS : V3VertList
class V3VertList:
	#<<member fields>>
	#list

	# MTHD : V3VertList.__init__
	def __init__(self, meshlist, facelist):
		number = 0
		self.list = []
		for v3f in facelist.list:
			for tempvert in v3f.face.v:
				if(v3f.face.smooth == 0):	#flat
					newv = V3Vert(tempvert, number, v3f.face.normal)
				else:						#smooth
					newv = V3Vert(tempvert, number, None)
				self.list.append(newv)
				v3f.vertices.append(number)
				number = number + 1

				bones = v3f.v3m.nmesh.getVertexInfluences(newv.vert.index)
				boneindex = -1
				weightmax = 0
				i = 0
				for b in bones:
					if (b[1] >= weightmax):
						weightmax = b[1]
						boneindex = i
					i = i + 1
				if(boneindex < 0 ):
					newv.bone = None 
					nmesh_cap = SearchNMeshCapsule(v3f.v3m.nmesh)
					newv.bone = nmesh_cap.name
				else:
					bonetup = bones[boneindex]
					newv.bone = bonetup[0]

	#write bac
	# MTHD : V3VertList.write
	def write(self, file):
		file.write('    ( Vertices\n')
		file.write('        ( coords\n')
		for v in self.list:
			v.writeVertex(file)
		file.write('        )\n')
		file.write('        ( normals\n')
		for v in self.list:
			v.writeNormal(file)
		file.write('        )\n')
		file.write('    )\n')

#-------------------------------------------------------------------------------

# CLSS : V3UV
class V3UV:
	#<<member fields>>
	#x
	#y
	#number

	# MTHD : V3UV.__init__
	def __init__(self, data, n):
		self.x = data[0]
		self.y = 1 - data[1]
		self.number = n

	#write bac
	# MTHD : V3UV.write
	def write(self, file):
		str = ("        ( f2 %s %s )\n"% (self.x, self.y) )
		file.write(str)

#-------------------------------------------------------------------------------

# CLSS : V3UVList
class V3UVList:
	#<<member fields>>
	#list

	# MTHD : V3UVList.__init__
	def __init__(self, meshlist, facelist):
		number = 0
		self.list = []
		for v3f in facelist.list:
			for tempuv in v3f.face.uv:
				newuv = V3UV(tempuv, number)
				self.list.append(newuv)
				v3f.texcoords.append(number)
				number = number + 1

	#write bac
	# MTHD : V3UVList.write
	def write(self, file):
		if(len(self.list) == 0):
			return
		file.write('    ( TextureCoords\n')
		for uv in self.list:
			uv.write(file)
		file.write('    )\n')

#---------------------------------------------------------------------------
  # TERM : class V3BoneList
  
# CLSS : V3BoneList
class V3BoneList:
	#<<member fields>>
	#tmpbonelist
	#list

	# MTHD : V3BoneList.__init__
	def __init__(self):
		global GlobalTopObject
		self.list = []
		self.make_list(GlobalTopObject)
	
	# MTHD : V3BoneList.make_list
	def make_list(self,obj): 
		self.list.append(V3Bone(obj))
		for child in obj.children:
			self.make_list(child)
	
	# MTHD : V3BoneList.addVertices
	def addVertices(self, verts):
		for bone in self.list:
			for v3v in verts.list:
				if(bone.name == v3v.bone):
					bone.addindex(v3v.number)

	#write bac
	# MTHD : V3BoneList.write_bac
	def write_bac(self, file):
		file.write('    ( Bones\n')
		for bone in self.list:
			bone.write_bac(file)
		file.write('    )\n')
	
	#write tra
	# MTHD : V3BoneList.write_tra
	def write_tra(self, file, startframe, endframe ):
		for bone in self.list:
			bone.write_tra(file, startframe, endframe )

#---------------------------------------------------------------------------
  # TERM : class V3Bone

# CLSS : V3Bone
class V3Bone:
	#<<member fields>>

	###Blender data
	#bone : Bone (myself)
	#name : String
	#parent : Bone
	#children : BoneList
	#relativecheck : bool
	#matrix

	###exporting data
	#name
	#hasChild
	#hasBrother
	#verts : list

	# MTHD : V3Bone.__init__
	def __init__(self, data):
		self.relativecheck = False
		self.bone = data
		self.name = data.name
		self.parent = data.parent
		self.children = data.children

		self.hasChild = data.hasChild()
		self.hasBrother = data.hasBrother()
		self.verts = []

	# MTHD : V3Bone.addindex
	def addindex(self, number):
		self.verts.append(number)

	# MTHD : V3Bone.isTop
	def isTop(self):
		if(self.parent == None):
			return True
		else:
			return False

	#write bac
	# MTHD : V3Bone.write_bac
	def write_bac(self, file):
		file.write('        ( bone\n')

		str = ('            ( name "%s" )\n'% (self.name) )
		file.write(str)

		if(self.hasChild):
			file.write('            ( hasChild true )\n')
		else:
			file.write('            ( hasChild false )\n')

		if(self.hasBrother):
			file.write('            ( hasBrother true )\n')
		else:
			file.write('            ( hasBrother false )\n')

		bbone = BacBone(self.bone.getWorldMatrix())
		bbone2 = BacBone(self.bone.matrix)
		
		rotate = bbone.translate + bbone2.rotate - bbone2.translate ;
		handle = bbone.translate + bbone2.handle - bbone2.translate ;
		
		str = ("            ( translate %s %s %s )\n"% (bbone.translate.x, bbone.translate.y, bbone.translate.z) )
		file.write(str)

		str = ("            ( rotate %s %s %s )\n"% (rotate.x, rotate.y, rotate.z) )
		file.write(str)

		str = ("            ( handle %s %s %s )\n"% (handle.x, handle.y, handle.z) )
		file.write(str)

		file.write("            ( vertexIndices\n")
		str = "                "
		for v in self.verts:
			str = str + ("%s " % v)
		str = str + "\n"
		file.write(str)
		file.write("            )\n")

		file.write('        )\n')
	
	#write_tra
	# MTHD : V3Bone.write_tra
	def write_tra(self, file, startframe, endframe):
		if(self.bone.track!=None and self.bone.track.animationExists()):

			admin = self.bone.track

			if( admin.hasCurve('LocX') and
				admin.hasCurve('LocY') and
				admin.hasCurve('LocZ') ):
				reducer = KeyFrameReducer()
				reducer.appendCurve(admin.curves['LocX'])
				reducer.appendCurve(admin.curves['LocY'])
				reducer.appendCurve(admin.curves['LocZ'])
				reducer.reduce(startframe,endframe) 

			if( admin.hasCurve('SizeX') and
				admin.hasCurve('SizeY') and
				admin.hasCurve('SizeZ') ):
				reducer = KeyFrameReducer()
				reducer.appendCurve(admin.curves['SizeX'])
				reducer.appendCurve(admin.curves['SizeY'])
				reducer.appendCurve(admin.curves['SizeZ'])
				reducer.reduce(startframe,endframe) 

			admin.compact(startframe,endframe)
			backupframe = Get('curframe')
			Set('curframe',startframe)
			Scene.GetCurrent().update(1) 
			admin.validate(startframe,self.bone)
			Set('curframe',backupframe)
			Scene.GetCurrent().update(1) 
			totframes = endframe - startframe + 1
			
			file.write('    ( bone\n')
			file.write('      ( name "%s" )\n' % self.name)
			
			# translate.x
			if(admin.hasCurve('LocX')):
				if( len(admin.curves['LocX'].frames)>0 ):
					locX = admin.curves['LocX']
					file.write('        ( translate.x\n')
					for t in range(totframes):
						time = startframe + t
						if(locX.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, locX[time] - self.bone.loc.x))
					file.write('        )\n')
			
			# translate.y
			if(admin.hasCurve('LocY')):
				if( len(admin.curves['LocY'].frames)>0 ):
					locY = admin.curves['LocY']
					file.write('        ( translate.y\n')
					for t in range(totframes):
						time = startframe + t
						if(locY.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, locY[time] - self.bone.loc.y))
					file.write('        )\n')
			
			# translate.z
			if(admin.hasCurve('LocZ')):
				if( len(admin.curves['LocZ'].frames)>0 ):
					locZ = admin.curves['LocZ']
					file.write('        ( translate.z\n')
					for t in range(totframes):
						time = startframe + t
						if(locZ.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, locZ[time] - self.bone.loc.z))
					file.write('        )\n')
			
			# scale.x
			if(admin.hasCurve('SizeX')):
				if( len(admin.curves['SizeX'].frames)>0 ):
					sizeX = admin.curves['SizeX']
					file.write('        ( scale.x\n')
					for t in range(totframes):
						time = startframe + t
						if(sizeX.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, (sizeX[time]/self.bone.size.x)*100.0))
					file.write('        )\n')
			
			# scale.y
			if(admin.hasCurve('SizeY')):
				if( len(admin.curves['SizeY'].frames)>0 ):
					sizeY = admin.curves['SizeY']
					file.write('        ( scale.y\n')
					for t in range(totframes):
						time = startframe + t
						if(sizeY.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, (sizeY[time]/self.bone.size.y)*100.0))
					file.write('        )\n')
			
			# scale.z
			if(admin.hasCurve('SizeZ')):
				if( len(admin.curves['SizeZ'].frames)>0 ):
					sizeZ = admin.curves['SizeZ']
					file.write('        ( scale.z\n')
					for t in range(totframes):
						time = startframe + t
						if(sizeZ.exists(time)):
							file.write('          ( kf %d %s )\n' % (t, (sizeZ[time]/self.bone.size.z)*100.0))
					file.write('        )\n')
			
			# rotate / roll
			quats = CurvePoints('Quaternion')
			rot_mode = False
			
			if( admin.hasCurve('QuatX') and
				admin.hasCurve('QuatY') and
				admin.hasCurve('QuatZ') and
				admin.hasCurve('QuatW') and
				len(admin.curves['QuatX'].frames)>0 and
				len(admin.curves['QuatY'].frames)>0 and
				len(admin.curves['QuatZ'].frames)>0 and
				len(admin.curves['QuatW'].frames)>0 ):
					quatX = admin.curves['QuatX']
					quatY = admin.curves['QuatY']
					quatZ = admin.curves['QuatZ']
					quatW = admin.curves['QuatW']
					quats.mergeCriticalFrom(quatX)
					quats.mergeCriticalFrom(quatY)
					quats.mergeCriticalFrom(quatZ)
					quats.mergeCriticalFrom(quatX)
					for t in range(totframes):
						time = startframe + t
						if( quatX.exists(time) and quatY.exists(time) and
							quatZ.exists(time) and quatW.exists(time) ):
								quat = Mathutils.Quaternion()
								quat.w = quatW[time]
								quat.x = quatX[time]
								quat.y = quatY[time]
								quat.z = quatZ[time]
								quats.append(time,quat)
			elif (  admin.hasCurve('RotX') and
					admin.hasCurve('RotY') and
					admin.hasCurve('RotZ') and
					len(admin.curves['RotX'].frames)>0 and
					len(admin.curves['RotY'].frames)>0 and
					len(admin.curves['RotZ'].frames)>0 ) :
					
					rotX = admin.curves['RotX']
					rotY = admin.curves['RotY']
					rotZ = admin.curves['RotZ']
					
					quats.mergeCriticalFrom(rotX)
					quats.mergeCriticalFrom(rotY)
					quats.mergeCriticalFrom(rotZ)
					
					rot_mode = True
					
					backupframe = Get('curframe')
					for fn in range(totframes):
						time = fn + startframe
						Set('curframe',time)
						Scene.GetCurrent().update(1)
						
						euler = Mathutils.Euler()
						euler.x = self.bone.object.RotX*180.0/pi
						euler.y = self.bone.object.RotY*180.0/pi
						euler.z = self.bone.object.RotZ*180.0/pi

						mat = Mathutils.Matrix(self.bone.matrix[0][0:3],self.bone.matrix[1][0:3],self.bone.matrix[2][0:3])
						base_quat = mat.toQuat()

						quat = Mathutils.DifferenceQuats(euler.toQuat(),base_quat)
						quats.append(time,quat)
						
					Set('curframe',backupframe)
					Scene.GetCurrent().update(1)
			quats.quaternionValidation(startframe,self.bone)
			eulers = CurveAdmin('Eulers')
			eulers.makeCurve('EulerX')
			eulers.makeCurve('EulerY')
			eulers.makeCurve('EulerZ')
			for t in range(totframes):
				time = startframe + t
				if(quats.exists(time)):
					euler = quats[time].toEuler()
					eulers.appendPoint('EulerX',time,euler.x)
					eulers.appendPoint('EulerY',time,euler.y)
					eulers.appendPoint('EulerZ',time,euler.z)

			eulers.mergeCriticalFrom('EulerX',quats)
			eulers.mergeCriticalFrom('EulerY',quats)
			eulers.mergeCriticalFrom('EulerZ',quats)
			eulers.reduce(startframe,endframe)

			rots =  CurvePoints('Rotations')

			for t in range(totframes):
				time = startframe + t 
				if(quats.exists(time) and eulers.exists(time)):
					traRot = TraRotation(quats[time],self.bone.matrix)
					rots.append(time,traRot)

			rots.compact(startframe,endframe)

			rotate_x = CurvePoints('rotate.x')
			rotate_y = CurvePoints('rotate.y')
			rotate_z = CurvePoints('rotate.z')
			roll = CurvePoints('roll')

			for t in range(totframes):
				time = startframe + t
				if(rots.exists(time)):
					rotate_x.append(time,rots[time].rotate[0]*100.0)
					rotate_y.append(time,rots[time].rotate[1]*100.0)
					rotate_z.append(time,rots[time].rotate[2]*100.0)
					roll.append(time,rots[time].roll)

			rotate_x.compact(startframe,endframe)
			rotate_y.compact(startframe,endframe)
			rotate_z.compact(startframe,endframe)
			roll.compact(startframe,endframe)
			
			# rotate.x
			file.write('        ( rotate.x\n')
			for t in range(totframes):
				time = startframe + t
				if(rotate_x.exists(time)):
					file.write('          ( kf %d %s )\n' % (t, rotate_x[time]))
			file.write('        )\n')
			
			# rotate.y
			file.write('        ( rotate.y\n')
			for t in range(totframes):
				time = startframe + t
				if(rotate_y.exists(time)):
					file.write('          ( kf %d %s )\n' % (t, rotate_y[time]))
			file.write('        )\n')
			
			# rotate.z
			file.write('        ( rotate.z\n')
			for t in range(totframes):
				time = startframe + t
				if(rotate_z.exists(time)):
					file.write('          ( kf %d %s )\n' % (t, rotate_z[time]))
			file.write('        )\n')
			
			# roll
			file.write('        ( roll\n')
			for t in range(totframes):
				time = startframe + t
				if(roll.exists(time)):
					file.write('          ( kf %d %s )\n' % (t, roll[time]))
			file.write('        )\n')
			file.write('    )\n')

#===========================================================================
# MARK : Builder
#---------------------------------------------------------------------------
  # MakeTopObject

# FUNC : MakeTopObject
def MakeTopObject(startframe,endframe):
	top = TransformedBaseObject('NULL',Scene.getCurrent().name)
	objects = Blender.Scene.GetCurrent().getChildren() #Blender.Object.Get()
	for object in objects:
		if(top.searchObject(object)):
			continue
		parent = object.getParent()
		hParent = MakeTopObject_EntryParents(top,parent)
		if(hParent!=None):
			hParent.appendChild(CreateCapsuleObject(object))
		else:
			top.appendChild(CreateCapsuleObject(object))
	MakeTopObject_RemoveUnnecessaryObjects(top)
	top.makeAllTracks(startframe,endframe)
	return top

# FUNC : MakeTopObject_EntryParents
def MakeTopObject_EntryParents(top,parent):
	if(parent==None):
		return None
	hParent = top.searchObject(parent)
	if(hParent!=None):
		return hParent
	hParentParent = MakeTopObject_EntryParents(top,parent.getParent())
	hParent = CreateCapsuleObject(parent)
	if(hParentParent==None):
		top.appendChild(hParent)
	else:
		hParentParent.appendChild(hParent)
	return hParent

# FUNC : MakeTopObject_RemoveUnnecessaryObjects
def MakeTopObject_RemoveUnnecessaryObjects(top):
	removable_children = []
	for child in top.children:
		MakeTopObject_RemoveUnnecessaryObjects(child)
		if (not child.isNecessaryObject()) and (not child.hasChild()):
			removable_children.append(child)
	for child in removable_children:
		child.parent.removeChild(child)

#---------------------------------------------------------------------------
  # MakeAll

# FUNC : MakeAll
def MakeAll():
	global GlobalTopObject
	global GlobalBoneList
	global GlobalNMeshList
	GlobalBoneList = []
	GlobalNMeshList = []
	scene = Scene.GetCurrent()
	context = scene.getRenderingContext()
	startframe = context.startFrame()
	endframe = context.endFrame()
	GlobalTopObject = MakeTopObject(startframe,endframe)
	getData()

#===========================================================================
# MARK : Export
#---------------------------------------------------------------------------
  # def export

# FUNC : export
def export(filename):
	print '------------------------ Export Start ---------------------------------'
	
	#get filename
	tmpString = ''
	if(filename[len(filename)-4:len(filename)] == '.bac'):
		tmpString = filename[:len(filename)-4]
	elif(filename[len(filename)-4:len(filename)] == '.tra'):
		tmpString = filename[:len(filename)-4]
	else:
		tmpString = filename

	bacfilename = tmpString + '.bac'
	trafilename = tmpString + '.tra'

	try:
		bacfile = open(bacfilename, 'w')
	except:
		Draw.PupMenu('error, could not open file for bac.')
	try:
		trafile = open(trafilename, 'w')
	except:
		Draw.PupMenu('error, could not open file for tra.')

	export_bac(bacfile)
	export_tra(trafile)

	bacfile.close()
	trafile.close()

	print '------------------------ Export finished ------------------------------'

#---------------------------------------------------------------------------
  # export_bac

# FUNC : export_bac
def export_bac(file):
	global gList_Tex		#class V3TexList
	global gList_Color		#class V3ColorList
	global gList_Mat		#class V3MatList
	global gList_Vert		#class V3VertList
	global gList_Bone		#class V3BoneList
	global gList_UV			#class V3UVList
	global gList_Face		#class V3FaceList

	file.write(';BAC\n\n')
	file.write('( Head\n')
	file.write('    ( bacVersion 6.0 )\n')
	file.write(')\n')
	file.write('( Figure\n')

	str = '    ( name "%s" )\n' % "dummy"
	file.write(str)

	gList_Tex.write(file)
	gList_Color.write(file)
	gList_Mat.write(file)
	gList_Vert.write(file)
	gList_Bone.write_bac(file)
	gList_UV.write(file)
	gList_Face.write(file)
	
	file.write(')\n')

#---------------------------------------------------------------------------
  # export_tra

# FUNC : export_tra
def export_tra(file):

	file.write(';TRA\n\n')
	file.write('( Head\n')
	file.write('    ( traVersion 4.0 )\n')
	file.write(')\n')
	file.write('( Figure\n')
	
	file.write('    ( name "%s" )\n' % "dummy")
	
	scene = Scene.GetCurrent()
	context = scene.getRenderingContext()
	
	startframe = context.startFrame()
	endframe = context.endFrame()
	totframes = endframe - startframe + 1
	
	file.write('    ( totalFrame %d )\n' % totframes)
	
	gList_Bone.write_tra(file,startframe,endframe)
	
	file.write(')\n')

#===========================================================================
# MARK : Main
#---------------------------------------------------------------------------

print '=*= BacTraExporter Ver.beta =*='
MakeAll() 
Window.FileSelector(export, 'Export')

